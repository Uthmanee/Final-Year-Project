#if !defined(_quanser_lidar_h)
#define _quanser_lidar_h

#include "quanser_extern.h"
#include "quanser_types.h"
#include "quanser_errors.h"

typedef struct tag_lidar2d_scan_matcher* t_lidar2d_scan_matcher;
typedef struct tag_range_single
{
    t_single x;
    t_single y;
} t_range_single;

/*
** Opens a 2D LIDAR scan matcher.
*/
EXTERN t_error
lidar2d_match_scans_grid_open(t_lidar2d_scan_matcher* matcher, t_single resolution, t_single max_range);

/*
** Set the reference scan for the matcher. The reference scan must be set before attempting a match. However, it does
** not have to be set every time. Once set, the matcher will continue to match against this reference scan until it
** is changed. This can save a significant amount of computation time as it does not have to recharacterize the
** reference scan in that case.
**
** The resolution is the number of cells per meter in the grid over which it will search.
*/
/*
EXTERN t_error
lidar2d_match_scans_grid_set_reference_scan(t_lidar2d_scan_matcher matcher, const t_single* ranges, const t_single* angles, t_uint num_points);
*/

/*
** Match the current scan to the reference scan, returning the pose of the current scan relative to the reference
** scan. If the score and/or covariance outputs are non-NULL then it will return the confidence in the match as
** a scalar score and/or 3x3 covariance matrix. For the fastest results, an initial pose may be specified, that
** may be derived from IMU data, for instance. In that case, if a translation search range and/or rotation search
** range is indicated then it will limit the search to those ranges.
**
** If the translation_search_range is NULL then values of 4 meters will be used. If the rotation_search_range
** is zero then a search range of 2*PI will be used.
*/
EXTERN t_error
lidar2d_match_scans_grid_match(t_lidar2d_scan_matcher matcher,
    const t_single* ref_ranges, const t_single* ref_angles, t_uint num_ref_points,
    const t_single* ranges, const t_single* angles, t_uint num_points,
    const t_single initial_pose[3], const t_range_single* translation_search_range, t_single rotation_search_range,
    t_single pose[3], t_single* score, t_single covariance[9]);

/*
** Closes the 2D LIDAR scan matcher and frees up resources allocated by the matcher. Scan matching can consume
** a significant amount of memory and system resources.
*/
EXTERN t_error
lidar2d_match_scans_grid_close(t_lidar2d_scan_matcher matcher);

#endif
