#if !defined(_quanser_file_h)
#define _quanser_file_h

#include <stddef.h>
#include <stdarg.h>

#include "quanser_errors.h"
#include "quanser_extern.h"

#if defined(_WIN32)

#include <stdlib.h>

#if !defined(__MINGW32__) && !defined(__QT__)
#include <io.h>
#ifndef _SSIZE_T_DEFINED
#define _SSIZE_T_DEFINED
typedef intptr_t ssize_t;
#endif /* _SSIZE_T_DEFINED */
#endif

#if defined(__INTIME__)

#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <io.h>
#include <unistd.h>

#define _S_IREAD        S_IREAD
#define _S_IWRITE       S_IWRITE
#define _S_IEXEC        S_IEXEC

#define _O_BINARY       O_BINARY
#define _O_TEXT         O_TEXT
#define _O_CREAT        O_CREAT
#define _O_TRUNC        O_TRUNC
#define _O_RDWR         O_RDWR
#define _O_RDONLY       O_RDONLY
#define _O_WRONLY       O_WRONLY
#define _O_SEQUENTIAL   0

#define STDIN_FILENO    0
#define STDOUT_FILENO   1
#define STDERR_FILENO   2

#define _write          write
#define _read           read
#define _close          close
#define _unlink         unlink
#define _stat           stat
#define _getcwd         getcwd

typedef int errno_t;

struct _utimbuf
{
    time_t actime;
    time_t modtime;
};

#else

#include <sys/utime.h>
#include <share.h>

#if !defined(_SH_COMPAT)
#define _SH_COMPAT      _SH_DENYNO
#endif

#if defined(__MINGW32__) && !defined(__QT__)

typedef int errno_t;

#else

/*
 *  Owner permissions
 */
#define S_IRWXU     000700              /*  Read, write, execute/search     */
#define S_IRUSR     000400              /*  Read permission                 */
#define S_IWUSR     000200              /*  Write permission                */
#define S_IXUSR     000100              /*  Execute/search permission       */

/*
 *  Group permissions
 */
#define S_IRWXG     000070              /*  Read, write, execute/search     */
#define S_IRGRP     000040              /*  Read permission                 */
#define S_IWGRP     000020              /*  Write permission                */
#define S_IXGRP     000010              /*  Execute/search permission       */

/*
 *  Other permissions
 */
#define S_IRWXO     000007              /*  Read, write, execute/search     */
#define S_IROTH     000004              /*  Read permission                 */
#define S_IWOTH     000002              /*  Write permission                */
#define S_IXOTH     000001              /*  Execute/search permission       */

#endif /* !defined(__MINGW32__) && !defined(__QT__)*/

#endif

#else

#define _utimbuf    utimbuf

#include "quanser_runtime.h"

#if defined (__linux) || defined(__APPLE__) || defined(__vxworks)

#if defined(__linux)
#include <linux/limits.h>   /* PATH_MAX */
#endif

#if defined(_INTEL_AERO) || defined(_INTEL_EDISON) || defined(_RASPBERRY_PI) || defined(_RASPBERRY_PI_3) || defined(_RASPBERRY_PI_4) || defined(_RASPBERRY32_PI) || defined(_RASPBERRY64_PI) || defined(_UBUNTU) || defined(_NVIDIA) || defined(__LINUX_RT_ARMV7__) || defined(_DUOVERO) || defined(__APPLE__)
#define O_BINARY       0
#include <unistd.h>
#endif

#if defined(__APPLE__)
#define O_LARGEFILE    0
#define EFPOS          ENOTRECOVERABLE
#endif

/* sopen() is not actually defined in Linux so provide same values for share flags as in QNX */
#define SH_DENYRW      0x10
#define SH_DENYWR      0x20
#define SH_DENYRD      0x30
#define SH_DENYNO      0x40

#else
#define _futime     futime
#include <limits.h>
#endif

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <utime.h>

typedef int errno_t;
typedef off_t _off_t;

#define _chdir          chdir
#define _read           read
#define _write          write
#define _close          close
#define _unlink         unlink
#define _stat           stat
#define _fstat          fstat
#define _getcwd         getcwd
#define _fileno         fileno

#define _MAX_PATH       PATH_MAX
#define _MAX_FNAME      NAME_MAX

#define _O_BINARY       O_BINARY
#define _O_TEXT         0
#define _O_CREAT        O_CREAT
#define _O_TRUNC        O_TRUNC
#define _O_RDWR         O_RDWR
#define _O_RDONLY       O_RDONLY
#define _O_WRONLY       O_WRONLY
#define _O_SEQUENTIAL   0

#define _S_IREAD        S_IREAD
#define _S_IWRITE       S_IWRITE
#define _S_IEXEC        S_IEXEC

#define _SH_COMPAT      SH_COMPAT
#define _SH_DENYNO      SH_DENYNO
#define _SH_DENYWR      SH_DENYWR
#define _SH_DENYRW      SH_DENYRW

#endif

typedef enum tag_file_origin
{
    FILE_ORIGIN_BEGINNING,
    FILE_ORIGIN_CURRENT,
    FILE_ORIGIN_END
} t_file_origin;

typedef FILE* t_stdfile;

/*
    Description:

    This function creates a directory, including all components of the
    directory, if necessary. Hence, it is possible to create the complete
    hierarchy in a single call.

    Parameters:

    folder_path = the folder to create
    permissions = the permissions to be assigned to the folder (see S_IRWXU
                  and other similar bit masks).

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
create_directory(const char * folder_path, t_uint permissions);

/*
    Description:

    This function creates a directory, including all components of the
    directory, if necessary. Hence, it is possible to create the complete
    hierarchy in a single call.

    Parameters:

    folder_path = the folder to create
    permissions = the permissions to be assigned to the folder (see S_IRWXU
                  and other similar bit masks).

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
create_wdirectory(const wchar_t * folder_path, t_uint permissions);

#if defined(_UNICODE)
#define _create_tdirectory(folder_path, permissions) create_wdirectory(folder_path, permissions)
#else
#define _create_tdirectory(folder_path, permissions) create_directory(folder_path, permissions)
#endif

/*
    Description:

    This function opens a file. If the file fails to open then it returns
    a standard QUARC error code. Note that it supports long path names in
    Windows, even for relative paths and Unix-style paths. It also handles
    the situation where the current directory is a UNC-style path.

    Parameters:

    filename   = the filename of the file to open or create
    open_flags = the open flags (see _open in MSDN), such as:
                    _O_APPEND   = append to the end of the file.
                    _O_BINARY   = open file in binary mode.
                    _O_CREAT    = creates the file and opens for writing.
                    _O_RDONLY   = opens the file for reading only.
                    _O_RDWR     = opens the file for reading and writing.
                    _O_TEXT     = opens the file in text mode.
                    _O_TRUNC    = opens the file and truncates it to zero length.
                    _O_WRONLY   = opens the file for writing only.
    share_flags = the sharing options (see _sopen_s in MSDN), such as:
                    _SH_DENYRW  = denies read and write access to the file (exclusive access - no access by others).
                    _SH_DENYWR  = denies write access to the file (read-only access by others).
                    _SH_DENYRD  = denies read access to the file (write-only access by others).
                    _SH_DENYNO  = permits read and write access by others.
    mode        = the mode. See the Linux open documentation for valid modes. Typical modes are:
                    S_IRUSR  = allow read access by the current user
                    S_IRGRP  = allow read access by members of the same group
                    S_IROTH  = allow read access by others.
                    S_IWUSR  = allow write access by the current user
                    S_IWGRP  = allow write access by members of the same group
                    S_IWOTH  = allow write access by others.
                    S_IXUSR  = allow execute access by the current user
                    S_IXGRP  = allow execute access by members of the same group
                    S_IXOTH  = allow execute access by others.
                  On Windows systems, std_open currently gives read access if any of the read flags are set, write
                  access if any of the write flags are set and execute permissions if any of the execute flags are set.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
std_open(const char * filename, int open_flags, int share_flags, int mode, int * file_handle);

/*
    Description:

    This function opens a file. If the file fails to open then it returns
    a standard QUARC error code. Note that it supports long path names in
    Windows, even for relative paths and Unix-style paths. It also handles
    the situation where the current directory is a UNC-style path. The
    filename is a wide character string.

    Parameters:

    filename   = the filename of the file to open or create
    open_flags = the open flags (see _open in MSDN), such as:
                    _O_APPEND   = append to the end of the file.
                    _O_BINARY   = open file in binary mode.
                    _O_CREAT    = creates the file and opens for writing.
                    _O_RDONLY   = opens the file for reading only.
                    _O_RDWR     = opens the file for reading and writing.
                    _O_TEXT     = opens the file in text mode.
                    _O_TRUNC    = opens the file and truncates it to zero length.
                    _O_WRONLY   = opens the file for writing only.
    share_flags = the sharing options (see _sopen_s in MSDN), such as:
                    _SH_DENYRW  = denies read and write access to the file (exclusive access - no access by others).
                    _SH_DENYWR  = denies write access to the file (read-only access by others).
                    _SH_DENYRD  = denies read access to the file (write-only access by others).
                    _SH_DENYNO  = permits read and write access by others.
    mode        = the mode. See the Linux open documentation for valid modes. Typical modes are:
                    S_IRUSR  = allow read access by the current user
                    S_IRGRP  = allow read access by members of the same group
                    S_IROTH  = allow read access by others.
                    S_IWUSR  = allow write access by the current user
                    S_IWGRP  = allow write access by members of the same group
                    S_IWOTH  = allow write access by others.
                    S_IXUSR  = allow execute access by the current user
                    S_IXGRP  = allow execute access by members of the same group
                    S_IXOTH  = allow execute access by others.
                  On Windows systems, std_open currently gives read access if any of the read flags are set, write
                  access if any of the write flags are set and execute permissions if any of the execute flags are set.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
std_wopen(const wchar_t * filename, int open_flags, int share_flags, int mode, int * file_handle);

#if defined(_UNICODE)
#define std_topen   std_open
#else
#define std_topen   std_wopen
#endif

/*
    Description:

    This function reads bytes from a file.

    Parameters:

    file_handle = the handle to the file (from std_open).
    buffer      = the buffer in which to store the bytes read.
    count       = the number of bytes to read.

    Return values:

    Returns the number of bytes read on success and a negative error code on failure.
*/
EXTERN ssize_t
std_read(int file_handle, void * buffer, size_t count);

/*
    Description:

    This function writes bytes to a file.

    Parameters:

    file_handle = the handle to the file (from std_open).
    buffer      = the buffer containing the bytes to write.
    count       = the number of bytes to write.

    Return values:

    Returns the number of bytes written on success and a negative error code on failure.
*/
EXTERN ssize_t
std_write(int file_handle, const void * buffer, size_t count);

/*
    Description:

    This function seeks to the given position in the file. It returns zero on success and
    a negative error code on failure.

    Parameters:

    file_handle   = handle of open file.
    offset        = the offset from the origin to which to seek. It may be positive
                    or negative depending on the origin.
    origin        = whether to start from the beginning of the file, the current position
                    or the end of the file. See the t_file_origin enumeration.

    Return values:

    Returns zero on success and a negative error code on failure.
*/
EXTERN t_error
std_seek(int file_handle, t_int64 offset, t_file_origin origin);

/*
    Description:

    This function closes a file.

    Parameters:

    file_handle = the handle to the file (from std_open).

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
std_close(int file_handle);

/*
    Description:

    This function gets information about an open file. If it fails then it returns
    a standard QUARC error code. It takes a file descriptor as argument.

    Parameters:

    file_handle = the handle of the open file.
    buffer      = the buffer in which to store the file information.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
std_fstat(int file_handle, struct _stat * buffer);

/*
    Description:

    This function gets information about a file. If it fails then it returns
    a standard QUARC error code. Note that it supports long path names in
    Windows, even for relative paths and Unix-style paths. It also handles
    the situation where the current directory is a UNC-style path.

    Parameters:

    filename = the filename of the file for which to get information.
    buffer   = the buffer in which to store the file information.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
std_stat(const char * filename, struct _stat * buffer);

/*
    Description:

    This function gets information about a file. If it fails then it returns
    a standard QUARC error code. Note that it supports long path names in
    Windows, even for relative paths and Unix-style paths. It also handles
    the situation where the current directory is a UNC-style path.

    Parameters:

    filename = the filename of the file for which to get information.
    buffer   = the buffer in which to store the file information.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
std_wstat(const wchar_t * filename, struct _stat * buffer);

#if defined(_UNICODE)
#define _std_tstat(filename, buffer)    std_wstat(filename, buffer)
#else
#define _std_tstat(filename, buffer)    std_stat(filename, buffer)
#endif

/*
    Description:

    This function sets the access and modification times for a file. If it
    fails then it returns a standard QUARC error code. If the times argument
    is NULL then it uses the current time.

    Parameters:

    file_handle = the file handle of the open file
    times       = the access and modification times (since midnight, Jan. 1, 1970)

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
std_futime(int file_handle, const struct _utimbuf * times);

/*
    Description:

    This function opens a file. If the file fails to open then it returns
    a standard QUARC error code. Note that it supports long path names in
    Windows, even for relative paths and Unix-style paths. It also handles
    the situation where the current directory is a UNC-style path.

    Parameters:

    filename = the filename of the file to open or create
    mode     = the mode. See the fopen documentation for valid modes. Typical
               modes are:
                   "r"  = opens for reading. If the file does not exist it fails with -QERR_FILE_NOT_FOUND.
                   "w"  = opens for writing. If the file exists its contents are destroyed.
                   "a"  = opens for appending. Creates the file if it doesn't exist.
                   "r+" = opens for reading and writing. If the file does not exist it fails with -QERR_FILE_NOT_FOUND.
                   "w+" = opens for reading and writing. If the file exists its contents are destroyed.
                   "a+" = opens for reading and appending. Creates the file if it doesn't exist.
               The mode can be modified by adding a translation mode character:
                   "t"  = opens in text (translated) mode. On Windows, carriage-return line-feed combinations are translated
                          as single line-feeds on input and single line-feeds on output are translated to carriage-return
                          line-feed combinations.
                   "b"  = opens in binary (untranslated) mode. No translations are performed.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
stdfile_open(const char * filename, const char * mode, t_stdfile* file_handle);

EXTERN t_error
stdfile_wopen(const wchar_t * filename, const wchar_t * mode, t_stdfile* file_handle);

#if defined(_UNICODE)
#define stdfile_topen   stdfile_wopen
#else
#define stdfile_topen   stdfile_open
#endif

/*
    Description:

    This function reads binary data from a file. It returns zero
    on success or a negative error code on failure. The number of bytes
    read is stored at the address pointed to by the bytes_read argument.
    This number may be less than the number requested if end-of-file is reached
    before all the data has been read or an error occurs. If end-of-file
    is reached then the return value is zero and the bytes_read argument
    indicates how many bytes were actually read. If an error occurs then
    a negative error code is returned, and the bytes_read arguments indicates
    the number of bytes read successfully before the error. However, in
    this case the file pointer is indeterminate and the file cannot continue
    to be read.

    Parameters:

    file_handle = handle of open file.
    buffer      = address of buffer in which to read data
    buffer_size = number of bytes to read from the file into the buffer
    bytes_read  = address of a variable which will be updated with the 
                  number of bytes read. This argument may be NULL.

    Return values:

    Returns zero on success and a negative error code on failure.
*/
EXTERN t_error
stdfile_read(t_stdfile file_handle, void * buffer, size_t buffer_size, size_t * bytes_read);

/*
    Description:

    This function writes binary data to a file. It returns zero on success and
    a negative error code on failure. The number of bytes written is returned
    in the address pointed to by the bytes_written argument. The number of bytes
    written will always equal the number requested unless an error occurs.

    Parameters:

    file_handle   = handle of open file.
    buffer        = address of buffer containing data to write
    buffer_size   = number of bytes from the buffer to write to the file
    bytes_written = address of a variable which will be updated with the 
                    number of bytes written. This argument may be NULL.

    Return values:

    Returns zero on success and a negative error code on failure.
*/
EXTERN t_error
stdfile_write(t_stdfile file_handle, const void * buffer, size_t buffer_size, size_t * bytes_written);

/*
    Description:

    This function reads a string from the file. A string is terminated
    at the next newline character or end-of-file or when the buffer is
    exhausted. The string will always be null-terminated, so the maximum
    string length it can read is buffer_size code units. The newline
    character, if read, is included in the string.

    Parameters:

    file_handle = handle of open file.
    buffer      = address of buffer in which to read string
    buffer_size = number of code units (bytes) available in the buffer

    Return values:

    Returns the number of code units read on success. If the end of file is reached then zero
    is returned. Otherwise a negative error code is returned.
*/
EXTERN t_int
stdfile_gets(t_stdfile file_handle, char * buffer, size_t buffer_size);

EXTERN t_int
stdfile_wgets(t_stdfile file_handle, wchar_t * buffer, size_t buffer_size);

#if defined(_UNICODE)
#define stdfile_tgets   stdfile_wgets
#else
#define stdfile_tgets   stdfile_gets
#endif

/*
    Description:

    This function writes formatted text to a file. It returns zero on success and
    a negative error code on failure. The number of bytes written is returned unless
    an error occurs.

    Parameters:

    file_handle   = handle of open file.
    bytes_written = address of a variable which will be updated with the 
                    number of bytes written. This argument may be NULL.
    format        = format string
    ...           = optional arguments for the format string

    Return values:

    Returns zero on success and a negative error code on failure.
*/
EXTERN t_error
stdfile_printf(t_stdfile file_handle, size_t * bytes_written, const char * format, ...);

EXTERN t_error
stdfile_wprintf(t_stdfile file_handle, size_t * bytes_written, const wchar_t * format, ...);

#if defined(_UNICODE)
#define stdfile_tprintf   stdfile_wprintf
#else
#define stdfile_tprintf   stdfile_printf
#endif

/*
    Description:

    This function writes formatted text to stdout. It returns zero on success and
    a negative error code on failure. The number of bytes written is returned unless
    an error occurs.

    Parameters:

    bytes_written = address of a variable which will be updated with the 
                    number of bytes written. This argument may be NULL.
    format        = format string
    ...           = optional arguments for the format string

    Return values:

    Returns zero on success and a negative error code on failure.
*/
EXTERN t_error
stdout_printf(size_t * bytes_written, const char * format, ...);

EXTERN t_error
stdout_wprintf(size_t * bytes_written, const wchar_t * format, ...);

#if defined(_UNICODE)
#define stdout_tprintf   stdout_wprintf
#else
#define stdout_tprintf   stdout_printf
#endif

/*
    Description:

    This function writes formatted text to a file. It returns zero on success and
    a negative error code on failure. The number of bytes written is returned unless
    an error occurs.

    Parameters:

    file_handle   = handle of open file.
    bytes_written = address of a variable which will be updated with the 
                    number of bytes written. This argument may be NULL.
    format        = format string
    arguments     = the arguments to format

    Return values:

    Returns the number of code units (bytes) written on success (not including the null terminator),
    or a negative error code. If the string is truncated then -QERR_STRING_TOO_SMALL is returned,
    but the truncated string is still written to the buffer and is always null terminated.
*/
EXTERN t_int
stdfile_vprintf(t_stdfile file_handle, size_t * bytes_written, const char * format, va_list arguments);

EXTERN t_int
stdfile_vwprintf(t_stdfile file_handle, size_t * bytes_written, const wchar_t * format, va_list arguments);

#if defined(_UNICODE)
#define stdfile_vtprintf(file_handle, bytes_written, format, arguments)   stdfile_vwprintf(file_handle, bytes_written, format, arguments)
#else
#define stdfile_vtprintf(file_handle, bytes_written, format, arguments)   stdfile_vprintf(file_handle, bytes_written, format, arguments)
#endif

/*
    Description:

    This function reads formatted text from a file. It returns zero on success and
    a negative error code on failure. The number of items read is returned unless
    an error occurs. If end of file is reached before the scan is complete then
    -QERR_PREMATURE_END_OF_FILE is returned. A return value of 0 means there were
    no matches.

    Parameters:

    file_handle   = handle of open file.
    format        = format string
    ...           = optional arguments for the format string

    Return values:

    Returns the number of items matched on success and a negative error code on failure.
*/
EXTERN t_int
stdfile_scanf(t_stdfile file_handle, const char* format, ...);

EXTERN t_int
stdfile_wscanf(t_stdfile file_handle, const wchar_t* format, ...);

#if defined(_UNICODE)
#define stdfile_tscanf   stdfile_wscanf
#else
#define stdfile_tscanf   stdfile_scanf
#endif

EXTERN t_int
stdfile_vscanf(t_stdfile file_handle, const char* format, va_list arguments);

EXTERN t_int
stdfile_vwscanf(t_stdfile file_handle, const wchar_t* format, va_list arguments);

#if defined(_UNICODE)
#define stdfile_vtscanf   stdfile_vwscanf
#else
#define stdfile_vtscanf   stdfile_vscanf
#endif


EXTERN t_int
stdfile_putc(t_stdfile file_handle, const char c);

EXTERN t_int
stdfile_putwc(t_stdfile file_handle, const wchar_t c);

#if defined(_UNICODE)
#define stdfile_tputc(file_handle, c)   stdfile_putc(file_handle, c)
#else
#define stdfile_tputc(file_handle, c)   stdfile_putwc(file_handle, c)
#endif

/*
    Description:

    This function gets information about an open file. If it fails then it returns
    a standard QUARC error code. It takes a t_stdfile handle as argument.

    Parameters:

    file_handle = the handle of the open file.
    buffer      = the buffer in which to store the file information.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
stdfile_stat(t_stdfile file_handle, struct _stat* buffer);

/*
    Description:

    This function gets the current position in the file. It returns zero on success and
    a negative error code on failure.

    Parameters:

    file_handle = handle of open file.
    position    = the current position in the file.

    Return values:

    Returns zero on success and a negative error code on failure.
*/
EXTERN t_error
stdfile_tell(t_stdfile file_handle, t_int64* offset);

/*
    Description:

    This function seeks to the given position in the file. It returns zero on success and
    a negative error code on failure.

    Parameters:

    file_handle   = handle of open file.
    offset        = the offset from the origin to which to seek. It may be positive
                    or negative depending on the origin.
    origin        = whether to start from the beginning of the file, the current position
                    or the end of the file. See the t_file_origin enumeration.

    Return values:

    Returns zero on success and a negative error code on failure.
*/
EXTERN t_error
stdfile_seek(t_stdfile file_handle, t_int64 offset, t_file_origin origin);

/*
    Description:

    This function flushes any cached data to a file. If an error occurs then it returns
    a standard QUARC error code.

    Parameters:

    file_handle = handle of open file.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
stdfile_flush(t_stdfile file_handle);

/*
    Description:

    This function closes a file. If an error occurs then it returns
    a standard QUARC error code.

    Parameters:

    file_handle = handle of open file.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
stdfile_close(t_stdfile file_handle);

/*
    Description:

    This function opens a temporary file. If the file fails to open then it returns
    a standard QUARC error code. When the file is closed it will be deleted automatically.

    Parameters:

    file_handle = pointer to a t_stdfile variable in which the new file handle will be stored.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
stdfile_temp(t_stdfile* file_handle);

/*
    Description:

    This function creates a symbolic link. If the link cannot be created then it returns
    a standard QUARC error code.

    Parameters:

    filename = the path of the symbolic link that is created
    target   = the target to which the symbolic link points

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
std_symlink(const char* old_path, const char* new_path);

/*
    Description:

    This function creates a hard link. If the link cannot be created then it returns
    a standard QUARC error code.

    Parameters:

    old_path = the target to which the hard link points
    new_path = the path of the hard link that is created

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
std_link(const char* old_path, const char* new_path);


#endif
