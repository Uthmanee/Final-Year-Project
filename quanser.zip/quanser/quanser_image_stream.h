#if !defined(_quanser_image_stream_h)
#define _quanser_image_stream_h

#include "quanser_extern.h"
#include "quanser_types.h"
#include "quanser_errors.h"
#include "quanser_image.h"

/*
** An image stream is an opaque image format optimized for each platform. It takes full advantage of the platform capabilities
** available, such as the GPU. For example, on an NVIDIA target, it will keep the image in the GPU without ever bringing it
** into main memory, avoiding the overhead of transferring the image to or from the GPU to CPU memory.
*/
typedef struct tag_image_stream* t_image_stream;
typedef struct tag_image_pool* t_image_pool;
typedef struct tag_image* t_image;

/*--- Image Stream functions ---*/

/*
** Description:
**
**  Creates an image stream.
**
** Parameters:
**
**  stream - the address of a t_image_stream variable to receive the handle to the image stream.
**
** Returns:
**
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
image_stream_create(t_image_stream* stream);

/*
** Description:
**
**  Pushes an image onto the image stream's stack.
**
** Parameters:
**
**  stream - a t_image_stream variable containing the handle to the image stream.
**  image  - a t_image representing the image.
**
** Returns:
**
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
image_stream_push_image(t_image_stream stream, t_image image);

/*
** Description:
**
**  Pops an image from the image stream's stack.
**
** Parameters:
**
**  stream - a t_image_stream variable containing the handle to the image stream.
**  image  - a pointer to an t_image variable which will receive the image. It may be NULL,
**           in which case the image is popped but discarded.
**
** Returns:
**
**  Returns zero on success and a negative error code otherwise. If the stack is empty so
**  that no image is available then -QERR_OBJECT_NOT_FOUND is returned.
*/
EXTERN t_error
image_stream_pop_image(t_image_stream stream, t_image* image);

/*
** Description:
**
**  Destroys an image stream.
**
** Parameters:
**
**  stream - a t_image_stream variable containing the handle to the image stream.
**
** Returns:
**
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
image_stream_destroy(t_image_stream stream);

/*--- Image Pool functions ---*/

/*
** Description:
**
**  Creates an image pool. This function is typically called only once to get the global
**  image pool.
**
** Parameters:
**
**  pool - the address of a t_image_pool variable to receive the handle to the image pool.
**
** Returns:
**
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
image_pool_create(t_image_pool* pool);

/*
** Description:
**
**  Returns the default image pool. Passing NULL as the pool to the other image_pool functions
**  will use this default pool so this function is not required.
**
** Parameters:
**
**  pool - the address of a t_image_pool variable to receive the handle to the default image pool.
**
** Returns:
**
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
image_pool_get_default(t_image_pool* pool);

/*
** Description:
**
**  Gets an image from the given image pool. If pool is NULL then a default image pool
**  is used. The memory for the image will be allocated if an image of the appropriate
**  format and dimensions is not already available in the pool. Note that the image
**  belongs to the pool. The pool lifetime must exceed that of all images it creates
**  even if the images are not currently part of the pool.
**
** Parameters:
**
**  pool   - a t_image_pool variable containing the handle to the image pool. If this
**           argument is NULL then a default image pool is used.
**  format - the colour format of the image: either monochrome or colour. Further
**           flexibility is not supported. The image format used is platform-specific
**           and optimized for the particular platform.
**  width  - the width of the image to retrieve.
**  height - the height of the image to retrieve.
**  image  - a pointer to a t_image variable to receive the handle to the image.
**
** Returns:
**
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
image_pool_get_image(t_image_pool pool, t_image_color_format format, t_uint width, t_uint height, t_image* image);

/*
** Description:
**
**  Returns an image to the given image pool. If pool is NULL then a default image pool
**  is used. The image should no longer be used.
**
** Parameters:
**
**  pool  - a t_image_pool variable containing the handle to the image pool. If this
**          argument is NULL then a default image pool is used.
**  image - the image to return to the pool.
**
** Returns:
**
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
image_pool_put_image(t_image_pool pool, t_image image);

/*
** Description:
**
**  Frees all the image in the given image pool, releasing their resources.
**  However, it does not free the image pool itself which may still be used.
**
** Parameters:
**
**  pool - a t_image_pool variable containing the handle to the image pool. If this
**         argument is NULL then the default image pool is cleared.
**
** Returns:
**
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
image_pool_clear(t_image_pool pool);

/*
** Description:
**
**  Destroys the given image pool, releasing its resources.
**
** Parameters:
**
**  pool - a t_image_pool variable containing the handle to the image pool. The argument
**         may not be NULL.
**
** Returns:
**
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
image_pool_destroy(t_image_pool pool);

#endif

