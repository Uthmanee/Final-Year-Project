#if !defined(_quanser_timebase_h)
#define _quanser_timebase_h

#include "quanser_errors.h"
#include "quanser_runtime.h"

typedef t_error (* t_start_polled_timebase)(void * context);
typedef t_error (* t_stop_polled_timebase)(void * context);

EXTERN t_error
polled_timebase_register(t_start_polled_timebase start_function, t_stop_polled_timebase stop_function, void * context);

EXTERN t_error
polled_timebase_call_start(void);

EXTERN t_error
polled_timebase_call_stop(void);

EXTERN t_error
polled_timebase_unregister(void);

#endif
