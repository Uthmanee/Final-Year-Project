#if !defined(_quanser_partitioning_h)
#define _quanser_partitioning_h

#include "quanser_extern.h"
#include "quanser_errors.h"

#define PARTITION_FLAG_THREAD_JOIN      (1 << 0)    /* cause current thread to join partition (default) */
#define PARTITION_FLAG_PROCESS_JOIN     (1 << 1)    /* cause current process to join partition */

EXTERN t_error
partition_join(const char * partition_name, t_uint flags);

#endif
