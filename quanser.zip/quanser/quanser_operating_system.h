#if !defined(_quanser_operating_system_h)
#define _quanser_operating_system_h

#define MAX_OPERATING_SYSTEM  32

#if defined(UNDER_RTSS)
    #define OPERATING_SYSTEM "rtx"
#elif defined(__INTIME__)
    #define OPERATING_SYSTEM "intime"
#elif defined(_WIN64)
    #define OPERATING_SYSTEM "win64"
#elif defined(_WIN32)
    #define OPERATING_SYSTEM "windows"
#elif defined(__QNX__)
    #if defined(__X86__)
        #define OPERATING_SYSTEM "qnx_x86"
    #elif defined(__PPC__)
        #if defined(VARIANT_spe)
            #define OPERATING_SYSTEM "qnx_ppc_be_spe"
        #else
            #define OPERATING_SYSTEM "qnx_ppc_be"
        #endif
    #elif defined(__MIPS__)
        #define OPERATING_SYSTEM "qnx_mips"
    #elif defined(__SH__)
        #define OPERATING_SYSTEM "qnx_sh"
    #elif defined(__ARM__)
        #define OPERATING_SYSTEM "qnx_arm"
    #else
        #error Unrecognized QNX target. Unable to define OPERATING_SYSTEM macro.
    #endif
#elif defined(_GUMSTIX)
    #if defined(_VERDEX)
        #define OPERATING_SYSTEM "linux_verdex"
    #elif defined(_OVERO)
        #define OPERATING_SYSTEM "linux_overo"
    #elif defined(_DUOVERO_2016)
        #define OPERATING_SYSTEM "linux_duovero_2016"
    #elif defined(_DUOVERO)
        #define OPERATING_SYSTEM "linux_duovero"
    #else
        #error Undefined gumstix target!
    #endif
#elif defined(_RASPBERRY64_PI)
    #define OPERATING_SYSTEM "linux_pi_arm64"
#elif defined(_RASPBERRY32_PI)
    #define OPERATING_SYSTEM "linux_pi_arm32"
#elif defined(_RASPBERRY_PI_4)
    #define OPERATING_SYSTEM "linux_pi_4"
#elif defined(_RASPBERRY_PI_3)
    #define OPERATING_SYSTEM "linux_pi_3"
#elif defined(_RASPBERRY_PI)
    #define OPERATING_SYSTEM "linux_raspbian"
#elif defined(_INTEL_AERO)
    #define OPERATING_SYSTEM "linux_x64"
#elif defined(_INTEL_EDISON)
    #define OPERATING_SYSTEM "linux_x86"
#elif defined(_ONLINE)
    #define OPERATING_SYSTEM "linux_online"
#elif defined(_UBUNTU)
    #define OPERATING_SYSTEM "linux_x86_64"
#elif defined(__LINUX_RT_ARMV7__)
    #define OPERATING_SYSTEM "linux_rt_armv7"
#elif defined(__linux) && defined(__i386)
    #define OPERATING_SYSTEM "linux_x86"
#elif defined(__APPLE__)
    #if defined(__i386)
        #define OPERATING_SYSTEM "mac_x86"
    #elif defined(__amd64)
        #define OPERATING_SYSTEM "mac_x86_64"
    #else
        #define OPERATING_SYSTEM "mac_arm64"
    #endif
#elif defined(_XAVIER_NX)
    #define OPERATING_SYSTEM "linux_qdrone2"
#elif defined(_ORIN_NANO)
    #define OPERATING_SYSTEM "linux_qbot_platform"
#elif defined(_ORIN_AGX)
    #define OPERATING_SYSTEM "linux_qcar2"
#elif defined(_NVIDIA)
    #define OPERATING_SYSTEM "linux_nvidia"
#endif

#endif
