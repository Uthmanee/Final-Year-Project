#if !defined(_quanser_utf_h)
#define _quanser_utf_h

#include "quanser_extern.h"
#include "quanser_errors.h"

#define UTF16_HIGH_SURROGATE_START      0x0D800
#define UTF16_HIGH_SURROGATE_END        0x0DBFF
#define UTF16_LOW_SURROGATE_START       0x0DC00
#define UTF16_LOW_SURROGATE_END         0x0DFFF
#define UTF16_BYTE_ORDER_MARK           0x0FEFF

#define UTF32_MAX_CHARACTER             0x0010FFFF

/* Maximum number of code units in a character */
#define UTF8_MAX_CODE_UNITS             4
#define UTF16_MAX_CODE_UNITS            2
#define UTF32_MAX_CODE_UNITS            1

#if WCHAR_MAX < 0x0100 /* wchar_t is UTF-8 */
#define WCHAR_MAX_CODE_UNITS UTF8_MAX_CODE_UNITS
#elif WCHAR_MAX < 0x010000 /* wchar_t is UTF-16 */
#define WCHAR_MAX_CODE_UNITS UTF16_MAX_CODE_UNITS
#else /* wchar_t is UTF-32 */
#define WCHAR_MAX_CODE_UNITS UTF32_MAX_CODE_UNITS
#endif

/*
    Description:

    This function returns a pointer to the UTF-8 character following
    the given character. The given character must be the start of a
    valid UTF-8 character or an error is returned. In UTF-8, the lead
    code unit indicates the length of the character, so this function
    only evaluates the lead code unit. A value of 0 is returned on success.
    A UTF-8 character may occupy up to 4 code units (4 bytes).

    If the UTF-8 code unit is not a valid lead code unit then
    an error is returned. In the event of an error, the next pointer
    is not updated. The next pointer is only set when the length
    is successfully determined.

    Parameters:

    source  = the UTF-8 character
    next    = a t_utf8_char * variable in which the address of the
              character following "source" is stored.

    Return values:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
utf8_char_next(t_utf8_char * character, t_utf8_char ** next);

/*
    Description:

    This function returns a pointer to the UTF-16 character following
    the given character. The given character must be the start of a
    valid UTF-16 character or an error is returned. In UTF-16, the lead
    code unit indicates the length of the character, so this function
    only evaluates the lead code unit. A value of 0 is returned on success.
    A UTF-16 character may occupy up to 2 code units (4 bytes).

    If the UTF-16 code unit is not a valid lead code unit then
    an error is returned. In the event of an error, the next pointer
    is not updated. The next pointer is only set when the length
    is successfully determined.

    Parameters:

    source  = the UTF-16 character
    next    = a t_utf16_char * variable in which the address of the
              character following "source" is stored.

    Return values:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
utf16_char_next(t_utf16_char * character, t_utf16_char ** next);

/*
    Description:

    This function returns a pointer to the UTF-32 character following
    the given character. The given character must be a valid UTF-32 
    character or an error is returned. A value of 0 is returned on success.
    A UTF-32 character always occupies 1 code unit (4 bytes).

    If the UTF-32 code unit is not a valid character then an
    error is returned. In the event of an error, the next pointer
    is not updated. The next pointer is only set when the length
    is successfully determined.

    Parameters:

    source  = the UTF-32 character
    next    = a t_utf32_char * variable in which the address of the
              character following "source" is stored.

    Return values:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
utf32_char_next(t_utf32_char * character, t_utf32_char ** next);

#define char_next  utf8_char_next

#if WCHAR_MAX < 0x0100 /* wchar_t is UTF-8 */
#define wchar_next  utf8_char_next
#elif WCHAR_MAX < 0x010000 /* wchar_t is UTF-16 */
#define wchar_next  utf16_char_next
#else /* wchar_t is UTF-32 */
#define wchar_next  utf32_char_next
#endif

/*
    Description:

    This function gets the length of the UTF-8 character by examining the
    lead code unit only. It returns -QERR_ILLEGAL_UTF8_CHARACTER if the lead
    code unit is not a valid UTF-8 code unit. It returns -QERR_ILLEGAL_UTF8_LEAD_CHAR
    if the lead code unit given is a valid UTF-8 code unit but not a lead
    character.

    Otherwise it returns a value between 1 and 4 according to the length 
    indicated by the lead code unit. It only tests the validity of the lead
    code unit. Subsequent code units are not validated.

    Parameters:

    source = the lead code unit used to determine the length of the UTF-8 character.

    Return value:

    Returns the length in code units indicated by the given lead code unit.
    If an error occurs then a negative error code is returned.
*/
EXTERN t_int
utf8_lead_char_length(t_utf8_char source);

/*
    Description:

    This function gets the length of the UTF-8 character by examining all
    the code units. It returns -QERR_ILLEGAL_UTF8_CHARACTER if any of the
    code units in the character are not valid UTF-8 code units. It returns
    -QERR_ILLEGAL_UTF8_LEAD_CHAR if the lead code unit given is a valid 
    UTF-8 code unit but not a lead character. If the source_units value
    is smaller than the number of code units in the character then
    -QERR_TRUNCATED_UTF8_CHAR is returned.

    Otherwise it returns a value between 1 and 4 according to the length 
    of the character. It tests the validity of all the code units comprising
    the character, up to source_units code units.

    Parameters:

    source       = the buffer containing the UTF-8 character.
    source_units = the maximum size in code units of the character. The
                   character may be shorter than this maximum.

    Return value:

    Returns the length in code units of the character.
    If an error occurs then a negative error code is returned.
*/
EXTERN t_int 
utf8_char_length(const t_utf8_char * source, size_t source_units);

/*
    Description:

    This function gets the length of the UTF-16 character by examining the
    lead code unit only. It returns -QERR_ILLEGAL_UTF16_CHARACTER if the lead
    code unit is not a valid UTF-16 code unit. It returns -QERR_ILLEGAL_UTF16_LEAD_CHAR
    if the lead code unit given is a valid UTF-16 code unit but not a lead
    character.

    Otherwise it returns a value between 1 and 2 according to the length 
    indicated by the lead code unit. It only tests the validity of the lead
    code unit. Subsequent code units are not validated.

    Parameters:

    source = the lead code unit used to determine the length of the UTF-16 character.

    Return value:

    Returns the length in code units indicated by the given lead code unit.
    If an error occurs then a negative error code is returned.
*/
EXTERN t_int
utf16_lead_char_length(t_utf16_char source);

/*
    Description:

    This function gets the length of the UTF-16 character by examining all
    the code units. It returns -QERR_ILLEGAL_UTF16_CHARACTER if any of the
    code units in the character are not valid UTF-16 code units. It returns
    -QERR_ILLEGAL_UTF16_LEAD_CHAR if the lead code unit given is a valid 
    UTF-16 code unit but not a lead character. If the source_units value
    is smaller than the number of code units in the character then
    -QERR_TRUNCATED_UTF16_CHAR is returned.

    Otherwise it returns a value between 1 and 2 according to the length 
    of the character. It tests the validity of all the code units comprising
    the character, up to source_units code units.

    Parameters:

    source       = the buffer containing the UTF-16 character.
    source_units = the maximum size in code units of the character. The
                   character may be shorter than this maximum.

    Return value:

    Returns the length in code units of the character.
    If an error occurs then a negative error code is returned.
*/
EXTERN t_int 
utf16_char_length(const t_utf16_char * source, size_t source_units);

/*
    Description:

    This function gets the length of the UTF-32 character by examining the
    code unit. It returns -QERR_ILLEGAL_UTF32_CHARACTER if the code unit
    is not a valid UTF-32 code unit. If the source_units value
    is smaller than the number of code units in the character then
    -QERR_TRUNCATED_UTF32_CHAR is returned.

    Otherwise it returns the value of 1.

    Parameters:

    source       = the buffer containing the UTF-32 character.
    source_units = the maximum size in code units of the character.

    Return value:

    Returns the length in code units of the character.
    If an error occurs then a negative error code is returned.
*/
EXTERN t_int 
utf32_char_length(const t_utf32_char * source, size_t source_units);

#define char_length     utf8_char_length

#if WCHAR_MAX < 0x0100 /* wchar_t is UTF-8 */
#define wchar_length    utf8_char_length
#elif WCHAR_MAX < 0x010000 /* wchar_t is UTF-16 */
#define wchar_length    utf16_char_length
#else /* wchar_t is UTF-32 */
#define wchar_length    utf32_char_length
#endif

/*
    Description:

    This function converts a UTF-32 character into a UTF-8 character.
    Since a UTF-8 character may take up to four code units (bytes), this
    function takes a destination buffer in which to store the UTF-8
    code units corresponding to the UTF-32 character.

    To ensure that this function succeeds, the UTF-32 character must
    be valid and the destination buffer must have at least four
    elements.

    Parameters:

    destination       = the buffer in which to store the UTF-8 character
    destination_units = the size of the buffer in code units (bytes)
    source            = the UTF-32 character to convert

    Return values:

    Returns the number of UTF-8 code units (bytes) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf32_char_to_utf8(t_utf8_char * destination, size_t destination_units, t_utf32_char source);

/*
    Description:

    This function converts a UTF-32 character into a UTF-16 character.
    Since a UTF-16 character may take up to two code units (words), this
    function takes a destination buffer in which to store the UTF-16
    code units corresponding to the UTF-32 character.

    To ensure that this function succeeds, the UTF-32 character must
    be valid and the destination buffer must have at least two
    elements.

    Parameters:

    destination       = the buffer in which to store the UTF-16 character
    destination_units = the size of the buffer in code units (words)
    source            = the UTF-32 character to convert

    Return values:

    Returns the number of UTF-16 code units (words) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf32_char_to_utf16(t_utf16_char * destination, size_t destination_units, t_utf32_char source);

/*
    Description:

    This function converts a UTF-32 character into a UTF-32 character.
    Since no conversion is necessary it simply checks the validity of
    the UTF-32 character and that destination_units > 0. If either
    check fails it returns a negative error code.

    This function is mainly provided in order to define the
    utf32_to_wchar macro and to have it behave consistently.

    Parameters:

    destination       = the buffer in which to store the UTF-32 character
    destination_units = the size of the buffer in code units (dwords)
    source            = the UTF-32 character to convert

    Return values:

    Returns the number of UTF-32 code units (dwords) stored in the destination
    buffer on success (always 1). Otherwise it returns a negative error code.
*/
EXTERN t_int
utf32_char_to_utf32(t_utf32_char * destination, size_t destination_units, t_utf32_char source);

/*
    Description:

    This function converts a UTF-8 character into a UTF-32 character.
    Since a UTF-8 character may take up to four code units (bytes), this
    function takes a source buffer as the UTF-8 character, whose size is
    specified by the source_units parameter. The destination is always
    a single UTF-32 code unit (dword) because UTF-32 characters are
    always one code unit (dword) in size.

    To ensure that this function succeeds, the UTF-8 character must
    be valid. Each code unit of the UTF-8 character is validated, up
    to source_units.

    Parameters:

    destination  = a pointer to a t_utf32_char in which to store the UTF-32 character
    source       = the buffer containing the UTF-8 character to convert
    source_units = the maximum size in code units (bytes) of the UTF-8 character. The
                   character may be shorter than this maximum.

    Return values:

    Returns the number of UTF-32 code units (dwords) stored in the destination
    buffer on success (always 1). Otherwise it returns a negative error code.
*/
EXTERN t_int
utf8_char_to_utf32(t_utf32_char * destination, const t_utf8_char * source, size_t source_units);

/*
    Description:

    This function converts a UTF-16 character into a UTF-32 character.
    Since a UTF-16 character may take up to two code units (words), this
    function takes a source buffer as the UTF-16 character, whose size is
    specified by the source_units parameter. The destination is always
    a single UTF-32 code unit (dword) because UTF-32 characters are
    always one code unit (dword) in size.

    To ensure that this function succeeds, the UTF-16 character must
    be valid. Each code unit of the UTF-16 character is validated, up
    to source_units.

    Parameters:

    destination  = a pointer to a t_utf32_char in which to store the UTF-32 character
    source       = the buffer containing the UTF-16 character to convert
    source_units = the maximum size in code units (words) of the UTF-16 character. The
                   character may be shorter than this maximum.

    Return values:

    Returns the number of UTF-32 code units (dwords) stored in the destination
    buffer on success (always 1). Otherwise it returns a negative error code.
*/
EXTERN t_int
utf16_char_to_utf32(t_utf32_char * destination, const t_utf16_char * source, size_t source_units);

/*
    Description:

    This function converts a UTF-8 character into a UTF-16 character.
    Since a UTF-8 character may take up to four code units (bytes), this
    function takes a source buffer as the UTF-8 character, whose size is
    specified by the source_units parameter. The destination is a
    UTF-16 character, which may take up to two code units (words). Hence,
    the destination is also a buffer, whose size in code units (words) is
    specified by the destination_units parameter.

    To ensure that this function succeeds, the UTF-8 character must
    be valid. Each code unit of the UTF-8 character is validated, up
    to source_units.

    Parameters:

    destination       = the buffer in which to store the UTF-16 character
    destination_units = the size of the buffer in code units (words)
    source            = the buffer containing the UTF-8 character to convert
    source_units      = the maximum size in code units (bytes) of the UTF-8 character. The
                        character may be shorter than this maximum.

    Return values:

    Returns the number of UTF-16 code units (words) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf8_char_to_utf16(t_utf16_char * destination, size_t destination_units, const t_utf8_char * source, size_t source_units);

/*
    Description:

    This function converts a UTF-16 character into a UTF-8 character.
    Since a UTF-16 character may take up to two code units (words), this
    function takes a source buffer as the UTF-16 character, whose size is
    specified by the source_units parameter. The destination is a
    UTF-8 character, which may take up to four code units (bytes). Hence,
    the destination is also a buffer, whose size in code units (bytes) is
    specified by the destination_units parameter.

    To ensure that this function succeeds, the UTF-16 character must
    be valid. Each code unit of the UTF-16 character is validated, up
    to source_units.

    Parameters:

    destination       = the buffer in which to store the UTF-8 character
    destination_units = the size of the buffer in code units (bytes)
    source            = the buffer containing the UTF-16 character to convert
    source_units      = the maximum size in code units (words) of the UTF-16 character. The
                        character may be shorter than this maximum.

    Return values:

    Returns the number of UTF-8 code units (bytes) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf16_char_to_utf8(t_utf8_char * destination, size_t destination_units, const t_utf16_char * source, size_t source_units);

/*
    Description:

    This function converts a UTF-16 character into a UTF-16 character.
    Since no conversion is necessary it simply checks the validity of
    the UTF-16 character and that destination_units > 0. If either
    check fails it returns a negative error code.

    This function is mainly provided in order to define the
    wchar_to_utf16 macro and to have it behave consistently.

    Parameters:

    destination       = the buffer in which to store the UTF-16 character
    destination_units = the size of the buffer in code units (words)
    source            = the buffer containing the UTF-16 character to convert
    source_units      = the maximum size in code units (words) of the UTF-16 character. The
                        character may be shorter than this maximum.

    Return values:

    Returns the number of UTF-16 code units (words) stored in the destination
    buffer on success (1 or 2). Otherwise it returns a negative error code.
*/
EXTERN t_int
utf16_char_to_utf16(t_utf16_char * destination, size_t destination_units, const t_utf16_char * source, size_t source_units);

#if WCHAR_MAX < 0x0100 /* wchar_t is UTF-8 */
#define wchar_to_utf8(destination, destination_units, source, source_units)  utf8_char_to_utf8(destination, destination_units, source, source_units)
#define wchar_to_utf16(destination, destination_units, source, source_units) utf8_char_to_utf16(destination, destination_units, source, source_units)
#define wchar_to_utf32(destination, destination_units, source, source_units) utf8_char_to_utf32(destination, source, source_units)
#define utf8_to_wchar(destination, destination_units, source, source_units)  utf8_char_to_utf8(destination, destination_units, source, source_units)
#define utf16_to_wchar(destination, destination_units, source, source_units) utf16_char_to_utf8(destination, destination_units, source, source_units)
#define utf32_to_wchar(destination, destination_units, source, source_units) utf32_char_to_utf8(destination, destination_units, source[0])
#elif WCHAR_MAX < 0x010000 /* wchar_t is UTF-16 */
#define wchar_to_utf8(destination, destination_units, source, source_units)  utf16_char_to_utf8(destination, destination_units, source, source_units)
#define wchar_to_utf16(destination, destination_units, source, source_units) utf16_char_to_utf16(destination, destination_units, source, source_units)
#define wchar_to_utf32(destination, destination_units, source, source_units) utf16_char_to_utf32(destination, source, source_units)
#define utf8_to_wchar(destination, destination_units, source, source_units)  utf8_char_to_utf16(destination, destination_units, source, source_units)
#define utf16_to_wchar(destination, destination_units, source, source_units) utf16_char_to_utf16(destination, destination_units, source, source_units)
#define utf32_to_wchar(destination, destination_units, source, source_units) utf32_char_to_utf16(destination, destination_units, source[0])
#else /* wchar_t is UTF-32 */
#define wchar_to_utf8(destination, destination_units, source, source_units) utf32_char_to_utf8(destination, destination_units, source[0])
#define wchar_to_utf16(destination, destination_units, source, source_units) utf32_char_to_utf16(destination, destination_units, source[0])
#define wchar_to_utf32(destination, destination_units, source, source_units) utf32_char_to_utf32(destination, destination_units, source[0])
#define utf8_to_wchar(destination, destination_units, source, source_units)  utf8_char_to_utf32(destination, source, source_units)
#define utf16_to_wchar(destination, destination_units, source, source_units) utf16_char_to_utf32(destination, source, source_units)
#define utf32_to_wchar(destination, destination_units, source, source_units) utf32_char_to_utf32(destination, 1, source[0])
#endif

/*
    Name: utf8_string_length_ex

    Description:
        This function returns the length of the string in code units and characters.
        It will not search beyond the maximum number of code units or the maximum number of characters
        specified by the max_units and max_characters arguments respectively. The terminating
        null character is not included in the length. Invalid characters are also not included
        in the length. The search stops at a null character or an invalid character.

        If the string length is determined successfully then 0 is returned. If an invalid character
        is encountered or a character occupying multiple code units is truncated by the max_units limit,
        or a parameter is invalid then a negative error code is returned. In the case of an invalid parameter, the
        string length in code units and characters will be set to 0. Otherwise the string lengths
        will be set according to the number of valid characters traversed.

        Up to 4 UTF-8 code units (bytes) may be required to represent a single Unicode character.

    Parameters:
        string         - the UTF-8 string whose length is being determined
        max_units      - the maximum number of code units the function will traverse in searching for the null terminator
        max_characters - the maximum number of characters the function will traverse in searching for the null terminator
        code_units     - the string length in code units. This parameter may be NULL.
        characters     - the string length in characters. This parameter may be NULL.

    Returns: 0 on success; a negative error code if a parameter is invalid, or an invalid character is encountered
             or a character truncated

    Author: Daniel R. Madill
    Date:   May 19, 2005
*/
EXTERN t_error 
utf8_string_length_ex(const t_utf8_char * string, size_t max_units, size_t max_characters, 
                      size_t * code_units, size_t * characters);

/*
    Name: utf16_string_length_ex

    Description:
        This function returns the length of the string in code units and characters.
        It will not search beyond the maximum number of code units or the maximum number of characters
        specified by the max_units and max_characters arguments respectively. The terminating
        null character is not included in the length. Invalid characters are also not included
        in the length. The search stops at a null character or an invalid character.

        If the string length is determined successfully then 0 is returned. If an invalid character
        is encountered or a character occupying multiple code units is truncated by the max_units limit,
        or a parameter is invalid then a negative error code is returned. In the case of an invalid parameter, the
        string length in code units and characters will be set to 0. Otherwise the string lengths
        will be set according to the number of valid characters traversed.

        Up to 2 UTF-16 code units (words) may be required to represent a single Unicode character.

    Parameters:
        string         - the UTF-16 string whose length is being determined
        max_units      - the maximum number of code units the function will traverse in searching for the null terminator
        max_characters - the maximum number of characters the function will traverse in searching for the null terminator
        code_units     - the string length in code units. This parameter may be NULL.
        characters     - the string length in characters. This parameter may be NULL.

    Returns: 0 on success; a negative error code if a parameter is invalid, or an invalid character is encountered
             or a character truncated

    Author: Daniel R. Madill
    Date:   May 19, 2005
*/
EXTERN t_error 
utf16_string_length_ex(const t_utf16_char * string, size_t max_units, size_t max_characters, 
                       size_t * code_units, size_t * characters);

/*
    Description:

    This function compares two strings for equality. It will not compare
    beyond the maximum_size in code units. The comparison is
    case-insensitive.

    *** NOTE: This function may belong in quanser_runtime because it makes use
              of the towupper() C library function!! ***

    Parameters:

    source       = the null-terminated dtring to compare
    maximum_size = the maximum number of code units to compare. This
                   parameter may be larger than the actual length of the strings
    comperand    = the string with which to compare

    Return values:

    Returns zero if the strings are not equal, and non-zero if the strings are equal.
    If maximum_size is zero then zero is returned regardless of the contents of the
    source and comperand strings.
*/
EXTERN t_boolean
utf16_string_equal_ignoring_case(const t_utf16_char* source, size_t maximum_size, const t_utf16_char* comperand);

/*
    Name: utf32_string_length_ex

    Description:
        This function returns the length of the string in code units and characters.
        It will not search beyond the maximum number of code units or the maximum number of characters
        specified by the max_units and max_characters arguments respectively. The terminating
        null character is not included in the length. Invalid characters are also not included
        in the length. The search stops at a null character or an invalid character.

        If the string length is determined successfully then 0 is returned. If an invalid character
        is encountered or a character occupying multiple code units is truncated by the max_units limit,
        or a parameter is invalid then a negative error code is returned. In the case of an invalid parameter, the
        string length in code units and characters will be set to 0. Otherwise the string lengths
        will be set according to the number of valid characters traversed.

        Only one UTF-32 code unit (dword) is required to represent a single Unicode character.

    Parameters:
        string         - the UTF-32 string whose length is being determined
        max_units      - the maximum number of code units the function will traverse in searching for the null terminator
        max_characters - the maximum number of characters the function will traverse in searching for the null terminator
        code_units     - the string length in code units. This parameter may be NULL.
        characters     - the string length in characters. This parameter may be NULL.

    Returns: 0 on success; a negative error code if a parameter is invalid, or an invalid character is encountered
             or a character truncated

    Author: Daniel R. Madill
    Date:   May 19, 2005
*/
EXTERN t_error 
utf32_string_length_ex(const t_utf32_char * string, size_t max_units, size_t max_characters, 
                       size_t * code_units, size_t * characters);

#define string_length_ex    utf8_string_length_ex

#if WCHAR_MAX < 0x0100 /* wchar_t is UTF-8 */
#define wstring_length_ex   utf8_string_length_ex
#elif WCHAR_MAX < 0x010000 /* wchar_t is UTF-16 */
#define wstring_length_ex   utf16_string_length_ex
#else /* wchar_t is UTF-32 */
#define wstring_length_ex   utf32_string_length_ex
#endif

/*
    Description:

    This function comparse two UTF-8 characters for equality. The arguments
    are strings because the function handles UTF-8 characters that span
    multiple code units.

    Parameters:

    left           = the left operand of the comparison
    max_code_units = the maximum number of code units to compare
    right          = the right operand of the comparison

    Return values:

    Returns the number of UTF-8 code units (bytes) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_boolean
utf8_char_equal(const t_utf8_char * left, size_t max_code_units, const t_utf8_char * right);

/*
    Description:

    This function comparse two UTF-16 characters for equality. The arguments
    are strings because the function handles UTF-16 characters that span
    multiple code units (surrogate pairs).

    Parameters:

    left           = the left operand of the comparison
    max_code_units = the maximum number of code units to compare
    right          = the right operand of the comparison

    Return values:

    Returns the number of UTF-16 code units (words) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_boolean
utf16_char_equal(const t_utf16_char * left, size_t max_code_units, const t_utf16_char * right);

/*
    Description:

    This function comparse two UTF-32 characters for equality. The arguments
    are strings because the function handles UTF-32 characters that span
    multiple code units (surrogate pairs).

    Parameters:

    left           = the left operand of the comparison
    max_code_units = the maximum number of code units to compare
    right          = the right operand of the comparison

    Return values:

    Returns the number of UTF-32 code units (words) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_boolean
utf32_char_equal(const t_utf32_char * left, size_t max_code_units, const t_utf32_char * right);

#if WCHAR_MAX < 0x0100 /* wchar_t is UTF-8 */
#define wchar_equal   utf8_char_equal
#elif WCHAR_MAX < 0x010000 /* wchar_t is UTF-16 */
#define wchar_equal   utf16_char_equal
#else /* wchar_t is UTF-32 */
#define wchar_equal   utf32_char_equal
#endif

/*
    Description:

    This function converts a UTF-8 string into a UTF-8 string. If the destination
    is NULL or the destination_units zero then it returns the number of UTF-8
    code units required to store the UTF-8 string, including the null terminator.
    This function is really just provided for the wstring_to_utf8 macro.
    
    To ensure that this function succeeds, each UTF-8 character in the string must
    be valid. Each code unit of the UTF-8 character is validated, up
    to source_units or the end of the string. If the character at source_units
    would be truncated then it is not included in the string and no error
    is generated.

    Parameters:

    destination       = the buffer in which to store the UTF-8 string
    destination_units = the size of the buffer in code units (bytes)
    source            = the buffer containing the UTF-8 character to convert
    source_units      = the maximum size in code units (words) of the UTF-8 string. The
                        string may be shorter than this maximum.

    Return values:

    Returns the number of UTF-8 code units (bytes) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf8_string_to_utf8(t_utf8_char * destination, size_t destination_units, const t_utf8_char * source, size_t source_units);

/*
    Description:

    This function converts a UTF-16 string into a UTF-8 string. If the destination
    is NULL or the destination_units zero then it returns the number of UTF-8
    code units required to store the UTF-8 string, including the null terminator.
    
    To ensure that this function succeeds, each UTF-16 character in the string must
    be valid. Each code unit of the UTF-16 character is validated, up
    to source_units or the end of the string. If the character at source_units
    would be truncated then it is not included in the string and no error
    is generated.

    Parameters:

    destination       = the buffer in which to store the UTF-8 string
    destination_units = the size of the buffer in code units (bytes)
    source            = the buffer containing the UTF-16 character to convert
    source_units      = the maximum size in code units (words) of the UTF-16 string. The
                        string may be shorter than this maximum.

    Return values:

    Returns the number of UTF-8 code units (bytes) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf16_string_to_utf8(t_utf8_char * destination, size_t destination_units, const t_utf16_char * source, size_t source_units);

/*
    Description:

    This function converts a UTF-32 string into a UTF-8 string. If the destination
    is NULL or the destination_units zero then it returns the number of UTF-8
    code units required to store the UTF-8 string, including the null terminator.
    
    To ensure that this function succeeds, each UTF-32 character in the string must
    be valid. Each code unit of the UTF-32 character is validated, up
    to source_units or the end of the string. If the character at source_units
    would be truncated then it is not included in the string and no error
    is generated.

    Parameters:

    destination       = the buffer in which to store the UTF-8 string
    destination_units = the size of the buffer in code units (bytes)
    source            = the buffer containing the UTF-32 character to convert
    source_units      = the maximum size in code units (words) of the UTF-32 string. The
                        string may be shorter than this maximum.

    Return values:

    Returns the number of UTF-8 code units (bytes) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf32_string_to_utf8(t_utf8_char * destination, size_t destination_units, const t_utf32_char * source, size_t source_units);

EXTERN t_int
utf8_string_to_utf16(t_utf16_char* destination, size_t destination_units, const t_utf8_char* source, size_t source_units);

EXTERN t_int
utf16_string_to_utf16(t_utf16_char* destination, size_t destination_units, const t_utf16_char* source, size_t source_units);

EXTERN t_int
utf32_string_to_utf16(t_utf16_char* destination, size_t destination_units, const t_utf32_char* source, size_t source_units);

#define string_to_utf8    utf8_string_to_utf8

#if WCHAR_MAX < 0x0100 /* wchar_t is UTF-8 */
#define wstring_to_utf8   utf8_string_to_utf8
#define wstring_to_utf16  utf8_string_to_utf16
#define wstring_to_utf32  utf8_string_to_utf32
#define utf8_to_wstring   utf8_string_to_utf8
#define utf16_to_wstring  utf16_string_to_utf8
#define utf32_to_wstring  utf32_string_to_utf8
#elif WCHAR_MAX < 0x010000 /* wchar_t is UTF-16 */
#define wstring_to_utf8   utf16_string_to_utf8
#define wstring_to_utf16  utf16_string_to_utf16
#define wstring_to_utf32  utf16_string_to_utf32
#define utf8_to_wstring   utf8_string_to_utf16
#define utf16_to_wstring  utf16_string_to_utf16
#define utf32_to_wstring  utf32_string_to_utf16
#else /* wchar_t is UTF-32 */
#define wstring_to_utf8   utf32_string_to_utf8
#define wstring_to_utf16  utf32_string_to_utf16
#define wstring_to_utf32  utf32_string_to_utf32
#define utf8_to_wstring   utf8_string_to_utf32
#define utf16_to_wstring  utf16_string_to_utf32
#define utf32_to_wstring  utf32_string_to_utf32
#endif

/*
    Description:

    This function converts a UTF-8 string into a UTF-8 string. It allocates the
    destination string using memory_allocate and returns a pointer to the buffer
    in the destination argument. This string must be freed with memory_free when
    no longer needed.
    
    To ensure that this function succeeds, each UTF-8 character in the string must
    be valid. Each code unit of the UTF-8 character is validated, up
    to source_units or the end of the string. If the character at source_units
    would be truncated then it is not included in the string and no error
    is generated.

    Parameters:

    destination       = outputs a pointer to the allocated buffer
    source            = the buffer containing the UTF-8 character to convert
    source_units      = the maximum size in code units (words) of the UTF-16 string. The
                        string may be shorter than this maximum.

    Return values:

    Returns the number of UTF-8 code units (bytes) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf8_string_to_allocated_utf8(t_utf8_char ** destination, const t_utf8_char * source, size_t source_units);

/*
    Description:

    This function converts a UTF-16 string into a UTF-8 string. It allocates the
    destination string using memory_allocate and returns a pointer to the buffer
    in the destination argument. This string must be freed with memory_free when
    no longer needed.
    
    To ensure that this function succeeds, each UTF-16 character in the string must
    be valid. Each code unit of the UTF-16 character is validated, up
    to source_units or the end of the string. If the character at source_units
    would be truncated then it is not included in the string and no error
    is generated.

    Parameters:

    destination       = outputs a pointer to the allocated buffer
    source            = the buffer containing the UTF-16 character to convert
    source_units      = the maximum size in code units (words) of the UTF-16 string. The
                        string may be shorter than this maximum.

    Return values:

    Returns the number of UTF-8 code units (bytes) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf16_string_to_allocated_utf8(t_utf8_char ** destination, const t_utf16_char * source, size_t source_units);

/*
    Description:

    This function converts a UTF-32 string into a UTF-8 string. It allocates the
    destination string using memory_allocate and returns a pointer to the buffer
    in the destination argument. This string must be freed with memory_free when
    no longer needed.
    
    To ensure that this function succeeds, each UTF-32 character in the string must
    be valid. Each code unit of the UTF-32 character is validated, up
    to source_units or the end of the string. If the character at source_units
    would be truncated then it is not included in the string and no error
    is generated.

    Parameters:

    destination       = outputs a pointer to the allocated buffer
    source            = the buffer containing the UTF-32 character to convert
    source_units      = the maximum size in code units (words) of the UTF-32 string. The
                        string may be shorter than this maximum.

    Return values:

    Returns the number of UTF-8 code units (bytes) stored in the destination
    buffer on success. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf32_string_to_allocated_utf8(t_utf8_char ** destination, const t_utf32_char * source, size_t source_units);

EXTERN t_int
utf8_string_to_allocated_utf16(t_utf16_char** destination, const t_utf8_char* source, size_t source_units);

EXTERN t_int
utf16_string_to_allocated_utf16(t_utf16_char** destination, const t_utf16_char* source, size_t source_units);

EXTERN t_int
utf32_string_to_allocated_utf16(t_utf16_char** destination, const t_utf32_char* source, size_t source_units);

#define string_to_allocated_utf8    utf8_string_to_allocated_utf8

#if WCHAR_MAX < 0x0100 /* wchar_t is UTF-8 */
#define wstring_to_allocated_utf8   utf8_string_to_allocated_utf8
#define utf16_to_allocated_wstring  utf16_string_to_allocated_utf8
#define string_to_allocated_wstring utf8_string_to_allocated_utf8
#elif WCHAR_MAX < 0x010000 /* wchar_t is UTF-16 */
#define wstring_to_allocated_utf8   utf16_string_to_allocated_utf8
#define utf16_to_allocated_wstring  utf16_string_to_allocated_utf16
#define string_to_allocated_wstring utf8_string_to_allocated_utf16
#else /* wchar_t is UTF-32 */
#define wstring_to_allocated_utf8   utf32_string_to_allocated_utf8
#define utf16_to_allocated_wstring  utf16_string_to_allocated_utf32
#define string_to_allocated_wstring utf8_string_to_allocated_utf32
#endif

/*
    Description:

    This function extracts a substring from a string based on a starting character
    position and a length in characters. It does NOT use code units for the
    position or length, but actual characters. For example, a Unicode character
    that takes four UTF-8 code units would count as a single character.

    The substring returned will always be null-terminated. If the starting character
    is out of range, then an empty string will be returned. If the length is
    such that it goes out of range then the substring will be truncated at
    the end of the string at a character boundary. The starting character position
    cannot be negative. If the length is zero then an empty string will be returned.

    Parameters:

    destination          = a pointer to the buffer in which to store the substring.
    destination_units    = the size of the destination buffer in code units (bytes).
    source               = the buffer containing the UTF-8 string from which to extract the
                           substring.
    source_units         = the maximum size in code units (bytes) of the UTF-8 source string.
                           The string may be shorter than this maximum.
    starting_character   = the character position at which to start extracting the substring.
                           It is the actual number of characters, not code units, from the
                           start of the string. A value of zero indicates the start of the
                           string.
    length_in_characters = the length in characters, not code units, of the substring to
                           extract.

    Return values:

    Returns the number of UTF-8 code units (bytes) stored in the destination
    buffer on success. This will typically be (length_in_characters + 1) because
    it includes the null terminator. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf8_get_substring(t_utf8_char * destination, size_t destination_units, const t_utf8_char * source, size_t source_units, size_t starting_character, size_t length_in_characters);

/*
    Description:

    This function extracts a substring from a string based on a starting character
    position and a length in characters. It does NOT use code units for the
    position or length, but actual characters. For example, a Unicode character
    that takes four UTF-16 code units would count as a single character.

    The substring returned will always be null-terminated. If the starting character
    is out of range, then an empty string will be returned. If the length is
    such that it goes out of range then the substring will be truncated at
    the end of the string at a character boundary. The starting character position
    cannot be negative. If the length is zero then an empty string will be returned.

    Parameters:

    destination          = a pointer to the buffer in which to store the substring.
    destination_units    = the size of the destination buffer in code units (bytes).
    source               = the buffer containing the UTF-16 string from which to extract the
                           substring.
    source_units         = the maximum size in code units (bytes) of the UTF-16 source string.
                           The string may be shorter than this maximum.
    starting_character   = the character position at which to start extracting the substring.
                           It is the actual number of characters, not code units, from the
                           start of the string. A value of zero indicates the start of the
                           string.
    length_in_characters = the length in characters, not code units, of the substring to
                           extract.

    Return values:

    Returns the number of UTF-16 code units (bytes) stored in the destination
    buffer on success. This will typically be (length_in_characters + 1) because
    it includes the null terminator. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf16_get_substring(t_utf16_char* destination, size_t destination_units, const t_utf16_char* source, size_t source_units, size_t starting_character, size_t length_in_characters);

/*
    Description:

    This function extracts a substring from a string based on a starting character
    position and a length in characters. It does NOT use code units for the
    position or length, but actual characters. For example, a Unicode character
    that takes four UTF-32 code units would count as a single character.

    The substring returned will always be null-terminated. If the starting character
    is out of range, then an empty string will be returned. If the length is
    such that it goes out of range then the substring will be truncated at
    the end of the string at a character boundary. The starting character position
    cannot be negative. If the length is zero then an empty string will be returned.

    Parameters:

    destination          = a pointer to the buffer in which to store the substring.
    destination_units    = the size of the destination buffer in code units (bytes).
    source               = the buffer containing the UTF-32 string from which to extract the
                           substring.
    source_units         = the maximum size in code units (bytes) of the UTF-32 source string.
                           The string may be shorter than this maximum.
    starting_character   = the character position at which to start extracting the substring.
                           It is the actual number of characters, not code units, from the
                           start of the string. A value of zero indicates the start of the
                           string.
    length_in_characters = the length in characters, not code units, of the substring to
                           extract.

    Return values:

    Returns the number of UTF-32 code units (bytes) stored in the destination
    buffer on success. This will typically be (length_in_characters + 1) because
    it includes the null terminator. Otherwise it returns a negative error code.
*/
EXTERN t_int
utf32_get_substring(t_utf32_char* destination, size_t destination_units, const t_utf32_char* source, size_t source_units, size_t starting_character, size_t length_in_characters);

#if WCHAR_MAX < 0x0100 /* wchar_t is UTF-8 */
#define wsubstring   utf8_substring
#elif WCHAR_MAX < 0x010000 /* wchar_t is UTF-16 */
#define wsubstring   utf16_substring
#else /* wchar_t is UTF-32 */
#define wsubstring   utf32_substring
#endif

/*
    Description:

    This function copies the source UTF-8 string to the destination string. It
    ensures that overflow of the destination string does not occur. The
    size of the destination string is specified in UTF-8 code units (bytes), not
    characters. The resulting string is always null-terminated. If the source string
    is longer than the destination_size then as much as possible is copied
    from the source string and the destination string is null terminated. In
    this case, -QERR_STRING_TOO_SMALL is returned.

    The results are undefined if the strings overlap.

    Unlike the string_copy function, this function only copies valid UTF-8
    characters from the source to the destination. The string is truncated
    at the first invalid or truncated UTF-8 character encountered. In this 
    case, an appropriate error is returned. However, the destination will
    be null-terminated.

    If the source argument is NULL then it returns -QERR_STRING_IS_NULL.

    Parameters:

    destination      = the UTF-8 string in which to copy the source
    destination_size = the size of the destination buffer in code units (bytes)
    source           = the null-terminated UTF-8 string to copy

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
utf8_string_copy_characters(t_utf8_char* destination, size_t destination_size, const t_utf8_char* source);

/*
    Description:

    This function copies the source UTF-16 string to the destination string. It
    ensures that overflow of the destination string does not occur. The
    size of the destination string is specified in UTF-16 code units (words), not 
    characters. The resulting string is always null-terminated. If the source string
    is longer than the destination_size then as much as possible is copied
    from the source string and the destination string is null terminated. In
    this case, -QERR_STRING_TOO_SMALL is returned.

    The results are undefined if the strings overlap.

    Unlike the string_copy function, this function only copies valid UTF-16
    characters from the source to the destination. The string is truncated
    at the first invalid or truncated UTF-16 character encountered. In this
    case, an appropriate error is returned. However, the destination will
    be null-terminated.

    If the source argument is NULL then it returns -QERR_STRING_IS_NULL.

    Parameters:

    destination      = the UTF-16 string in which to copy the source
    destination_size = the size of the destination buffer in code units (bytes)
    source           = the null-terminated UTF-16 string to copy

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
utf16_string_copy_characters(t_utf16_char* destination, size_t destination_size, const t_utf16_char* source);

/*
    Description:

    This function copies the source UTF-32 string to the destination string. It
    ensures that overflow of the destination string does not occur. The
    size of the destination string is specified in UTF-32 code units (dwords), not
    characters. The resulting string is always null-terminated. If the source string
    is longer than the destination_size then as much as possible is copied
    from the source string and the destination string is null terminated. In
    this case, -QERR_STRING_TOO_SMALL is returned.

    The results are undefined if the strings overlap.

    Unlike the string_copy function, this function only copies valid UTF-32
    characters from the source to the destination. The string is truncated
    at the first invalid or truncated UTF-32 character encountered. In this
    case, an appropriate error is returned. However, the destination will
    be null-terminated.

    If the source argument is NULL then it returns -QERR_STRING_IS_NULL.

    Parameters:

    destination      = the UTF-32 string in which to copy the source
    destination_size = the size of the destination buffer in code units (bytes)
    source           = the null-terminated UTF-32 string to copy

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
utf32_string_copy_characters(t_utf32_char* destination, size_t destination_size, const t_utf32_char* source);

#if WCHAR_MAX < 0x0100 /* wchar_t is UTF-8 */
#define wstring_copy_characters   utf8_string_copy_characters
#elif WCHAR_MAX < 0x010000 /* wchar_t is UTF-16 */
#define wstring_copy_characters   utf16_string_copy_characters
#else /* wchar_t is UTF-32 */
#define wstring_copy_characters   utf32_string_copy_characters
#endif

#endif
