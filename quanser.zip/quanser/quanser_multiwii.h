#if !defined(_quanser_multiwii_h)
#define _quanser_multiwii_h

#include "quanser_extern.h"
#include "quanser_types.h"
#include "quanser_stream.h"

#define MAX_MOTORS                  16
#define MAX_MOTOR_PINS              8
#define MAX_SERVO_CONFIGURATIONS    8
#define MAX_BOX_ITEMS               16
#define MAX_PID_ITEMS               10
#define MAX_RC_DATA                 16
#define MAX_NAME_LENGTH             255

typedef struct tag_multiwii * t_multiwii;

/*-------- Configuration --------*/

EXTERN t_error
multiwii_connect(const char * uri, t_boolean non_blocking, t_int send_buffer_size, t_int receive_buffer_size, t_multiwii * multiwii);

EXTERN t_error
multiwii_set_byte_order(t_multiwii multiwii, t_stream_byte_order byte_order);

EXTERN t_int
multiwii_poll(t_multiwii multiwii, const t_timeout * timeout, t_uint flags);

EXTERN t_error
multiwii_flush(t_multiwii multiwii);

EXTERN t_error
multiwii_shutdown(t_multiwii multiwii);

EXTERN t_error
multiwii_close(t_multiwii multiwii);

/*-------- Requests --------*/

EXTERN t_error
multiwii_get_identity(t_multiwii multiwii, t_uint8 * version, t_uint8 * multitype, t_uint8 * msp_version, t_uint32 * capability);

EXTERN t_error
multiwii_get_status(t_multiwii multiwii, t_uint16 * cycle_time, t_uint16 * i2c_errors_count, t_uint16 * sensor, t_uint32 * flag, t_uint8 * current_set);

EXTERN t_error
multiwii_get_raw_imu(t_multiwii multiwii, t_int16 acceleromter[3], t_int16 gyroscope[3], t_int16 magnetometer[3]);

EXTERN t_error
multiwii_get_servo(t_multiwii multiwii, t_uint16 * servo, t_uint8 length);

EXTERN t_error
multiwii_get_motor(t_multiwii multiwii, t_uint16 * motor, t_uint8 length);

EXTERN t_error
multiwii_get_rc(t_multiwii multiwii, t_uint16 * rc, t_uint8 length);

EXTERN t_error
multiwii_get_raw_gps(t_multiwii multiwii, t_uint8 * fix, t_uint8 * num_sat, t_uint32 coords[2], t_uint16 * altitude, t_uint16 * speed, t_uint16 * course);

EXTERN t_error
multiwii_get_computed_gps(t_multiwii multiwii, t_uint16 * distance, t_uint16 * direction, t_uint8 * update);

EXTERN t_error
multiwii_get_attitude(t_multiwii multiwii, t_int16 angles[2], t_int16 * heading);

EXTERN t_error
multiwii_get_altitude(t_multiwii multiwii, t_int32 * estimate, t_int16 * vario);

EXTERN t_error
multiwii_get_analog(t_multiwii multiwii, t_uint8 * vbat, t_uint16 * power, t_uint16 * rssi, t_uint16 * amperage);

EXTERN t_error
multiwii_get_rc_tuning(t_multiwii multiwii, t_uint8 * rc_rate, t_uint8 * rc_expo, t_uint8 * roll_rate, t_uint8 * yaw_rate, t_uint8 * dyn_pid, t_uint8 * throttle_mid, t_uint8 * throttle_expo);

EXTERN t_error
multiwii_get_pid_gains(t_multiwii multiwii, t_uint8 * proportional, t_uint8 * integral, t_uint8 * derivative, t_uint8 length);

EXTERN t_error
multiwii_get_box(t_multiwii multiwii, t_uint16 * box_items, t_uint8 length);

EXTERN t_error
multiwii_get_miscellaneous(t_multiwii multiwii, t_uint16 * power, t_uint16 throttle[4], t_uint16 * declination, t_uint8 * vbat_scale, t_uint8 vbat_level[3], t_uint16 * arm, t_uint32 * lifetime);

EXTERN t_error
multiwii_get_motor_pins(t_multiwii multiwii, t_uint8 * pins, t_uint8 length);

EXTERN t_error
multiwii_get_box_names(t_multiwii multiwii, char * names, t_uint16 length);

EXTERN t_error
multiwii_get_pid_names(t_multiwii multiwii, char * names, t_uint16 length);

EXTERN t_error
multiwii_get_waypoint(t_multiwii multiwii, t_uint8 * waypoint_num, t_uint32 coords[2], t_uint32 * altitude, t_uint16 * heading, t_uint16 * time_to_stay, t_uint8 * navigation_flag);

EXTERN t_error
multiwii_get_box_identifiers(t_multiwii multiwii, t_uint8 * ids, t_uint8 length);

EXTERN t_error
multiwii_get_servo_configuration(t_multiwii multiwii, t_uint16 * minimum, t_uint16 * maximum, t_uint16 * middle, t_uint8 * rate, t_uint8 length);

EXTERN t_error
multiwii_get_debug(t_multiwii multiwii, t_uint16 * debug, t_uint8 length);

/*-------- Commands --------*/

EXTERN t_error
multiwii_set_raw_rc(t_multiwii multiwii, const t_uint16 * rc_data, t_uint8 length);

EXTERN t_error
multiwii_set_raw_gps(t_multiwii multiwii, t_uint8 fix, t_uint8 num_sat, const t_uint32 coords[2], t_uint16 altitude, t_uint16 speed);

EXTERN t_error
multiwii_set_pid_gains(t_multiwii multiwii, const t_uint8 * proportional, const t_uint8 * integral, const t_uint8 * derivative, t_uint8 length);

EXTERN t_error
multiwii_set_box(t_multiwii multiwii, const t_uint16 * box_items, t_uint8 length);

EXTERN t_error
multiwii_set_rc_tuning(t_multiwii multiwii, t_uint8 rc_rate, t_uint8 rc_expo, t_uint8 roll_rate, t_uint8 yaw_rate, t_uint8 dyn_pid, t_uint8 throttle_mid, t_uint8 throttle_expo);

EXTERN t_error
multiwii_set_accelerometer_calibration(t_multiwii multiwii);

EXTERN t_error
multiwii_set_magnetometer_calibration(t_multiwii multiwii);

EXTERN t_error
multiwii_reset_configuration(t_multiwii multiwii);

EXTERN t_error
multiwii_bind(t_multiwii multiwii);

EXTERN t_error
multiwii_eeprom_write(t_multiwii multiwii);

EXTERN t_error
multiwii_set_miscellaneous(t_multiwii multiwii, t_uint16 power, const t_uint16 throttle[4], t_uint16 declination, t_uint8 vbat_scale, const t_uint8 vbat_level[3]);

EXTERN t_error
multiwii_set_waypoint(t_multiwii multiwii, t_uint8 waypoint_num, const t_uint32 coords[2], t_uint32 altitude, t_uint16 heading, t_uint16 time_to_stay, t_uint8 navigation_flag);

EXTERN t_error
multiwii_select_setting(t_multiwii multiwii, t_uint8 current_set);

EXTERN t_error
multiwii_set_heading_lock_reference(t_multiwii multiwii, t_int16 heading_lock);

EXTERN t_error
multiwii_set_servo_configuration(t_multiwii multiwii, const t_uint16 * minimum, const t_uint16 * maximum, const t_uint16 * middle, const t_uint8 * rate, t_uint8 length);

EXTERN t_error
multiwii_set_motor(t_multiwii multiwii, const t_uint16 * motor, t_uint8 length);

#endif
