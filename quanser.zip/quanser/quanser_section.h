#if !defined(_quanser_section_h)
#define _quanser_section_h

#include "quanser_extern.h"
#include "quanser_errors.h"
#include "quanser_types.h"

#if defined(_WIN32)

#include <windows.h>

#if defined(_MSC_VER) && (_MSC_VER <= 1100)

#include "quanser_inline.h"

INLINE void WINAPI InitializeCriticalSectionAndSpinCount(LPCRITICAL_SECTION critical_section, DWORD spin_count)
{
    InitializeCriticalSection(critical_section);
}

#endif

typedef struct tag_qthread_sectionattr
{
    int spin_count;
} qthread_sectionattr_t;

typedef CRITICAL_SECTION qthread_section_t;

#else

#include <pthread.h>

typedef pthread_mutexattr_t qthread_sectionattr_t;
typedef pthread_mutex_t     qthread_section_t;

#endif

EXTERN t_error
qthread_section_init(qthread_section_t * section, qthread_sectionattr_t * attributes);

EXTERN t_error
qthread_section_lock(qthread_section_t * section);

EXTERN t_error
qthread_section_unlock(qthread_section_t * section);

EXTERN t_error
qthread_section_destroy(qthread_section_t * section);

#endif
