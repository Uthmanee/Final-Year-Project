#if !defined(_quanser_byte_order_h)
#define _quanser_byte_order_h

#include "quanser_extern.h"

#if defined(__QNX__)

#include "quanser_types.h"

#if defined(__BIGENDIAN__)
    #define byte_order_is_big_endian() (true)
#else
    #define byte_order_is_big_endian() (false)
#endif

#else

EXTERN t_boolean
byte_order_is_big_endian(void);

#endif

/* Swap the bytes in the buffer */
EXTERN void
byte_order_swap(void * destination, int destination_size);

#endif
