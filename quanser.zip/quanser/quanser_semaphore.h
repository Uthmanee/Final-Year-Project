#if !defined(_quanser_semaphore_h)
#define _quanser_semaphore_h

#include "quanser_extern.h"
#include "quanser_errors.h"
#include "quanser_time.h"

#if defined(_WIN32)

#define INVALID_SEMAPHORE   NULL

typedef struct tag_qsem * qsem_t;

#elif defined(__vxworks)

#include <semLib.h>

typedef SEM_ID qsem_t;

#define INVALID_SEMAPHORE   NULL

#elif defined(__APPLE__)

typedef struct tag_qsem * qsem_t;

#define INVALID_SEMAPHORE   NULL

#else

#include <semaphore.h>

#if defined(__linux) || defined(__APPLE__)
#define INVALID_SEMAPHORE   SEM_FAILED
#else
#define INVALID_SEMAPHORE   (sem_t *)(-1)
#endif

typedef sem_t qsem_t;

#endif

/*
    Description:

    This function initializes a semaphore with the given initial value.
    The semaphore is not named and may not be shared between processes.
    
    If the semaphore count is zero, then an attempt to wait on the
    semaphore using qsem_wait will block. If the semaphore count
    is greater than zero then qsem_wait will not block. The qsem_wait
    operation decrements the semaphore count before returning.

    The semaphore count is incremented using qsem_post, which wakes
    up a thread waiting on the semaphore.

    The semaphore should be destroyed using qsem_destroy when it
    is no longer in use.

    Parameters:

    semaphore = a pointer to the qsem_t variable that is initialized
    value     = the initial value of the semaphore (typically 0).

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned.
*/
EXTERN t_error
qsem_init(qsem_t * semaphore, unsigned int value);

/*
    Description:

    This function opens a named semaphore. The semaphore may be shared
    between processes. 

    The name of the semaphore must begin with a leading '/' character.
    Also, to maximize compatibility, names longer than 14 characters should
    be avoided.

    If the semaphore count is zero, then an attempt to wait on the
    semaphore using qsem_wait will block. If the semaphore count
    is greater than zero then qsem_wait will not block. The qsem_wait
    operation decrements the semaphore count before returning.

    The semaphore count is incremented using qsem_post, which wakes
    up a thread waiting on the semaphore.

    The semaphore should be closed using qsem_close when it
    is no longer in use.

    Parameters:

    semaphore = a pointer to the qsem_t variable that is initialized
    name      = the name of the semaphore. It must begin with a '/' character.

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned.
*/
EXTERN t_error
qsem_open(qsem_t ** semaphore, const char * name);

/*
    Description:

    This function creates a named semaphore with the given initial value
    or opens a named semaphore. The semaphore may be shared between processes. 

    The name of the semaphore must begin with a leading '/' character.
    Also, to maximum compatibility, names longer than 14 characters should
    be avoided.

    If the exclusive argument is false then this function creates the
    named semaphore. If the named semaphore already exists then it simply
    opens the semaphore and the value argument is ignored. Otherwise the
    value argument is used to set the initial value of the semaphore.

    If the exclusive argument is true then this function
    only creates the named semaphore if it does not already exist.
    
    If the semaphore count is zero, then an attempt to wait on the
    semaphore using qsem_wait will block. If the semaphore count
    is greater than zero then qsem_wait will not block. The qsem_wait
    operation decrements the semaphore count before returning.

    The semaphore count is incremented using qsem_post, which wakes
    up a thread waiting on the semaphore.

    The semaphore should be closed using qsem_close when it
    is no longer in use.

    Parameters:

    semaphore = a pointer to the qsem_t variable that is initialized
    name      = the name of the semaphore. It must begin with a '/' character.
    exclusive = whether to create the semaphore if it already exists
    value     = the initial value of the semaphore (typically 0).

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned.
*/
EXTERN t_error
qsem_create(qsem_t ** semaphore, const char * name, t_boolean exclusive, unsigned int value);

/*
    Description:

    This function waits for the semaphore to be signalled. A semaphore
    is signalled when the semaphore count is greater than zero. If the
    semaphore count is non-zero then this function decrements the
    semaphore count and returns immediately. Otherwise it waits for the
    semaphore count to become non-zero. The sem_post function increments
    the semaphore count and wakes up a thread waiting on qsem_wait.

    The semaphore must be initialized by qsem_init before it is
    used for the first time.

    The qsem_wait function is a cancellation point. Hence, if
    qthread_cancel has been called for this thread then the thread
    will be cancelled when it reaches a qsem_wait call.
    
    Parameters:

    semaphore = a pointer to the qsem_t variable

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned.
*/
EXTERN t_error
qsem_wait(qsem_t * semaphore);

/*
    Description:

    This function tests whether the semaphore to be signalled. A semaphore
    is signalled when the semaphore count is greater than zero. If the
    semaphore count is non-zero then this function decrements the semaphore
    count and returns zero immediately. Otherwise it returns -QERR_TIMED_OUT.
    This function never blocks.

    The semaphore must be initialized by qsem_init before it is
    used for the first time.

    The qsem_trywait function is a not a cancellation point.
    
    Parameters:

    semaphore = a pointer to the qsem_t variable

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned.
*/
EXTERN t_error
qsem_trywait(qsem_t * semaphore);

/*
    Description:

    This function waits up to the specified timeout period for the
    semaphore to be signalled. A semaphore is signalled when the
    semaphore count is greater than zero. If the semaphore count is
    non-zero then this function decrements the semaphore count and
    returns immediately. Otherwise it waits for the semaphore count
    to become non-zero. The sem_post function increments the semaphore
    count and wakes up a thread waiting on qsem_wait. If the timeout
    interval expires before the semaphore is signalled then this
    function returns -QERR_TIMED_OUT and the semaphore count is
    left unchanged.

    The semaphore must be initialized by qsem_init before it is
    used for the first time.

    The qsem_timedwait function is a cancellation point. Hence, if
    qthread_cancel has been called for this thread then the thread
    will be cancelled when it reaches a qsem_timedwait call.
    
    Parameters:

    semaphore = a pointer to the qsem_t variable
    timeout   = a pointer to a t_timeout structure indicating the
                timeout interval

    Return value:

    Returns 0 on success. If the timeout occurs it returns -QERR_TIMED_OUT.
    If an error occurs then a negative error code is returned.

    Error codes:

    -QERR_TIMED_OUT = indicates that the semaphore count was zero and a
                      qsem_wait call would have blocked.
*/
EXTERN t_error
qsem_timedwait(qsem_t * semaphore, const t_timeout * timeout);

/*
    Description:

    This function "signals" the semaphore by incrementing the
    semaphore count and waking up any thread waiting on qsem_wait.
    The number of waiting threads awoken will equal the semaphore
    count after qsem_post.

    The semaphore must be initialized by qsem_init before it is
    used for the first time.

    The qsem_post function is not a cancellation point. On some
    operating systems, qsem_post is asynchronous signal safe. See
    the documentation for sem_post for the operating system for
    details. The qsem_post function is safe to call from a signal
    handler in Windows and RTX.
    
    Parameters:

    semaphore = a pointer to the qsem_t variable

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned.
*/
EXTERN t_error
qsem_post(qsem_t * semaphore);

/*
    Description:

    This function destroys the semaphore created by qsem_init.
    A semaphore cannot be used after it has been destroyed, unless
    it is reinitialized using qsem_init.

    Parameters:

    semaphore = a pointer to the qsem_t variable to destroy

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned.
*/
EXTERN t_error
qsem_destroy(qsem_t * semaphore);

/*
    Description:

    This function closes a named semaphore created by qsem_open.
    A named semaphore cannot be used after it has been closed.

    Parameters:

    semaphore = a pointer to the qsem_t variable to close

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned.
*/
EXTERN t_error
qsem_close(qsem_t * semaphore);

/*
    Description:

    This function removes a named semaphore from the namespace.
    A named semaphore cannot be opened after it has been unlinked,
    but semaphores that are already open are not affected.

    This function does nothing on operating systems that do not
    use the filesystem namespace for named semaphores, like RTX,
    INTime and Windows.

    Parameters:

    name = the name of the semaphore to unlink

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned.
*/
EXTERN t_error
qsem_unlink(const char * name);

#endif
