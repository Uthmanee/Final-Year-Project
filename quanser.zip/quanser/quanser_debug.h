#if !defined(_quanser_debug_h)
#define _quanser_debug_h

#include "quanser_inline.h"
#include "quanser_extern.h"
#include <stdarg.h>

#if !defined (__dsPIC30F__) && !defined (__dsPIC33F__) && !defined(__vxworks)
#include <wchar.h>
#endif

#if !defined(QUOTE)
#define QUOTE1(text)    # text
#define QUOTE(text)     QUOTE1(text)
#endif

/*
* This header file defines the following macros, which may be used for debugging.
* The macros invoke their debug functionality when the NDEBUG macro is not defined.
* When the NDEBUG macro is defined then they do not invoke their debug functionality.
* However, some of the macros still produce code, even in release. When they do so,
* this is documented.
* 
* debug_break()         
*   - causes the code to break into the debugger in debug mode.
*   - in release, this macro does nothing.
* 
* debug_heap()
*   - checks the heap in debug mode to ensure it is not corrupted.
*   - in release, this macro does nothing.
* 
* debug_assert(file, line, expression)
*   - in debug, if the expression evaluates to false then it prints an assertion
*     failure and breaks into the debugger. The file and line arguments should be
*     __FILE__ and __LINE__ respectively.
*   - in release, this macro does nothing.
*
* debug_assert_scope_begin(file, line, expression)
*   - in debug, if the expression evaluates to false then it prints an assertion
*     failure. Any addition code between debug_assert_scope_begin and debug_assert_scope_end
*     will also be executed. This code is typically debug_printf statements providing
*     more information about the assertion failure.
*   - in release, this macro does nothing. However, it must still be matched with a
*     debug_assert_scope_end() call.
* 
* debug_assert_scope_end()
*   - in debug, it terminates a debug_assert_scope_begin section of code. It will
*     break into the debugger after executing the scoped section if the expression
*     in debug_assert_scope_begin evaluated to false.
*   - in release, this macro does nothing.
* 
* verify_assert(file, line, expression)
*   - in debug, if the expression evaluates to false then it prints an assertion
*     failure and breaks into the debugger. The file and line arguments should be
*     __FILE__ and __LINE__ respectively.
*   - in release, it evaluates the expression but does not check for an assertion
*     failure.
*
* verify_assert2(file, line, expression, expected)
*   - in debug, if the expression does not evaluate to the given expected value,
*     then it prints an assertion failure and breaks into the debugger. The file 
*     and line arguments should be __FILE__ and __LINE__ respectively.
*   - in release, it evaluates the expression but does not check for an assertion
*     failure. The expected expression is not used in this case.
* 
* debug_trace(file, line, expression)
*   - in debug, it prints out the file name, line number and expression, and then
*     it evaluates the expression.
*   - in release, it simply evaluates the expression.
* 
* define debug_vprintf(format, arguments)
*   - in debug, it prints the formatted string using the given varargs, just like
*     vprintf.
*   - in release, this macro does nothing.
* 
* debug_printf(format, ...)
*   - in debug, it prints the formatted string using the given argument list, just like
*     printf.
*   - in release, this macro does nothing.
*
* debug_vwprintf(format, ...)
*   - in debug, it prints the wide formatted string using the given varargs, just like
*     vwprintf.
*   - in release, this macro does nothing.
*
* debug_wprintf(format, ...)
*   - in debug, it prints the wide formatted string using the given argument list, just like
*     wprintf.
*   - in release, this macro does nothing.
*/

#if !defined(NDEBUG)

    #if defined(UNDER_RTSS)

        #include <windows.h>
        #include <rtapi.h>

        #define debug_break() do { __asm int 3 } while(0)
        #define debug_heap() do { } while (0)

    #elif defined(__QNX__)

        #include <stdio.h>
        #include <sys/neutrino.h>
        #include <malloc.h>

        #define debug_break() DebugBreak()
        #define debug_heap()  mallopt(MALLOC_VERIFY, 1)

    #elif defined(__SOLARIS__) || defined(__linux) || defined(__INTIME__) || defined(__APPLE__) || defined(__vxworks)

        #include <stdio.h>

        #if defined(__INTIME__)
            #define debug_break() do { __asm int 3 } while(0)
            #define debug_heap()
        #elif defined(__APPLE__)
            //#include <CoreServices/CoreServices.h>
            //#define debug_break() Debugger() -- deprecated
            #define debug_break() do { __builtin_trap(); } while (0)
            #define debug_heap()
        #else
            #define debug_break()
            #define debug_heap()
        #endif

    #elif defined(_WIN32)

        #include <windows.h>
        #include <stdio.h>
        #if defined(_MSC_VER)
            #include <crtdbg.h>
        #endif

        #define debug_break() DebugBreak()
        #define debug_heap() do { } while (0)
/*
        #define debug_heap()                                             \
            do {                                                         \
                if (!(_CrtCheckMemory())) {                              \
                    debug_break();                                       \
                }                                                        \
            } while(0)
*/
    #endif  /* UNDER_RTSS */

    #define debug_assert(file, line, expression)                                             \
        do {                                                                                 \
            if (!(expression)) {                                                             \
                debug_printf("ASSERTION in %s at line %d: %s\n", file, line, QUOTE(expression));  \
                debug_break();                                                               \
            }                                                                                \
        } while(0)

    #define debug_assert_scope_begin(file, line, expression)                                 \
        do {                                                                                 \
            if (!(expression)) {                                                             \
                debug_printf("ASSERTION in %s at line %d: %s\n", file, line, QUOTE(expression));

    #define debug_assert_scope_end()                                                         \
                debug_break();                                                               \
            }                                                                                \
        } while(0)

    #define verify_assert(file, line, expression)            debug_assert(file, line, expression)
    #define verify_assert2(file, line, expression, expected) debug_assert(file, line, (expression) == (expected))

    #define debug_trace(file, line, expression)                         \
        do {                                                            \
            debug_printf("%s@%u: %s\n", file, line, QUOTE(expression)); \
            expression;                                                 \
        } while (0)

    EXTERN void debug_printf(const char * format, ...);
    EXTERN void debug_vprintf(const char * format, va_list arguments);

    #if !defined(__INTIME__) && !defined(__vxworks)
        EXTERN void debug_wprintf(const wchar_t * format, ...);
        EXTERN void debug_vwprintf(const wchar_t * format, va_list arguments);
    #endif

#else   /* NDEBUG */

    #if defined(UNDER_RTSS)
        #include <windows.h>
        #include <strsafe.h>
        #include <rtapi.h>
    #endif  /* UNDER_RTSS */

    #define debug_break()                           do {} while (0)
    #define debug_heap()                            do {} while (0)
    #define debug_assert(file, line, expression)    do {} while (0)

    #define debug_assert_scope_begin(file, line, expression) if (0) do {
    #define debug_assert_scope_end() } while (0)

    #define verify_assert(file, line, expression)            expression
    #define verify_assert2(file, line, expression, expected) expression

    #define debug_trace(file, line, expression) expression

    #define debug_vprintf(format, arguments)    do {} while (0)
    #define debug_printf(format, ...)           do {} while (0)
    #define debug_vwprintf(format, arguments)   do {} while (0)
    #define debug_wprintf(format, ...)          do {} while (0)

#endif  /* NDEBUG */

#ifdef _UNICODE
    #define _tdebug_printf debug_wprintf
#else
    #define _tdebug_printf debug_printf
#endif

#endif
