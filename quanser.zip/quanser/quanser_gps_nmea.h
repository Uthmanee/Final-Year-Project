

#if !defined(_QUANSER_GPS_NMEA_h)
#define _QUANSER_GPS_NMEA_h

#include "quanser_runtime.h"
#include "quanser_types.h"
#include "quanser_errors.h"
#include "quanser_thread.h"



typedef struct tag_gps_properties * t_gps_properties;

EXTERN t_error gps_open(t_gps_properties *gps, const char *uri, qthread_attr_t * attributes);
EXTERN t_error gps_close(t_gps_properties gps);
EXTERN t_error gps_read(t_gps_properties gps, t_boolean * valid, t_double * latitude, t_double * longitude, 
         t_boolean * lat_north, t_boolean * long_east, t_int * sat_count, t_double * pdop, t_double * hdop,
         t_double * heading_true, t_double * heading_magnetic, t_double * ground_speed);

#endif

