#if !defined(_quanser_optical_flow_h)
#define _quanser_optical_flow_h

#include "quanser_extern.h"
#include "quanser_errors.h"
#include "hil.h"

typedef enum tag_optical_flow_sensor_type
{
    OPTICAL_FLOW_SENSOR_TYPE_INVALID,        /* Invalid sensor type */
    OPTICAL_FLOW_SENSOR_TYPE_PMW3901,        /* Pimoroni PMW3901 optical flow sensor */

    NUMBER_OF_OPTICAL_FLOW_SENSOR_TYPES = OPTICAL_FLOW_SENSOR_TYPE_PMW3901
} t_optical_flow_sensor_type;

typedef struct tag_optical_flow_sensor * t_optical_flow_sensor;

/*
** Description:
**
**  Opens a PMW3901 optical flow sensor. The URI defines the communication protocol to use
**  to talk to the device. For example, a suitable URI for SPI port 0 would be:
**      spi://localhost:0?baud=4e6,word=8,lsb=no,polarity=1,phase=1
**  Note that the SPI CS should be connected to the digital output chosen as a CS pin. The
**  SPI CS pin cannot be used as the PMW3901 sensor uses non-standard SPI timing. Note that
**  the sensor cannot produce motion data at the same time as image frames.
**
** Parameters:
**
**  uri        = URI used to communicate with the sensor
**  card       = handle of opened HIL card. It must remain open until after pwm3901_close is called.
**  cs_pin     = digital output to use for CS pin. It must already be configured as a digital output.
**  read_image = whether to read images (true) instead of motion data (false).
**  sensor     = address of a t_optical_flow_sensor variable which will receive a handle to
**               the opened device.
**
** Returns:
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
pmw3901_open(const char* uri, t_card card, t_uint cs_pin, t_boolean read_image, t_optical_flow_sensor* sensor);

/*
** Description:
**
**  Reads the (x,y) motion detected since the last call. There are no units to
**  the returned delta (x,y) values because the values depend on the distance from
**  the surface in view of the sensor.
**
** Parameters:
**
**  sensor  = the t_optical_flow_sensor handled returned by pmw3901_open.
**  delta_x = the motion in the x-direction in ticks.
**  delta_y = the motion in the y-direction in ticks.
**
** Returns:
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
pmw3901_read_motion(t_optical_flow_sensor sensor, t_int16 * delta_x, t_int16 * delta_y);

/*
** Description:
**
**  Reads the 35x35 image from the sensor's camera. The pixels array must be
**  35x35 = 1225 bytes in size.
**
** Parameters:
**
**  sensor  = the t_optical_flow_sensor handled returned by pmw3901_open.
**  pixels  = a 35x35 t_uint8 array to receive the image frame.
**
** Returns:
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
pmw3901_read_image(t_optical_flow_sensor sensor, t_uint8 * pixels);

/*
** Description:
**
**  Closes the PMW3901 device.
**
** Parameters:
**
**  sensor  = the t_optical_flow_sensor handled returned by pmw3901_open.
**
** Returns:
**  Returns zero on success and a negative error code otherwise.
*/
EXTERN t_error
pmw3901_close(t_optical_flow_sensor sensor);

#endif

