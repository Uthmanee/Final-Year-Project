#if !defined(_hil_simulation_h)
#define _hil_simulation_h

#include "quanser_extern.h"
#include "quanser_errors.h"
#include "quanser_time.h"
#include "hil.h"

/*
** A HIL simulation is essentially a user-defined HIL proxy server. It allows a HIL board to be simulated
** so that it acts just like a real card when accessed from the HIL SDK. The simulated board is accessed
** the same way the HIL proxy server is accessed: by adding a URI to the board identifier. For example,
** if the HIL simulation of a Q8 card is serving on the URI: shmem://hil_sim:1 then the following hil_open
** call will access the simulation instead of the real card:
**      result = hil_open("q8", "0@shmem://hil_sim:1");
** It is mainly used for making simulations in Simulink because a HIL card could always be simulated by
** creating a HIL driver for the simulated card. The HIL Simulation interface handles listening as a proxy
** server and tracks the various I/O.
*/
typedef struct tag_hil_simulation * t_hil_simulation;

typedef struct tag_hil_simulation_parameters
{
    /* Board being simulated */
    const char * board_type;
    const char * board_identifier;

    /* Sample time at which hil_sim_read_write will be called. This value is used to simulate hardware timebases and the watchdog */
    t_double sample_time;

    /* Size of structure (for future expansion) */
    t_uint structure_size;

    /* Channel information */
    const t_uint * other_input_channels;            /* valid other input channel numbers */
    const t_uint * other_output_channels;           /* valid other output channel numbers */

    t_uint num_analog_inputs;                       /* number of analog input channels (0..N-1) */
    t_uint num_encoder_inputs;                      /* number of encoder input channels (0..N-1) */
    t_uint num_digital_inputs;                      /* number of digital input only channels (NIO..NIO+N-1)*/
    t_uint num_other_inputs;                        /* number of other input channels (channels numbers in other_input_channels array) */

    t_uint num_analog_outputs;                      /* number of analog output channels (0..N-1) */
    t_uint num_pwm_outputs;                         /* number of PWM output channels (0..N-1) */
    t_uint num_digital_outputs;                     /* number of digital output only channels (NIO..NIO+N-1) */
    t_uint num_digital_io;                          /* number of bidirectional digital I/O channels (0..NIO-1) */
    t_uint num_other_outputs;                       /* number of other output channels (channel numbers in other_output_channels array) */

    /* Number of clocks and interrupt sources */
    t_uint num_clocks;                              /* number of clocks */
    t_uint num_interrupts;                          /* number of interrupt sources */

    /* Board-specific options */
    const char* options;                            /* template for board-specific options e.g. speed=%d;max_fps=%d[10,120];period=%f;gyro_rate=%f[0.1,100.0];gains=%f(0.1|1.0|10.0);polarity=%b;parity=%d(none|even|odd|mark|space);update=%d(slow=10|normal=7|fast=0); */

    /* Number of properties (do not include standard number of channel properties) */
    t_hil_integer_property * integer_get_properties;/* valid integer property codes */
    t_hil_double_property * double_get_properties;  /* valid double property codes */
    t_hil_string_property * string_get_properties;  /* valid string property codes */

    t_uint num_integer_get_properties;              /* number of elements in integer_get_properties array */
    t_uint num_double_get_properties;               /* number of elements in double_get_properties array */
    t_uint num_string_get_properties;               /* number of elements in string_get_properties array */

    t_hil_integer_property* integer_set_properties;/* valid integer property codes */
    t_hil_double_property* double_set_properties;  /* valid double property codes */
    t_hil_string_property* string_set_properties;  /* valid string property codes */

    t_uint num_integer_set_properties;              /* number of elements in integer_set_properties array */
    t_uint num_double_set_properties;               /* number of elements in double_set_properties array */
    t_uint num_string_set_properties;               /* number of elements in string_set_properties array */

    /* Initial values which will be output from block until first client connects */
    const t_double  * initial_analog_outputs;       /* initial analog output values (array of num_analog_outputs elements) */
    const t_double  * initial_pwm_outputs;          /* initial PWM output values (array of num_pwm_outputs elements) */
    const t_boolean * initial_digital_outputs;      /* initial digital output values (array of num_digital_io + num_digital_outputs elements) */
    const t_double  * initial_other_outputs;        /* initial other output values (array of num_other_outputs elements) */

    /* Initial property values which will be output from block until first client connects */
    const t_int*    initial_integer_set_properties; /* initial integer property values (array of num_integer_properties elements) */
    const t_double* initial_double_set_properties;  /* initial double property values (array of num_double_properties elements) */
    const char**    initial_string_set_properties;  /* initial string property values (array of num_string_properties elements) */

} t_hil_simulation_parameters;

typedef struct tag_hil_simulation_option
{
    const char* name;       /* name of option. Only valid while t_hil_simulation instance is valid */
    const char* format;     /* format specifier for option e.g. %f. Only valid while t_hil_simulation instance is valid */

    union tag_hil_simulation_option_value
    {
        t_timeout t;        /* used if format[1] == 't' */
        t_double d;         /* used if format[1] == 'f' */
        t_int i;            /* used if format[1] == 'd' */
        t_boolean b;        /* used if format[1] == 'b' */
    } value;

} t_hil_simulation_option;

typedef char* t_char_ptr;

EXTERN t_error
hil_sim_open(const char * uri, const t_hil_simulation_parameters * parameters, t_hil_simulation * simulation);

EXTERN t_error
hil_sim_read_write(t_hil_simulation simulation,
                   const t_uint32 analog_input_channels[],  t_uint32 num_analog_input_channels,
                   const t_uint32 encoder_input_channels[], t_uint32 num_encoder_input_channels,
                   const t_uint32 digital_input_lines[],    t_uint32 num_digital_input_lines,
                   const t_uint32 other_input_channels[],   t_uint32 num_other_input_channels,

                   const t_uint32 analog_output_channels[],  t_uint32 num_analog_output_channels,
                   const t_uint32 pwm_output_channels[],     t_uint32 num_pwm_output_channels,
                   const t_uint32 digital_output_lines[],    t_uint32 num_digital_output_lines,
                   const t_uint32 other_output_channels[],   t_uint32 num_other_output_channels,

                   const t_double  analog_input_buffer[],
                   const t_int32   encoder_input_buffer[],
                   const t_boolean digital_input_buffer[],
                   const t_double  other_input_buffer[],

                   t_double  analog_output_buffer[],
                   t_double  pwm_output_buffer[],
                   t_boolean digital_output_buffer[],
                   t_double  other_output_buffer[]
);

EXTERN t_error
hil_sim_get_set_properties(t_hil_simulation simulation,
    const t_hil_integer_property integer_get_property_codes[], t_uint32 num_integer_get_property_codes,
    const t_hil_double_property  double_get_property_codes[], t_uint32 num_double_get_property_codes,
    const t_hil_string_property  string_get_property_codes[], t_uint32 num_string_get_property_codes,

    const t_hil_integer_property integer_set_property_codes[], t_uint32 num_integer_set_property_codes,
    const t_hil_double_property  double_set_property_codes[], t_uint32 num_double_set_property_codes,
    const t_hil_string_property  string_set_property_codes[], t_uint32 num_string_set_property_codes,

    const t_int32 integer_get_properties[],
    const t_double double_get_properties[],
    const char* string_get_properties[],
    const t_uint32 string_get_property_lengths[],

    t_int32 integer_set_properties[],
    t_double double_set_properties[],
    char* string_set_properties[],
    t_uint32 string_set_property_lengths[]
);

/*
** Get the current values of the card-specific options for the simulated card. The options array will be filled in
** the same order as the options appeared in the options field of the hil_sim_open call's parameters argument. It
** returns the number of options actually copied into the array. If num_options is zero then it returns the number
** of options that are available.
*/
EXTERN t_int
hil_sim_get_card_specific_options(t_hil_simulation simulation, t_hil_simulation_option* options, t_uint num_options);

/*
** Get the number of clients currently connected to the HIL simulation. It returns zero if no clients
** are connected.
*/
EXTERN t_int
hil_sim_get_number_of_connections(t_hil_simulation simulation);

/*
** Close the HIL simulation.
*/
EXTERN t_error
hil_sim_close(t_hil_simulation simulation);

#endif
