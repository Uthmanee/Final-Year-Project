#if !defined(_quanser_start_time_h)
#define _quanser_start_time_h

#include "quanser_extern.h"
#include "quanser_time.h"

EXTERN t_timeout _high_resolution_start_time;   /* common reference point for the absolute time at which the model started */

#endif


