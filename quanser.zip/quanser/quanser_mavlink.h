#if !defined(_quanser_mavlink_h)
#define _quanser_mavlink_h

#include "quanser_extern.h"
#include "quanser_types.h"
#include "quanser_stream.h"

typedef struct tag_mavlink * t_mavlink;

/*
** Metadata associated with every Mavlink packet
*/
typedef struct tag_mavlink_packet_metadata
{
    t_uint32 message_id;
    t_uint8 payload_length;
    t_uint8 incompatible;
    t_uint8 compatible;
    t_uint8 sequence;
    t_uint8 system_id;
    t_uint8 component_id;
} t_mavlink_packet_metadata;

/*
** The status of a Mavlink connection.
*/
typedef enum tag_mavlink_connection_status
{
    MAVLINK_STATUS_NOT_CONNECTED,
    MAVLINK_STATUS_CONNECTING,
    MAVLINK_STATUS_CONNECTED
} t_mavlink_connection_status;

#define MAVLINK_LISTEN_STATUS_NOT_LISTENING     MAVLINK_STATUS_NOT_CONNECTED
#define MAVLINK_LISTEN_STATUS_LISTENING         MAVLINK_STATUS_CONNECTING
#define MAVLINK_LISTEN_STATUS_CONNECTED         MAVLINK_STATUS_CONNECTED

#define MAVLINK_CONNECT_STATUS_NOT_CONNECTED    MAVLINK_STATUS_NOT_CONNECTED
#define MAVLINK_CONNECT_STATUS_CONNECTING       MAVLINK_STATUS_CONNECTING
#define MAVLINK_CONNECT_STATUS_CONNECTED        MAVLINK_STATUS_CONNECTED

/*
** Information about Mavlink messages needed for packet processing.
*/
typedef struct tag_mavlink_message_entry {
	t_uint32 message_id;                /* message identifier */
	t_uint8 crc_extra;                  /* extra CRC byte used in computing checksum */
	t_uint8 min_payload_length;         /* minimum length of the message payload in bytes (size of base fields without extension fields) */
	t_uint8 flags;                      /* bitmask of MAVLINK_ENTRY_FLAG_XXX flags */
	t_uint8 target_system_offset;       /* offset in bytes of target_system field in message payload */
	t_uint8 target_component_offset;    /* offset in bytes of target_component field in message payload */
} t_mavlink_message_entry;

#define MAVLINK_ENTRY_FLAG_TARGET_SYSTEM    (1 << 0)    /* set if message contains a target_system field */
#define MAVLINK_ENTRY_FLAG_TARGET_COMPONENT (1 << 1)    /* set if message contains a target_component field */

/*
** Flags for configuring the Mavlink connection.
*/
#define MAVLINK_FLAG_USE_MAVLINK_AUTO   (0 << 0)    /* start sending Mavlink 1 packets but switch to Mavlink 2 if flight controller supports it */
#define MAVLINK_FLAG_USE_MAVLINK_1      (1 << 0)    /* always send Mavlink 1 packets unless Mavlink 2 necessary (e.g. message ID > 255) */
#define MAVLINK_FLAG_USE_MAVLINK_2      (2 << 0)    /* always send Mavlink 2 packets */
#define MAVLINK_FLAG_USE_MAVLINK_MASK   (3 << 0)    /* bitmask to mask off USE_MAVLINK value */

/*-------- Configuration --------*/

EXTERN t_error
mavlink_connect(const char * uri, t_int send_buffer_size, t_int receive_buffer_size, const t_mavlink_message_entry * message_details, t_uint num_details, t_uint flags, t_mavlink * mavlink);

EXTERN t_error
mavlink_listen(const char * uri, t_int send_buffer_size, t_int receive_buffer_size, const t_mavlink_message_entry * message_details, t_uint num_details, t_uint flags, t_mavlink * mavlink);

EXTERN t_error
mavlink_get_connection_status(t_mavlink mavlink, t_mavlink_connection_status * status);

EXTERN t_error
mavlink_get_connection_error(t_mavlink mavlink);

EXTERN t_int
mavlink_poll(t_mavlink mavlink, const t_timeout * timeout, t_uint flags);

EXTERN t_error
mavlink_flush(t_mavlink mavlink);

EXTERN t_error
mavlink_shutdown(t_mavlink mavlink);

EXTERN t_error
mavlink_close(t_mavlink mavlink);

/*-------- Requests --------*/

/*
** Returns the most recent packet received with the given message_id. The packet has already been validated by its start byte,
** checksum and optional signature. Only the metadata and the payload are returned. The payload_length must reflect the number of
** bytes in the payload array. This array will be zero-padded if the actual payload length is smaller.
*/
EXTERN t_error
mavlink_receive_packet(t_mavlink mavlink, t_uint8 system_id, t_uint8 component_id, t_uint32 message_id, t_mavlink_packet_metadata * metadata, t_uint8 * payload, t_uint8 payload_length);

/*-------- Commands --------*/

/*
** Sends a Mavlink packet to the flight controller. The payload_length in the metadata must reflect the number of bytes in the payload array.
** The sequence number in the metadata is ignored as it is automatically generated.
*/
EXTERN t_error
mavlink_send_packet(t_mavlink mavlink, t_uint8 target_system_id, t_uint8 target_component_id, const t_mavlink_packet_metadata * metadata, const t_uint8 * payload);

#endif
