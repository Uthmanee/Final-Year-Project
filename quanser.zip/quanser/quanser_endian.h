#if !defined(_quanser_endian_h)
#define _quanser_endian_h

#if defined(_M_IX86) || defined(_M_IA64) || defined(_M_X64) || defined(__X86__)
#define IS_LITTLE_ENDIAN	1
#else
#define IS_BIG_ENDIAN		1
#endif

#endif
