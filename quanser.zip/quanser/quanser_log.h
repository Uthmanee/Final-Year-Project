#if !defined(_quanser_log_h)
#define _quanser_log_h

#include "quanser_runtime.h"
#include "quanser_errors.h"
#include "quanser_inline.h"
#include "quanser_arguments.h"
#include <stdarg.h>

typedef struct tag_log * t_log;

typedef enum tag_log_priority
{
    LOG_PRIORITY_ERROR,
    LOG_PRIORITY_WARNING,
    LOG_PRIORITY_INFORMATION
} t_log_priority;

EXTERN t_error
log_open(t_log * log, const char * name);

EXTERN t_error
log_wopen(t_log * log, const wchar_t * name);

EXTERN t_error
log_vprintf(t_log log, t_log_priority priority, const char * format, va_list arguments);

EXTERN t_error
log_vwprintf(t_log log, t_log_priority priority, const wchar_t * format, va_list arguments);

EXTERN t_error
log_printf(t_log log, t_log_priority priority, const char * format, ...);

EXTERN t_error
log_wprintf(t_log log, t_log_priority priority, const wchar_t * format, ...);

#if defined(_DEBUG)

INLINE t_error
log_debug_printf(t_log log, t_log_priority priority, const char * format, ...)
{
    va_list arguments;
    t_error result;

    va_start(arguments, format);
    result = log_vprintf(log, priority, format, arguments);
    va_end(arguments);
    return result;
}

INLINE t_error
log_debug_wprintf(t_log log, t_log_priority priority, const wchar_t * format, ...)
{
    va_list arguments;
    t_error result;

    va_start(arguments, format);
    result = log_vwprintf(log, priority, format, arguments);
    va_end(arguments);
    return result;
}

#else

INLINE t_error
log_debug_printf(t_log log, t_log_priority priority, const char * format, ...)
{
    UNUSED_ARGUMENT(log);
    UNUSED_ARGUMENT(priority);
    UNUSED_ARGUMENT(format);

    return 0;
}

INLINE t_error
log_debug_wprintf(t_log log, t_log_priority priority, const wchar_t * format, ...)
{
    UNUSED_ARGUMENT(log);
    UNUSED_ARGUMENT(priority);
    UNUSED_ARGUMENT(format);

    return 0;
}

#endif

#if defined(_UNICODE)

#define _tlog_open(log, name)                           log_wopen(log, name)
#define _tlog_vprintf(log, priority, format, arguments) log_vwprintf(log, priority, format, arguments)
#define _tlog_printf                                    log_wprintf
#define _tlog_debug_printf                              log_debug_wprintf

#else

#define _tlog_open(log, name)                           log_open(log, name)
#define _tlog_vprintf(log, priority, format, arguments) log_vprintf(log, priority, format, arguments)
#define _tlog_printf                                    log_printf
#define _tlog_debug_printf                              log_debug_printf

#endif

EXTERN t_error
log_close(t_log log);

#endif
