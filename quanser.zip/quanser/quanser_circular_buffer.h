#if !defined(_quanser_circular_buffer_h)
#define _quanser_circular_buffer_h

#include "quanser_time.h"

typedef struct tag_circular_buffer * t_circular_buffer;
typedef struct tag_circular_buffer_array* t_circular_buffer_array;

/*
    Description:

    This function creates a circular buffer. The buffer is multithread-safe.
    It protects access to the buffer from multiple threads. Call circular_buffer_free
    to free the resources for the buffer.

    Parameters:

    circular_buffer      = the address of a t_circular_buffer handle which will be initialized upon successful return
    circular_buffer_size = the size of the circular buffer in bytes

    Return values:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
circular_buffer_create(t_circular_buffer * circular_buffer, t_int circular_buffer_size);

/*
    Description:

    This function reads from the circular buffer. If the amount of data requested is not available
    then it will wait up to the timeout period for the data to become available. If the timeout
    argument is NULL then it will wait indefinitely. If the timeout argument is a relative time
    of zero seconds then it will poll the buffer without blocking. If the timeout occurs then
    0 is returned. If the data is successfully read from the buffer then the data is removed from
    the circular buffer and 1 is returned. If an error occurs then a negative error code is
    returned.

    To read the most recent data only, there are two options. The most typical is to create
    a buffer of exactly the number of bytes required for a single read operation and then
    set the overwrite flag to true when writing to the buffer. In this manner, the write
    operation overwrites the previous value each time and the read will get the latest data.
    A second option, when sometimes all the data is required, is to read in a loop with a
    timeout of zero seconds. When the read finally returns 0 then the buffer has been emptied
    and the data returned is the most recent.

    This function is a cancellation point.

    Parameters:

    circular_buffer = the t_circular_buffer handle of the circular buffer
    data            = a buffer in which to store the data read. It must be at least length bytes.
    length          = the number of bytes to read from the buffer.
    timeout         = a timeout. May be relative or absolute. If this parameter is NULL it will
                      wait indefinitely for data to become available.

    Return values:

    Returns 1 on success and 0 if the timeout occurs. Otherwise it returns a negative error code.
*/
EXTERN t_int
circular_buffer_read(t_circular_buffer circular_buffer, void * data, t_int length, const t_timeout * timeout);

/*
    Description:

    This function reads whatever data is available from the circular buffer, up to the maximum
    number of bytes specified. If no data is available, then it will wait up to the timeout period
    for data to become available. If the timeout argument is NULL then it will wait indefinitely.
    If the timeout argument is a relative time of zero seconds then it will poll the buffers without
    blocking. If the timeout occurs then 0 is returned. If the data is successfully read from the
    buffer then the data is removed from the circular buffer and the number of bytes read
    is returned. If an error occurs then a negative error code is returned.

    This function is a cancellation point.

    Parameters:

    circular_buffer = the t_circular_buffer handle of the circular buffer
    data            = a pointer to the buffer in which to store the data read.
                      The buffer must be at least max_length bytes.
    max_length      = the maximum number of bytes to read from the buffer.
    timeout         = a timeout. May be relative or absolute. If this parameter is NULL it will
                      wait indefinitely for at least one byte to become available.

    Return values:

    Returns the number of bytes read on success and 0 if the timeout occurs. Otherwise it returns a negative error code.
*/
EXTERN t_int
circular_buffer_read_available(t_circular_buffer circular_buffer, void * data, t_int max_length, const t_timeout * timeout);

/*
    Description:

    This function writes to the circular buffer. If space for the amount of data provided is not available
    then it will wait up to the timeout period for the requisite space to become available. If the timeout
    argument is NULL then it will wait indefinitely. If the timeout argument is a relative time
    of zero seconds then it will write to the buffer without blocking, if space is available. 
    
    If the timeout occurs then it returns 0. However, what this function does to the buffer in this case
    depends on the overwrite flag. If the overwrite flag is false, then the buffer is left untouched and
    the data is not written to the buffer. If the overwrite flag is true, then old data in the buffer is
    overwritten. In either case 0 is returned, notifying the caller that the timeout occurred.

    If the data is successfully written to the buffer prior to the timeout then the data is added to
    the circular buffer and 1 is returned. If an error occurs then a negative error code is
    returned.

    This function is a cancellation point.

    Parameters:

    circular_buffer = the t_circular_buffer handle of the circular buffer
    data            = a buffer containing the data to write. It must be at least length bytes.
    length          = the number of bytes to write to the buffer.
    timeout         = a timeout. May be relative or absolute. If this parameter is NULL it will
                      wait indefinitely for space to become available.
    overwrite       = whether to overwrite the oldest data in the buffer when no space is available

    Return values:

    Returns 1 on success and 0 if the timeout occurs. Otherwise it returns a negative error code.
*/
EXTERN t_int
circular_buffer_write(t_circular_buffer circular_buffer, const void * data, t_int length, const t_timeout * timeout, t_boolean overwrite);

/*
    Description:

    This function clears the circular buffer so that the buffer becomes empty.

    Parameters:

    circular_buffer = the t_circular_buffer handle of the circular buffer

    Return values:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
circular_buffer_clear(t_circular_buffer circular_buffer);

/*
    Description:

    This function indicates whether the circular buffer contains new data
    or not. A buffer is considered to contain new data when data has been
    written, but the data has not yet been read i.e. when the buffer is not
    empty.

    Parameters:

    circular_buffer = the t_circular_buffer handle of the circular buffer

    Return values:

    Returns true if the buffer contains data. Otherwise it returns false.
*/
EXTERN t_boolean
circular_buffer_has_new_data(t_circular_buffer circular_buffer);


/*
    Description:

    This function waits for at least the number of bytes specified to be available
    in the circular buffer.

    Parameters:

    circular_buffer = the t_circular_buffer handle of the circular buffer
    length          = the number of bytes for which to wait.
    timeout         = the maximum amount of time to wait

    Return values:

    Returns true if the buffer contains the given amount of data. Otherwise it returns false.
*/
EXTERN t_error
circular_buffer_wait(t_circular_buffer circular_buffer, t_int length, const t_timeout* timeout);

/*
    Description:

    This function frees the circular buffer.

    Parameters:

    circular_buffer = the t_circular_buffer handle of the circular buffer

    Return values:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
circular_buffer_free(t_circular_buffer circular_buffer);

/*
    Description:

    This function creates an array of circular buffers. The buffers are multithread-safe.
    It protects access to the buffers from multiple threads. Call circular_buffer_array_free
    to free the resources for the buffers.

    Multiple arrays, all indexed by the same indices, are used in situations where we have
    non-interleaved data, such as multiple audio channels, that we want to write to a
    circular buffer but do not want to interleave so that more efficient memory transfers
    may be used yet the amount of data written to the buffer and read from the buffer can
    be different.

    Parameters:

    circular_buffer      = the address of a t_circular_buffer handle which will be initialized upon successful return
    circular_buffer_size = the size of the circular buffer in bytes
    num_buffers          = the number of buffers

    Return values:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
circular_buffer_array_create(t_circular_buffer_array* circular_buffer, t_int circular_buffer_size, t_uint num_buffers);

/*
    Description:

    This function reads from the circular buffer array. If the amount of data requested is not available
    then it will wait up to the timeout period for the data to become available. If the timeout
    argument is NULL then it will wait indefinitely. If the timeout argument is a relative time
    of zero seconds then it will poll the buffers without blocking. If the timeout occurs then
    0 is returned. If the data is successfully read from the buffers then the data is removed from
    the circular buffer array and 1 is returned. If an error occurs then a negative error code is
    returned.

    To read the most recent data only, there are two options. The most typical is to create
    a buffer of exactly the number of bytes required for a single read operation and then
    set the overwrite flag to true when writing to the buffer. In this manner, the write
    operation overwrites the previous value each time and the read will get the latest data.
    A second option, when sometimes all the data is required, is to read in a loop with a
    timeout of zero seconds. When the read finally returns 0 then the buffer has been emptied
    and the data returned is the most recent.

    This function is a cancellation point.

    Parameters:

    circular_buffer = the t_circular_buffer_array handle of the circular buffer array
    data            = an array of pointers to the buffers in which to store the data read.
                      Each buffer in the array must be at least length bytes.
    length          = the number of bytes to read from the buffers.
    timeout         = a timeout. May be relative or absolute. If this parameter is NULL it will
                      wait indefinitely for data to become available.

    Return values:

    Returns 1 on success and 0 if the timeout occurs. Otherwise it returns a negative error code.
*/
EXTERN t_int
circular_buffer_array_read(t_circular_buffer_array circular_buffer, void** data, t_int length, const t_timeout* timeout);

/*
    Description:

    This function reads whatever data is available from the circular buffer array, up to the maximum
    number of bytes specified. If no data is available, then it will wait up to the timeout period
    for data to become available. If the timeout argument is NULL then it will wait indefinitely.
    If the timeout argument is a relative time of zero seconds then it will poll the buffers without
    blocking. If the timeout occurs then 0 is returned. If the data is successfully read from the
    buffers then the data is removed from the circular buffer array and the number of bytes read
    is returned. If an error occurs then a negative error code is returned.

    This function is a cancellation point.

    Parameters:

    circular_buffer = the t_circular_buffer_array handle of the circular buffer array
    data            = an array of pointers to the buffers in which to store the data read.
                      Each buffer in the array must be at least max_length bytes.
    max_length      = the maximum number of bytes to read from the buffers.
    timeout         = a timeout. May be relative or absolute. If this parameter is NULL it will
                      wait indefinitely for at least one byte to become available.

    Return values:

    Returns the number of bytes read on success and 0 if the timeout occurs. Otherwise it returns a negative error code.
*/
EXTERN t_int
circular_buffer_array_read_available(t_circular_buffer_array circular_buffer, void** data, t_int max_length, const t_timeout* timeout);

/*
    Description:

    This function writes to the circular buffer array. If space for the amount of data provided is not available
    then it will wait up to the timeout period for the requisite space to become available. If the timeout
    argument is NULL then it will wait indefinitely. If the timeout argument is a relative time
    of zero seconds then it will write to the buffers without blocking, if space is available.

    If the timeout occurs then it returns 0. However, what this function does to the buffers in this case
    depends on the overwrite flag. If the overwrite flag is false, then the buffers are left untouched and
    the data is not written to the buffers. If the overwrite flag is true, then old data in the buffers is
    overwritten. In either case 0 is returned, notifying the caller that the timeout occurred.

    If the data is successfully written to the buffers prior to the timeout then the data is added to
    the circular buffer array and 1 is returned. If an error occurs then a negative error code is
    returned.

    This function is a cancellation point.

    Parameters:

    circular_buffer = the t_circular_buffer_array handle of the circular buffer array
    data            = an array of pointers containing the data to write. Each buffers must be at least length bytes.
    length          = the number of bytes to write to the circular buffer.
    timeout         = a timeout. May be relative or absolute. If this parameter is NULL it will
                      wait indefinitely for space to become available.
    overwrite       = whether to overwrite the oldest data in the buffer when no space is available

    Return values:

    Returns 1 on success and 0 if the timeout occurs. Otherwise it returns a negative error code.
*/
EXTERN t_int
circular_buffer_array_write(t_circular_buffer_array circular_buffer, const void** data, t_int length, const t_timeout* timeout, t_boolean overwrite);

/*
    Description:

    This function clears the circular buffer array so that the buffers become empty.

    Parameters:

    circular_buffer = the t_circular_buffer_array handle of the circular buffer array

    Return values:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
circular_buffer_array_clear(t_circular_buffer_array circular_buffer);

/*
    Description:

    This function indicates whether the circular buffer array contains new data
    or not. A buffer is considered to contain new data when data has been
    written, but the data has not yet been read i.e. when the buffer is not
    empty.

    Parameters:

    circular_buffer = the t_circular_buffer_array handle of the circular buffer array

    Return values:

    Returns true if the buffer array contains data. Otherwise it returns false.
*/
EXTERN t_boolean
circular_buffer_array_has_new_data(t_circular_buffer_array circular_buffer);

/*
    Description:

    This function waits for at least the number of bytes specified to be available
    in each buffer of the circular buffer array.

    Parameters:

    circular_buffer = the t_circular_buffer_array handle of the circular buffer array
    length          = the number of bytes for which to wait.
    timeout         = the maximum amount of time to wait

    Return values:

    Returns true if the buffer array contains the given amount of data in each buffer
    of the circular buffer array. Otherwise it returns false.
*/
EXTERN t_error
circular_buffer_array_wait(t_circular_buffer_array circular_buffer, t_int length, const t_timeout * timeout);

/*
    Description:

    This function frees the circular buffer.

    Parameters:

    circular_buffer = the t_circular_buffer_array handle of the circular buffer array

    Return values:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
circular_buffer_array_free(t_circular_buffer_array circular_buffer);

#endif
