#if !defined(_quanser_arguments_h)
#define _quanser_arguments_h

#define UNUSED_ARGUMENT(x)  (void)(x)

#endif /* QUANSER_ARGUMENTS_H */
