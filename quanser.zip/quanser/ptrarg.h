/*
 *  ptrarg.h
 *
 *  Defines the "pointer argument list" datatype, which is analogous to the "variable argument list", va_list, 
 *  data type, but is strictly an array of pointers. The pa_list type is used for Quanser Stream API functions
 *  which end in "P", and allow argument lists to be constructed dynamically.
 *
 *  Created by Daniel Madill on 01/05/10.
 *  Copyright 2010 Quanser. All rights reserved.
 */

#if !defined(_ptrarg_h)
#define _ptrarg_h

typedef void ** pa_list;   /* Pointer to an array of arguments' addresses (either the address of a scalar or the address of the first element of an array) */

#define pa_arg(/* pa_list */ arguments, datatype)                   (*(datatype *) ((arguments)++))
#define pa_copy(/* pa_list */ destination, /* pa_list */ source)    do { (destination) = (source); } while (0)

#endif
