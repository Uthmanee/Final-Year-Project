#if !defined(_quanser_hash_h)
#define _quanser_hash_h

#include "quanser_extern.h"
#include "quanser_types.h"

typedef struct tag_md5 * t_md5;

/*
** Computes a Fowler / Noll / Vo (FNV) hash producing a 32-bit unsigned integer.
*/
EXTERN t_uint32
hash_fnv_compute_uint32(const void * key, t_uint key_length);

/*
** Computes a Fowler / Noll / Vo (FNV) hash producing a 64-bit unsigned integer.
*/
EXTERN t_uint64
hash_fnv_compute_uint64(const void * key, t_uint key_length);

/*
** Compute a MD5 hash producing a 128-bit byte stream.
**
** This function should be used when the entire data to be hashed are contained in the data.
** For hashing data that cannot fit into one chunk of memory (e.g. hashing of an entire file),
** use the hash_md5_compute_u128_init(), hash_md5_compute_u128_update(),
** hash_md5_compute_u128_final(), and hash_md5_compute_u128_cleanup() functions.
*/
EXTERN t_error
hash_md5_compute_u128(const void * data, t_uint data_length, t_uint8 hash[16]);

/*
** Initialize a MD5 hashing context.
** Typical usage is as follows:
**
**      t_md5 md5_ctx;
**      t_uint8 hash1[16];
**      t_uint8 hash2[16];
**      char  msg1_submsg1_to_encode[] = "my_test_msg1_submsg1";
**      char  msg1_submsg2_to_encode[] = "my_test_msg1_submsg2";
**      char  msg2_submsg1_to_encode[] = "my_test_msg2_submsg1";
**      char  msg2_submsg2_to_encode[] = "my_test_msg2_submsg2";
**
**      hash_md5_compute_u128_init(&md5_ctx);
**
**      // repeatedly call the hash_md5_compute_u128_update to add more data to be hashed.
**      hash_md5_compute_u128_update(md5_ctx, msg1_submsg1_to_encode, sizeof(msg1_submsg1_to_encode));
**      hash_md5_compute_u128_update(md5_ctx, msg1_submsg2_to_encode, sizeof(msg1_submsg2_to_encode));
**
**      // The hash for msg1_submsg1_to_encode plus msg1_submsg2_to_encode are now in hash1
**      hash_md5_compute_u128_final(md5_ctx, hash1);
**      
**      // repeatedly call the hash_md5_compute_u128_update to add more data to be hashed.
**      hash_md5_compute_u128_update(md5_ctx, msg2_submsg1_to_encode, sizeof(msg2_submsg1_to_encode));
**      hash_md5_compute_u128_update(md5_ctx, msg2_submsg2_to_encode, sizeof(msg2_submsg2_to_encode));
**
**      // The hash for msg2_submsg1_to_encode plus msg2_submsg2_to_encode are now in hash2
**      hash_md5_compute_u128_final(md5_ctx, hash2);
**
**      hash_md5_compute_u128_cleanup(md5_ctx);
*/
EXTERN t_error
hash_md5_compute_u128_init(t_md5 *md5_ctx);

/*
** Feed in data to the md5_ctx context that was created using hash_md5_compute_u128_init() to create
** the hash for the data.
*/
EXTERN t_error
hash_md5_compute_u128_update(t_md5 md5_ctx, const void * data, t_uint data_length);

/*
** Return the hash value in "hash".
** Note that once this function is called, the hash would be "closed". Do not call it again until
** after feeding in new data using hash_md5_compute_u128_update(), then a new hash will be created
** based on the data fed into hash_md5_compute_u128_update().
*/
EXTERN t_error
hash_md5_compute_u128_final(t_md5 md5_ctx, t_uint8 hash[16]);

/* Clean up the md5_ctx once hashing is no longer needed.
*/
EXTERN void
hash_md5_compute_u128_cleanup(t_md5 md5_ctx);

#endif
