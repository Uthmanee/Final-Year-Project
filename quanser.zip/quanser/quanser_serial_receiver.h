#if !defined(_quanser_serial_receiver_h)
#define _quanser_serial_receiver_h

#include "quanser_extern.h"
#include "quanser_errors.h"
#include "quanser_thread.h"

/*--- Serial Receiver ---*/

typedef enum tag_serial_receiver_protocol
{
    SERIAL_RECEIVER_DSMX,
    SERIAL_RECEIVER_DSM2,
    SERIAL_RECEIVER_DSMX_OR_DSM2,                   /* only valid if external = false */
    
    SERIAL_RECEIVER_SBUS1,
    SERIAL_RECEIVER_SBUS2,
    SERIAL_RECEIVER_SBUS1_OR_SBUS2,

    NUMBER_OF_SERIAL_RECEIVER_PROTOCOLS
} t_serial_receiver_protocol;

typedef enum tag_serial_receiver_state
{
    SERIAL_RECEIVER_STATE_NOT_CONNECTED,  /* no stream connected */
    SERIAL_RECEIVER_STATE_CLOSING,        /* stream is closing */
    SERIAL_RECEIVER_STATE_CONNECTING,     /* stream_connect has been called in non-blocking mode */
    SERIAL_RECEIVER_STATE_CONNECTED,      /* stream is connected */
    SERIAL_RECEIVER_STATE_ACTIVE,         /* stream is connected and packets are being received within the expected time for the protocol selected */

    NUMBER_OF_SERIAL_RECEIVER_STATES
} t_serial_receiver_state;

typedef struct tag_serial_receiver_parameters
{
    size_t size;
    t_serial_receiver_protocol protocol;

    union tag_serial_receiver_protocol_parameters
    {
        struct tag_dsm_receiver_parameters
        {
            t_boolean external;                 /* whether the remote is internal (0) or external (1) */
        } dsm;

        struct tag_sbus_receiver_parameters
        {
            t_uint8 * synchronization_bytes;    /* choices for synchronization bytes (may be NULL) */
            t_uint num_synchronization_bytes;   /* number of choices for synchronization bytes */
        } sbus;
    } info;

} t_serial_receiver_parameters;

typedef struct tag_serial_receiver_data
{
    t_uint interval;            /* very rough measure of the interval between packets (in nanoseconds) */
    t_uint maximum;             /* maximum channel value for the protocol detected (useful for scaling channel values) */

    union tag_serial_receiver_protocol_data
    {
        struct tag_dsm_receiver_data
        {
            t_uint16 fades;     /* number of missed frames */
            t_uint8 system;     /* protocol selected (0x01=DSM2 22ms, 0x12=DSM2 11ms, 0xA2=DSMX 22ms, 0xB2=DSMX 11ms) */
            t_uint16 phases;    /* bitmask, one bit per channel */
        } dsm;

        struct tag_sbus_receiver_data
        {
            t_uint8 flags;
        } sbus;
    } data;
} t_serial_receiver_data;

typedef struct tag_serial_receiver * t_serial_receiver;

EXTERN t_error
serial_receiver_open(const char * uri, qthread_attr_t * thread_attributes, const t_serial_receiver_parameters * parameters, t_serial_receiver * receiver);

EXTERN t_error
serial_receiver_read(t_serial_receiver receiver, t_uint16 channels[16], t_boolean valid[16], t_serial_receiver_data * extra);

EXTERN t_error
serial_receiver_get_state(t_serial_receiver receiver, t_serial_receiver_state * state);

EXTERN t_error
serial_receiver_close(t_serial_receiver receiver);

/*--- Serial Transmitter (emulates the signals sent to a serial receiver) ---*/

typedef enum tag_serial_transmitter_protocol
{
    SERIAL_TRANSMITTER_DSMX,
    SERIAL_TRANSMITTER_DSM2,
    SERIAL_TRANSMITTER_SBUS1,
    SERIAL_TRANSMITTER_SBUS2,

    NUMBER_OF_SERIAL_TRANSMITTER_PROTOCOLS
} t_serial_transmitter_protocol;

typedef struct tag_serial_transmitter_parameters
{
    size_t size;
    t_serial_transmitter_protocol protocol;     /* protocol to emulate */
    t_uint interval;                            /* interval between packets (in nanoseconds) */

    union tag_serial_transmitter_protocol_parameters
    {
        struct tag_dsm_transmitter_parameters
        {
            t_boolean external;     /* whether the remote is internal (0) or external (1) */
        } dsm;
    } info;

} t_serial_transmitter_parameters;

typedef struct tag_serial_transmitter_data
{
    union tag_serial_transmitter_protocol_data
    {
        struct tag_dsm_transmitter_data
        {
            t_uint16 fades;     /* number of missed frames */
            t_uint16 phases;    /* bitmask, one bit per channel */
        } dsm;

        struct tag_sbus_transmitter_data
        {
            t_uint8 synchronization;    /* synchronization byte */
            t_uint8 flags;              /* flags byte */
            t_uint8 telemetry;          /* telemetry (end) byte */
        } sbus;
    } data;
} t_serial_transmitter_data;

typedef struct tag_serial_transmitter * t_serial_transmitter;

EXTERN t_error
serial_transmitter_open(const char * uri, qthread_attr_t * thread_attributes, const t_serial_transmitter_parameters * parameters, t_serial_transmitter * transmitter);

EXTERN t_error
serial_transmitter_write(t_serial_transmitter transmitter, const t_uint16 channels[16], const t_boolean valid[16], const t_serial_transmitter_data * extra);

EXTERN t_error
serial_transmitter_get_state(t_serial_transmitter transmitter, t_serial_receiver_state * state);

EXTERN t_error
serial_transmitter_close(t_serial_transmitter transmitter);

#endif
