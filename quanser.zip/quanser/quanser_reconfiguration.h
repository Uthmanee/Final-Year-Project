#if !defined(_quanser_reconfiguration_h)
#define _quanser_reconfiguration_h

#include "quanser_extern.h"
#include "quanser_errors.h"

/* Maximum length of a state name (see namelengthmax in Matlab) */
#define MAX_STATE_NAME  63

typedef struct tag_reconfiguration * t_reconfiguration;
typedef struct tag_reconfiguration_state * t_reconfiguration_state;

/*
    Description:

    This function opens a dynamic reconfiguration instance.
    This instance is required for supporting dynamic reconfiguration.
    Dynamic reconfiguration is the ability to switch from one
    running model to another, on the fly, in real-time. The outgoing
    model is referred to as "switching out" and the incoming model
    is referred to as "switching in".
    
    Each model belongs to a "reconfiguration group". Reconfiguration
    groups are identified by a positive integer number. The default
    reconfiguration group is group 0. Models are identified for
    switching out by their reconfiguration group, not by name, in
    order to reduce the complexity of systems in which the model
    currently running may not be known (or is a nuisance to keep
    track of) but needs to be replaced with a new model.

    By default, the reconfiguration_open function returns a
    reconfiguration instance that is marked as neither switching in
    nor switching out, and belonging to the default reconfiguration
    group (group id 0). However, this does not mean that the model
    cannot be dynamically switched out - it can - and the
    reconfiguration_is_switching_out() function will indicate whether
    another model is trying to switch out the current model.

    The reconfiguration instance must be closed when no longer
    in use via reconfiguration_close.

    Parameters:

    reconfiguration = a pointer to a t_reconfiguration variable in
                      which the reconfiguration handle will be stored.
                      This handle is required by all the other
                      reconfiguration functions. It should be closed
                      using reconfiguration_close when it is no
                      longer required.

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
reconfiguration_open(t_reconfiguration * reconfiguration);

/*
    Description:

    This function allows the reconfiguration group identifier
    of the current reconfiguration instance to be changed. This
    function is typically called when a "-reconfig <reconfig id>"
    command-line option is specified, indicating that this model
    should belong to the specified reconfiguration group. It may
    also be called in MdlStart when a Reconfiguration block is
    present in a Simulink diagram.

    The reconfiguration group of this instance may only be set
    prior to calling reconfiguration_begin_control.

    Parameters:

    reconfiguration       = the reconfiguration handle returned by
                            reconfiguration_open
    reconfiguration_group = the new reconfiguration group

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
reconfiguration_set_group(t_reconfiguration reconfiguration, t_uint reconfiguration_group);

/*
    Description:

    This function allows the current model to be marked as
    switching in. This function is typically called when
    a "-switch <reconfig id>" command-line option is specified
    indicating that this model is switching in, and a model
    in the given reconfiguration group should be switched out.

    The switching state of this instance may only be set
    prior to calling reconfiguration_begin_control.

    Parameters:

    reconfiguration       = the reconfiguration handle returned by
                            reconfiguration_open
    reconfiguration_group = the reconfiguration group of the model to
                            switch out.
    is_switching_in       = whether to mark this instance as switching
                            in (true) or not (false).

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
reconfiguration_set_switching_in(t_reconfiguration reconfiguration, t_uint reconfiguration_group, t_boolean is_switching_in);

/*
    Description:

    This function returns true if the current instance is
    switching in. Otherwise it returns false.

    Parameters:

    reconfiguration = the reconfiguration handle returned by
                      reconfiguration_open

    Return values:

    Returns true is model is switching in and false otherwise.
*/
EXTERN t_boolean
reconfiguration_is_switching_in(t_reconfiguration reconfiguration);

/*
    Description:

    This function returns true if the current instance is
    switching out. Otherwise it returns false. This function
    should be polled within the control loop to determine
    whether the model is being switched out. If it returns
    true then the control loop should be exited and
    reconfiguration_end_control called.

    Parameters:

    reconfiguration = the reconfiguration handle returned by
                      reconfiguration_open

    Return values:

    Returns true is model is switching out and false otherwise.
*/
EXTERN t_boolean
reconfiguration_is_switching_out(t_reconfiguration reconfiguration);

/*
    Description:

    This function should be called as the control loop of the
    model is entered. If the model is being switched in then it
    ensures a smooth transfer of control from the outgoing model
    to this model. If this function returns successfully then
    reconfiguration_end_control must be called as the control
    loop of the model is exited.

    Parameters:

    reconfiguration = the reconfiguration handle returned by
                      reconfiguration_open

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
reconfiguration_begin_control(t_reconfiguration reconfiguration);

/*
    Description:

    This function should be called as the control loop of the
    model exits. If the model is being switched out then it
    ensures a smooth transfer of control from this model to the
    incoming model.

    Parameters:

    reconfiguration = the reconfiguration handle returned by
                      reconfiguration_open

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
reconfiguration_end_control(t_reconfiguration reconfiguration);

/*
    Description:

    This function closes the reconfiguration instance. It
    releases any resources required for supporting dynamic
    reconfiguration.

    Parameters:

    reconfiguration = the reconfiguration handle returned by
                      reconfiguration_open

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
reconfiguration_close(t_reconfiguration reconfiguration);

/*
    Description:

    This function registers a state variable by name. The
    data type and size of the state variable are also specified
    to avoid unexpected conflicts between states. The state
    variable is set to a handle identifying the state.

    Parameters:

    state_name   = the name of the state
    data_type_id = the data type of the state
    num_bytes    = the number of bytes needed to store the state
    state        = a pointer to a t_reconfiguration_state variable
                   which will hold a handle to the state

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
reconfiguration_register_state(const char * state_name, t_int data_type_id, size_t num_bytes, t_reconfiguration_state * state);

/*
    Description:

    This function gets the value of a state. The value
    is retrieved atomically. The size of the buffer must match the
    number of bytes in the state.

    Parameters:

    state       = the handle to the state returned by
                  reconfiguration_register_state
    buffer      = the buffer in which to store the state
    buffer_size = the size of the buffer in bytes

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
reconfiguration_get_state(t_reconfiguration_state state, void * buffer, size_t buffer_size);

/*
    Description:

    This function sets the value of a state. The value is
    set atomically. The size of the buffer must match the
    number of bytes in the state.

    Parameters:

    state       = the handle to the state returned by
                  reconfiguration_register_state
    buffer      = the buffer containing the value of the state
    buffer_size = the size of the buffer in bytes

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
reconfiguration_set_state(t_reconfiguration_state state, const void * buffer, size_t buffer_size);

/*
    Description:

    This function unregisters a state variable. The state
    information is destroyed after the all processes have
    unregistered the state.

    Parameters:

    state       = the handle to the state returned by
                  reconfiguration_register_state

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
reconfiguration_unregister_state(t_reconfiguration_state state);

#endif
