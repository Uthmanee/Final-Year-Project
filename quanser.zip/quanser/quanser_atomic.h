#if !defined(_quanser_atomic_h)
#define _quanser_atomic_h

#include "quanser_extern.h"
#include "quanser_types.h"

#if defined(__QNX__)
typedef unsigned int t_atomic_int;
#elif defined(__APPLE__)
typedef int t_atomic_int;
#else
typedef long t_atomic_int;
#endif

typedef void * t_void_pointer;

/*
    Description:

    This function compares the comperand pointer with the value of the
    pointer in the destination. If the two are the same then it stores
    the new value in the destination. Otherwise it does nothing.
    It returns the original value of the destination. The entire
    operation is completely atomic.

    Parameters:

    destination = the location in which to store the new value
    comperand   = the value to compare to the value in the destination
    new_value   = the value to store in the destination

    Return values:

    The previous value stored in the destination. If this value is
    not equal to the comperand then the function did not store the
    new value in the destination.
*/
#if defined(__LINUX_RT_ARMV7__) || defined(_DUOVERO) || defined(_INTEL_AERO) || defined(_UBUNTU) || defined(_NVIDIA) || !defined(__linux)
EXTERN t_void_pointer
qatomic_compare_exchange_pointer(volatile t_void_pointer * destination, t_void_pointer comperand, t_void_pointer new_value);
#endif

/*
    Description:

    This function atomically increments the given value and
    returns the new value, after incrementing.

    Parameters:

    value = the address of the value to increment

    Return values:

    The new value after incrementing.
*/
EXTERN t_atomic_int
qatomic_increment(volatile t_atomic_int * value);

/*
    Description:

    This function atomically decrements the given value and
    returns the new value, after decrementing.

    Parameters:

    value = the address of the value to decrement

    Return values:

    The new value after decrementing.
*/
EXTERN t_atomic_int
qatomic_decrement(volatile t_atomic_int * value);


/*
    Description:

    This function atomically adds a quantity to the given value and
    returns the new value, after the addition.

    Parameters:

    value  = the address of the value being adjusted
    addend = the value being added

    Return values:

    The new value after addition.
*/
EXTERN t_atomic_int
qatomic_add(volatile t_atomic_int * value, t_int addend);

/*
    Description:

    This function atomically bitwise-ANDs the given value with the
    mask and returns the original value, prior to the AND operation.

    Parameters:

    value = the address of the value to bitwise-AND
    mask  = the mask to use for the bitwise-AND

    Return values:

    The value prior to the AND operation.
*/
EXTERN t_atomic_int
qatomic_and(volatile t_atomic_int * value, t_atomic_int mask);

/*
    Description:

    This function atomically bitwise-ORs the given value with the
    mask and returns the original value, prior to the OR operation.

    Parameters:

    value = the address of the value to bitwise-OR
    mask  = the mask to use for the bitwise-OR

    Return values:

    The value prior to the OR operation.
*/
EXTERN t_atomic_int
qatomic_or(volatile t_atomic_int * value, t_atomic_int mask);

#endif
