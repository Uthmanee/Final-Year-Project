#if !defined(_quanser_sound_h)
#define _quanser_sound_h

#include "quanser_extern.h"
#include "quanser_errors.h"
#include "quanser_types.h"

/*---------------------------- Beep Support ----------------------------*/

typedef struct tag_beep * t_beep;

EXTERN t_error
beep_open(t_beep * beep);

EXTERN t_error
beep_emit(t_beep beep, t_double frequency, t_double duration);

EXTERN t_error
beep_close(t_beep beep);

#endif
