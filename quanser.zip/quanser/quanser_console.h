#if !defined(_quanser_console_h)
#define _quanser_console_h

#include <stdarg.h>
#include "quanser_types.h"
#include "quanser_extern.h"
#include "quanser_errors.h"

EXTERN t_int
console_printV(t_int max_units, t_int * fields_printed, const t_utf8_char * format, va_list arguments);

EXTERN t_int
console_print(t_int max_units, t_int * fields_printed, const t_utf8_char * format, ...);

EXTERN t_error
console_flush(void);

EXTERN t_int
console_scanV(t_int max_units, t_int * fields_scanned, const t_utf8_char * format, va_list arguments);

EXTERN t_int
console_scan(t_int max_units, t_int * fields_scanned, const t_utf8_char * format, ...);

#endif
