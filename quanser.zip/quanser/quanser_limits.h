#if !defined(_quanser_limits_h)
#define _quanser_limits_h

#include "quanser_extern.h"
#include "quanser_types.h"

EXTERN t_double get_infinity(void);
EXTERN t_single get_infinityf(void);

#endif
