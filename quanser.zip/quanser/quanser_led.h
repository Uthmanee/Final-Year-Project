#if !defined(_quanser_led_h)
#define _quanser_led_h

typedef struct tag_led_color
{
    t_uint8 red;
    t_uint8 green;
    t_uint8 blue;
} t_led_color;

typedef struct tag_aaaf5050_mc_k12* t_aaaf5050_mc_k12;
typedef struct tag_aaaf5050_mc_k12_sim* t_aaaf5050_mc_k12_sim;

EXTERN t_error
aaaf5050_mc_k12_open(const char* uri, t_uint max_leds, t_aaaf5050_mc_k12* led_handle);

EXTERN t_int
aaaf5050_mc_k12_write(t_aaaf5050_mc_k12 led_handle, const t_led_color* colors, t_uint num_leds);

EXTERN t_error
aaaf5050_mc_k12_close(t_aaaf5050_mc_k12 led_handle);

EXTERN t_error
aaaf5050_mc_k12_sim_open(const char* uri, t_uint max_leds, t_aaaf5050_mc_k12_sim* led_handle);

EXTERN t_int
aaaf5050_mc_k12_sim_read(t_aaaf5050_mc_k12_sim led_handle, t_led_color* colors, t_uint num_leds);

EXTERN t_error
aaaf5050_mc_k12_sim_close(t_aaaf5050_mc_k12_sim led_handle);

#endif
