#if !defined(_quanser_audio_h)
#define _quanser_audio_h

#include "quanser_extern.h"
#include "quanser_errors.h"

typedef struct tag_audio_capture * t_audio_capture;
typedef struct tag_audio_render  * t_audio_render;
typedef void* t_audio_samples;

typedef enum tag_audio_format
{
    AUDIO_FORMAT_PCM,   /* 16-bit samples (t_int16) */
    AUDIO_FORMAT_FLOAT, /* 32-bit IEEE floating-point samples (t_single) */

    NUMBER_OF_AUDIO_FORMATS
} t_audio_format;

/* Modes used when a seekable file or URL is being read instead of a device */
typedef enum tag_audio_capture_mode
{
    AUDIO_CAPTURE_MODE_ONCE_AT_OPEN,        /* read audio samples from URL to end of stream once as soon as audio capture session is opened */
    AUDIO_CAPTURE_MODE_REPEAT_AT_OPEN,      /* read audio samples from URL to end of stream repeatedly as soon as audio capture session is opened */
    AUDIO_CAPTURE_MODE_ON_TRIGGER,          /* read audio samples from URL to end of stream each time trigger occurs */

    NUMBER_OF_AUDIO_CAPTURE_MODES
} t_audio_capture_mode;

/*
** Description:
**
**  Open an audio capture session which captures audio data from a microphone.
**
** Arguments:
**  url          = A valid URL would be "audio://localhost:0" where the port represents
**                 the audio input device number.
**  sample_rate  = The sample rate at which the PCM data is recorded in Hertz. A typical value
**                 is 44100 Hz.
**  num_channels = The number of audio channels. A typical value is 2 for the left and right channels.
**  format       = The format of the audio data. Valid values come from the t_audio_format enumeration
**                 above. The recommended value is AUDIO_FORMAT_FLOAT.
**  buffer_size  = The size of the audio buffer in samples (where one sample includes all channels). A
**                 buffer large enough for at least 0.1 seconds of audio is recommended i.e. sample_rate * 0.1.
**  mode         = The mode to use when the url parameter is a seekable file or URL (see t_audio_mode enumeration above).
**  capture      = A variable to which a handle to the audio capture session will be written.
*/

EXTERN t_error
audio_capture_open(const char * url, t_double sample_rate, t_uint num_channels, t_audio_format format, t_uint buffer_size, t_audio_capture_mode mode, t_audio_capture * capture);

/*
** Description:
**
**  Reads audio samples from the audio capture session. A "sample" consists of the data for all channels at one time instant. For example,
**  for AUDIO_FORMAT_PCM (16-bits) where two channels are used, a sample consists of 2 * sizeof(t_int16) = 4 bytes. It is more
**  efficient to read as many samples as possible at one time, such as a full audio buffer. This function returns immediately. If the
**  requested samples are not available then it returns 0 to indicate it timed out. If any are available then the buffers are filled
**  with the samples and the number of samples stored is returned.
**
** Arguments:
**  capture     = the handle to the audio capture session returned by audio_capture_open.
**  max_samples = the size of each buffer in number of samples.
**  buffers     = an array of pointers to the buffer for each channel (one pointer for each channel).
**                For AUDIO_FORMAT_PCM the data for each channel is of type t_uint16. For AUDIO_FORMAT_FLOAT
**                the data for each channel is of type t_single.
**
** Returns:
**  If samples are retrieved successfully then the number of samples is returned. If no samples are available
**  then zero is returned. If an error occurs then a negative error code is returned.
*/
EXTERN t_int
audio_capture_read(t_audio_capture capture, t_uint max_samples, t_audio_samples* buffers);

/*
** Description:
**
**  Triggers another read from the seekable file or URL. This function only works when the capture session was opened
**  in the AUDIO_CAPTURE_MODE_ON_TRIGGER mode.
*/
EXTERN t_error
audio_capture_trigger(t_audio_capture capture);

/*
** Description:
**
**  Closes the audio capture session.
*/
EXTERN t_error
audio_capture_close(t_audio_capture capture);

/*
** Description:
**
**  Open an audio renderer which plays audio data on a speaker.
**
** Arguments:
**  url          = A valid URL would be "audio://localhost:0" where the port represents
**                 the audio output device number.
**  sample_rate  = The sample rate at which the PCM data is played in Hertz. A typical value
**                 is 44100 Hz.
**  num_channels = The number of audio channels. A typical value is 2 for the left and right channels.
**  format       = The format of the audio data. Valid values come from the t_audio_format enumeration
**                 above. The recommended value is AUDIO_FORMAT_FLOAT.
**  buffer_size  = The size of the audio buffer in samples (where one sample includes all channels). A
**                 buffer large enough for at least 0.1 seconds of audio is recommended i.e. sample_rate * 0.1.
**  render       = A variable to which a handle to the audio renderer will be written.
*/
EXTERN t_error
audio_render_open(const char * url, t_double sample_rate, t_uint num_channels, t_audio_format format, t_uint buffer_size, t_audio_render * render);

/*
** Description:
**
**  Writes audio samples to the audio renderer. A "sample" consists of the data for all channels at one time instant. For example,
**  for AUDIO_FORMAT_PCM (16-bits) where two channels are used, a sample consists of 2 * sizeof(t_int16) = 4 bytes. It is more
**  efficient to write as many samples as possible at one time, such as a full audio buffer.
**
** Arguments:
**  render      = the handle to the audio renderer returned by audio_render_open.
**  num_samples = the number of samples in the data provided.
**  data        = an array of pointers to the data for each channel (one pointer for each channel).
**                For AUDIO_FORMAT_PCM the data for each channel is of type t_uint16. For AUDIO_FORMAT_FLOAT
**                the data for each channel is of type t_single.
*/
EXTERN t_error
audio_render_write(t_audio_render render, t_uint num_samples, const t_audio_samples * data);

/*
** Description:
**
**  Closes the audio renderer.
*/
EXTERN t_error
audio_render_close(t_audio_render render);

#endif
