#if !defined(_quanser_string_h)
#define _quanser_string_h

#include <stddef.h>
#include <stdarg.h>

#include "quanser_extern.h"
#include "quanser_errors.h"
#include "quanser_time.h"

#define MAX_STRING_LENGTH ((~0U) >> 1)

/*
    Description:

    This function returns the length of the source string, not including
    the null terminator. If length exceeds source_size then source_size
    is returned. Note that source_size includes space for a null terminator
    so that the length of the source string must always be less than the
    source_size parameter if successful.

    Parameters:

    source      = the string whose length to determine
    source_size = the size of the source buffer in code units (bytes)

    Return values:

    Returns the length of the string if successful, not including
    the null terminator. Otherwise it returns source_size.
*/
EXTERN size_t
string_length(const char * source, size_t source_size);

/*
    Description:

    This function copies the source string to the destination string. It
    ensures that overflow of the destination string does not occur. The
    size of the destination string is specified in code units, not characters.
    The resulting string is always null-terminated. If the source string
    is longer than the destination_size then as much as possible is copied
    from the source string and the destination string is null terminated. In
    this case, -QERR_STRING_TOO_SMALL is returned.

    The results are undefined if the strings overlap.

    If the source argument is NULL then it returns -QERR_STRING_IS_NULL.

    Parameters:

    destination      = the string in which to copy the source
    destination_size = the size of the destination buffer in code units (bytes)
    source           = the null-terminated string to copy

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
string_copy(char * destination, size_t destination_size, const char * source);

/*
    Description:

    This function copies the source string to the destination string. It
    ensures that overflow of the destination string does not occur. The
    size of the destination string is specified in code units, not characters.
    The resulting string is always null-terminated. If the source string
    is longer than the destination_size then as much as possible is copied
    from the source string and the destination string is null terminated. In
    this case, -QERR_STRING_TOO_SMALL is returned.

    The strings may overlap.

    Parameters:

    destination      = the string in which to copy the source
    destination_size = the size of the destination buffer in code units (bytes)
    source           = the null-terminated string to copy

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
string_move(char * destination, size_t destination_size, const char * source);

/*
    Description:

    This function concatenates the source string with the destination string. It
    ensures that overflow of the destination string does not occur. The
    size of the destination string is specified in code units, not characters.
    If the concatenated string is longer than destination_size than as much as possible
    is concatenated from the source string and the destination string is null terminated.
    In this case, -QERR_STRING_TOO_SMALL is returned.

    If the destination string itself is not null terminated within destination_size code units
    then -QERR_STRING_NOT_TERMINATED is returned and the destination string is left unchanged.

    Parameters:

    destination      = the string to which the source string is concatenated
    destination_size = the size of the destination buffer in code units (bytes)
    source           = the null-terminated string to concatenate

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
string_concatenate(char * destination, size_t destination_size, const char * source);

/*
    Description:

    This function finds the first occurrence of a character in a string.
    It returns a pointer to the character in the string or NULL if the
    character could not be found. This function will not search beyond
    source_size code units (bytes).

    Parameters:

    source      = the null-terminated string to search
    source_size = the size of the source buffer in code units (bytes). This
                  parameter may be larger than the actual length of the string
    c           = the character for which to search
    new_size    = the size of the source buffer in code units relative to
                  the returned position in the string.
                  i.e. new_size = source_size - (return_value - source)
                  This parameter may be NULL, in which case the new size
                  is not returned.

    Return values:

    Returns a pointer to the character found on success, or NULL if the
    character could not be found.
*/
EXTERN char *
string_find(const char * source, size_t source_size, char c, size_t * new_size);

/*
    Description:

    This function finds the first occurrence of any character in the given
    set in a string. It returns a pointer to the character in the string
    or NULL if no character in the set could be found. This function will
    not search beyond source_size code units (bytes).

    Parameters:

    source      = the null-terminated string to search
    source_size = the size of the source buffer in code units (bytes). This
                  parameter may be larger than the actual length of the string
    set         = the set of characters for which to search
    set_size    = the size of the set in code units. This parameter may be
                  larger than the actual length of the set.
    new_size    = the size of the source buffer in code units relative to
                  the returned position in the string.
                  i.e. new_size = source_size - (return_value - source)
                  This parameter may be NULL, in which case the new size
                  is not returned.
    set_index   = the position in the set of the character that was found.

    Return values:

    Returns a pointer to the character found on success, or NULL if the
    character could not be found.
*/
EXTERN char *
string_find_in_set(const char * source, size_t source_size, const char * set, size_t set_size, size_t * new_size, size_t * set_index);


/*
    Description:

    This function finds the first occurrence of a substring in a string.
    It returns a pointer to the substring in the string or NULL if the
    substring could not be found. This function will not search beyond
    source_size code units (bytes).

    Parameters:

    source      = the null-terminated string to search
    source_size = the size of the source buffer in code units (bytes). This
                  parameter may be larger than the actual length of the string
    substring   = the substring for which to search
    new_size    = the size of the source buffer in code units relative to
                  the returned position in the string
                  i.e. new_size = source_size - (return_value - source)

    Return values:

    Returns a pointer to the substring found on success, or NULL if the
    substring could not be found.
*/
EXTERN char *
string_find_substring(const char * source, size_t source_size, const char * substring, size_t * new_size);

/*
    Description:

    This function compares two strings for equality. It will not compare
    beyond the maximum_size in code units (bytes). The comparison is 
    case-sensitive.

    Parameters:

    source       = the null-terminated string to compare
    maximum_size = the maximum number of code units (bytes) to compare. This
                   parameter may be larger than the actual length of the strings
    comperand    = the string with which to compare

    Return values:

    Returns zero if the strings are not equal, and non-zero if the strings are equal.
    If maximum_size is zero then zero is returned regardless of the contents of the
    source and comperand strings.
*/
EXTERN t_boolean
string_equal(const char * source, size_t maximum_size, const char * comperand);

/*
    Description:

    This function compares two strings for equality. It will not compare
    beyond the maximum_size in code units (bytes). The comparison is 
    case-insensitive.

    *** NOTE: This function may belong in quanser_runtime because it makes use
              of the toupper() C library function!! ***

    Parameters:

    source       = the null-terminated string to compare
    maximum_size = the maximum number of code units (bytes) to compare. This
                   parameter may be larger than the actual length of the strings
    comperand    = the string with which to compare

    Return values:

    Returns zero if the strings are not equal, and non-zero if the strings are equal.
    If maximum_size is zero then zero is returned regardless of the contents of the
    source and comperand strings.
*/
EXTERN t_boolean
string_equal_ignoring_case(const char * source, size_t maximum_size, const char * comperand);

/*
    Description:

    This function converts a string to an integer. It supports binary,
    octal and hexadecimal using prefixes '0b', '0' and '0x' respectively.
    If no prefix is specified then the integer is assumed to be decimal.
    This function will not convert beyond the source_size in code units 
    (bytes). Conversion stops at the first invalid character. This
    situation is not considered an error. The return value can be
    used to check the validity of the character at which it
    stopped converting. However note that if conversion stops at
    source_size code units then the returned pointer will point
    to the character immediately following source_size code units.

    Note that leading whitespace is not skipped. The caller must skip
    leading whitespace if whitespace may be present.

    Parameters:

    source      = the null-terminated string to convert to an integer
    source_size = initialize to the size of the source buffer in code units
                  (bytes). This parameter may be larger or smaller than the
                  actual length of the string.
    value       = the converted value
    new_size    = a pointer to a size_t variable which will be set to
                  the "new" source_size if the source pointer were set to
                  the return value from this function.

    Return values:

    Returns a pointer to the character immediately following the integer value
    or NULL if an error occurs.  If the first character is not an integer or 
	the string is empty, the function returns NULL.
*/
EXTERN char *
string_to_integer(const char * source, size_t source_size, t_int * value, size_t * new_size);

/*
    Description:

    This function converts a string to a 64-bit integer. It supports binary,
    octal and hexadecimal using prefixes '0b', '0' and '0x' respectively.
    If no prefix is specified then the 64-bit integer is assumed to be decimal.
    This function will not convert beyond the source_size in code units 
    (bytes). Conversion stops at the first invalid character. This
    situation is not considered an error. The return value can be
    used to check the validity of the character at which it
    stopped converting. However note that if conversion stops at
    source_size code units than the returned pointer will point
    to the character immediately following source_size code units.

    Note that leading whitespace is not skipped. The caller must skip
    leading whitespace if whitespace may be present.

    Parameters:

    source      = the null-terminated string to convert to a 64-bit integer
    source_size = initialize to the size of the source buffer in code units
                  (bytes). This parameter may be larger or smaller than the
                  actual length of the string.
    value       = the converted value
    new_size    = a pointer to a size_t variable which will be set to
                  the "new" source_size if the source pointer were set to
                  the return value from this function.

    Return values:

    Returns a pointer to the character immediately following the integer value
    or NULL if an error occurs.  If the first character is not an integer or 
	the string is empty, the function returns NULL.
*/
EXTERN char *
string_to_long(const char * source, size_t source_size, t_long * value, size_t * new_size);

/*
    Description:

    This function converts a string to an unsigned 64-bit integer. It supports binary,
    octal and hexadecimal using prefixes '0b', '0' and '0x' respectively.
    If no prefix is specified then the 64-bit integer is assumed to be decimal.
    This function will not convert beyond the source_size in code units 
    (bytes). Conversion stops at the first invalid character. This
    situation is not considered an error. The return value can be
    used to check the validity of the character at which it
    stopped converting. However note that if conversion stops at
    source_size code units than the returned pointer will point
    to the character immediately following source_size code units.

    Note that leading whitespace is not skipped. The caller must skip
    leading whitespace if whitespace may be present.

    Parameters:

    source      = the null-terminated string to convert to a 64-bit integer
    source_size = initialize to the size of the source buffer in code units
                  (bytes). This parameter may be larger or smaller than the
                  actual length of the string.
    value       = the converted value
    new_size    = a pointer to a size_t variable which will be set to
                  the "new" source_size if the source pointer were set to
                  the return value from this function.

    Return values:

    Returns a pointer to the character immediately following the integer value
    or NULL if an error occurs.  If the first character is not an integer or 
	the string is empty, the function returns NULL.
*/
EXTERN char *
string_to_unsigned_long(const char * source, size_t source_size, t_ulong * value, size_t * new_size);

/*
    Description:

    This function converts a string to a double. It supports floating-point
    numbers in the form:

        [+|-][0-9]*[.][0-9]*[e|E][+|-][0-9]+
    or  [+|-]Inf
    or  [+|-]NaN

    For example:
        0.5
        -.75
        1e-10
        .5e7
        -Inf
        +NaN

    This function will not convert beyond the source_size in code units 
    (bytes). Conversion stops at the first invalid character. This
    situation is not considered an error. The return value can be
    used to check the validity of the character at which it
    stopped converting. However note that if conversion stops at
    source_size code units than the returned pointer will point
    to the character immediately following source_size code units.

    Note that leading whitespace is not skipped. The caller must skip
    leading whitespace if whitespace may be present.

    Parameters:

    source      = the null-terminated string to convert to a double
    source_size = initialize to the size of the source buffer in code units
                  (bytes). This parameter may be larger or smaller than the
                  actual length of the string.
    value       = the converted value
    new_size    = a pointer to a size_t variable which will be set to
                  the "new" source_size if the source pointer were set to
                  the return value from this function.

    Return values:

    Returns a pointer to the character immediately following the double value
    or NULL if an error occurs.  If no valid value could be parsed or 
	the string is empty, the function returns NULL.
*/
EXTERN char *
string_to_double(const char * source, size_t source_size, t_double * value, size_t * new_size);

/*
    Description:

    This function converts an integer to a string. It supports any base
    between 2 and 36 inclusive. The return value is zero on success or a
    negative error code on failure. Conversion stops at destination_size 
    code units. The resulting string is always null-terminated. If there
    is not enough room in the destination string then the string is
    truncated and a negative error code is returned. No prefix is added 
    to the string to indicate the base. If the value is negative then a
    '-' character is placed at the beginning of the string.

    Parameters:

    destination      = the null-terminated string in which to store the result
    destination_size = initialize to the size of the destination buffer in code
                       units (bytes).
    base             = the base in which to convert the value
    value            = the value to convert

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
integer_to_string(char * destination, size_t destination_size, t_uint base, t_int value);

/*
    Description:

    This function converts an unsigned integer to a string. It supports any base
    between 2 and 36 inclusive. The return value is zero on success or a negative
    error code on failure. Conversion stops at destination_size code units. The
    resulting string is always null-terminated. If there is not enough room in
    the destination string then the string is truncated and a negative
    error code is returned. No prefix is added to the string to indicate
    the base.

    Parameters:

    destination      = the null-terminated string in which to store the result
    destination_size = initialize to the size of the destination buffer in code
                       units (bytes).
    base             = the base in which to convert the value
    value            = the value to convert

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
unsigned_to_string(char * destination, size_t destination_size, t_uint base, t_uint value);

/*
    Description:

    This function converts a string to a t_timeout structure. This
    function will not convert beyond the source_size in code units 
    (bytes). Conversion stops at the first invalid character. This
    situation is not considered an error. The return value can be
    used to check the validity of the character at which it
    stopped converting. However note that if conversion stops at
    source_size code units than the returned pointer will point
    to the character immediately following source_size code units.

    The timeout string is expressed as a real number. The returned
    t_timeout structure is initialized as a relative timeout.

    Parameters:

    source      = the null-terminated string to convert to a timeout
    source_size = initialize to the size of the source buffer in code units
                  (bytes). This parameter may be larger or smaller than the
                  actual length of the string. Upon return, it contains the
                  size of the source buffer as if it started at the return
                  value from the function.
    value       = the converted value
    new_size    = a pointer to a size_t variable which will be set to
                  the "new" source_size if the source pointer were set to
                  the return value from this function.

    Return values:

    Returns a pointer to the character immediately following the timeout value
    or NULL if an error occurs.
*/
EXTERN char *
string_to_timeout(const char * source, size_t source_size, t_timeout * value, size_t * new_size);

/*
    Description:

    This function converts a string to a t_boolean. This
    function will not convert beyond the source_size in code units
    (bytes). Conversion stops at the first invalid character. This
    situation is not considered an error. The return value can be
    used to check the validity of the character at which it
    stopped converting. However note that if conversion stops at
    source_size code units than the returned pointer will point
    to the character immediately following source_size code units.

    The boolean string is expressed as one of the following:
        "0", "n", "no", "off", "f" or "false"
        "1", "y", "yes", "on", "t" or "true"

    Parameters:

    source      = the null-terminated string to convert to a timeout
    source_size = initialize to the size of the source buffer in code units
                  (bytes). This parameter may be larger or smaller than the
                  actual length of the string. Upon return, it contains the
                  size of the source buffer as if it started at the return
                  value from the function.
    value       = the converted value
    new_size    = a pointer to a size_t variable which will be set to
                  the "new" source_size if the source pointer were set to
                  the return value from this function.

    Return values:

    Returns a pointer to the character immediately following the timeout value
    or NULL if an error occurs.
*/
EXTERN char *
string_to_boolean(const char * source, size_t source_size, t_boolean * value, size_t * new_size);

/*
    Description:

    This function replaces the old_char in the source string with the
    new_char character. Every instance of old_char is replaced, not just
    the first instance.

    Parameters:

    source      = the string to modify
    source_size = the limit on the size of the source string in code units (bytes)
    old_char    = the character to replace
    new_char    = the character with which to replace it

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
string_replace(char * source, size_t source_size, char old_char, char new_char);

/*
    Description:

    This function prints formatted output to a string. The resulting string will
    be truncated if the formatted output is too large for the destination string.
    The string is always null terminated, unless the buffer size is 0.

    Parameters:

    destination      = the buffer in which to store the formatted string
    destination_size = the size of the buffer in code units (bytes)
    format           = the formatting string
    ...              = the arguments to format

    Return values:

    Returns the number of code units (bytes) written on success (not including the null terminator),
    or a negative error code. If the string is truncated then -QERR_STRING_TOO_SMALL is returned,
    but the truncated string is still written to the buffer and is always null terminated.
*/
EXTERN t_int
string_format(char * destination, size_t destination_size, const char * format, ...);

/*
    Description:

    This function prints formatted output to a string. The resulting string will
    be truncated if the formatted output is too large for the destination string.
    The string is always null terminated, unless the buffer size is 0.

    Parameters:

    destination      = the buffer in which to store the formatted string
    destination_size = the size of the buffer in code units (bytes)
    format           = the formatting string
    arguments        = the arguments to format

    Return values:

    Returns the number of code units (bytes) written on success (not including the null terminator),
    or a negative error code. If the string is truncated then -QERR_STRING_TOO_SMALL is returned,
    but the truncated string is still written to the buffer and is always null terminated.
*/
EXTERN t_int
string_formatV(char * destination, size_t destination_size, const char * format, va_list arguments);

/*
    Description:

    This function converts a string into a wide string. Only the number of code units specified
    in the source_size parameter will be converted. The output string will be truncated at the
    destination_size (which is expressed in code units), if necessary, but will always be null-
    terminated.

    The return value is the number of code units copied to the destination, including the null
    terminator. If the destination is NULL then it will be the number of code units required to
    hold the result, including the null terminator.
 
    Parameters:

    source           = the string to convert
    source_size      = the size of the source buffer in code units (bytes)
    destination      = the buffer in which to store the wide string
    destination_size = the size of the destination buffer in code units (number of wchar_t's)

    Return values:

    Returns the number of code units copied to the destination on success and a negative error code on failure.
*/
EXTERN t_error
string_to_wstring(const char * source, size_t source_size, wchar_t * destination, size_t destination_size);

/*
    Description:

    This function returns the length of the source string, not including
    the null terminator. If length exceeds source_size then source_size
    is returned. Note that source_size includes space for a null terminator
    so that the length of the source string must always be less than the
    source_size parameter if successful.

    Parameters:

    source      = the string whose length to determine
    source_size = the size of the source buffer in code units (bytes)

    Return values:

    Returns the length of the string if successful, not including
    the null terminator. Otherwise it returns source_size.
*/
EXTERN size_t
wstring_length(const wchar_t * source, size_t source_size);

/*
    Description:

    This function copies the source string to the destination string. It
    ensures that overflow of the destination string does not occur. The
    size of the destination string is specified in code units, not characters.
    The resulting string is always null-terminated. If the source string
    is longer than the destination_size then as much as possible is copied
    from the source string and the destination string is null terminated. In
    this case, -QERR_STRING_TOO_SMALL is returned.

    If the source argument is NULL then it returns -QERR_STRING_IS_NULL.

    Parameters:

    destination      = the string in which to copy the source
    destination_size = the size of the destination buffer in code units (words)
    source           = the null-terminated string to copy

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
wstring_copy(wchar_t * destination, size_t destination_size, const wchar_t * source);

/*
    Description:

    This function copies the source string to the destination string. It
    ensures that overflow of the destination string does not occur. The
    size of the destination string is specified in code units, not characters.
    The resulting string is always null-terminated. If the source string
    is longer than the destination_size then as much as possible is copied
    from the source string and the destination string is null terminated. In
    this case, -QERR_STRING_TOO_SMALL is returned.

    The strings may overlap.

    Parameters:

    destination      = the string in which to copy the source
    destination_size = the size of the destination buffer in code units (words)
    source           = the null-terminated string to copy

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
wstring_move(wchar_t * destination, size_t destination_size, const wchar_t * source);

/*
    Description:

    This function concatenates the source string with the destination string. It
    ensures that overflow of the destination string does not occur. The
    size of the destination string is specified in code units, not characters.
    If the concatenated string is longer than destination_size than as much as possible
    is concatenated from the source string and the destination string is null terminated.
    In this case, -QERR_STRING_TOO_SMALL is returned.

    If the destination string itself is not null terminated within destination_size code units
    then -QERR_STRING_NOT_TERMINATED is returned and the destination string is left unchanged.

    Parameters:

    destination      = the string to which the source string is concatenated
    destination_size = the size of the destination buffer in code units (bytes)
    source           = the null-terminated string to concatenate

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
wstring_concatenate(wchar_t * destination, size_t destination_size, const wchar_t * source);

/*
    Description:

    This function finds the first occurrence of a character in a string.
    It returns a pointer to the character in the string or NULL if the
    character could not be found. This function will not search beyond
    source_size code units.

    Parameters:

    source      = the null-terminated string to search
    source_size = the size of the source buffer in code units. This
                  parameter may be larger than the actual length of the string
    c           = the character for which to search
    new_size    = the size of the source buffer in code units relative to
                  the returned position in the string.
                  i.e. new_size = source_size - (return_value - source)
                  This parameter may be NULL, in which case the new size
                  is not returned.

    Return values:

    Returns a pointer to the character found on success, or NULL if the
    character could not be found.
*/
EXTERN wchar_t *
wstring_find(const wchar_t * source, size_t source_size, wchar_t c, size_t * new_size);

/*
    Description:

    This function finds the first occurrence of any character in the given
    set in a wide string. It returns a pointer to the character in the string
    or NULL if no character in the set could be found. This function will
    not search beyond source_size code units (bytes).

    Parameters:

    source      = the null-terminated wide string to search
    source_size = the size of the source buffer in code units. This
                  parameter may be larger than the actual length of the string
    set         = the set of characters for which to search
    set_size    = the size of the set in code units. This parameter may be
                  larger than the actual length of the set.
    new_size    = the size of the source buffer in code units relative to
                  the returned position in the string.
                  i.e. new_size = source_size - (return_value - source)
                  This parameter may be NULL, in which case the new size
                  is not returned.
    set_index   = the position in the set of the character that was found.

    Return values:

    Returns a pointer to the character found on success, or NULL if the
    character could not be found.
*/
EXTERN wchar_t *
wstring_find_in_set(const wchar_t * source, size_t source_size, const wchar_t * set, size_t set_size, size_t * new_size, size_t * set_index);

/*
    Description:

    This function finds the first occurrence of a substring in a string.
    It returns a pointer to the substring in the string or NULL if the
    substring could not be found. This function will not search beyond
    source_size code units.

    Parameters:

    source      = the null-terminated string to search
    source_size = the size of the source buffer in code units. This
                  parameter may be larger than the actual length of the string
    substring   = the substring for which to search
    new_size    = the size of the source buffer in code units relative to
                  the returned position in the string
                  i.e. new_size = source_size - (return_value - source)

    Return values:

    Returns a pointer to the substring found on success, or NULL if the
    substring could not be found.
*/
EXTERN wchar_t *
wstring_find_substring(const wchar_t * source, size_t source_size, const wchar_t * substring, size_t * new_size);

/*
    Description:

    This function compares two wide strings for equality. It will not compare
    beyond the maximum_size in code units (bytes). The comparison is 
    case-sensitive.

    Parameters:

    source       = the null-terminated wide string to compare
    maximum_size = the maximum number of code units to compare. This parameter
                   may be larger than the actual length of the strings
    comperand    = the wide string with which to compare

    Return values:

    Returns zero if the strings are not equal, and non-zero if the strings are equal.
    If maximum_size is zero then zero is returned regardless of the contents of the
    source and comperand strings.
*/
EXTERN t_boolean
wstring_equal(const wchar_t * source, size_t maximum_size, const wchar_t * comperand);

/*
    Description:

    This function compares two strings for equality. It will not compare
    beyond the maximum_size in code units. The comparison is 
    case-insensitive.

    *** NOTE: This function may belong in quanser_runtime because it makes use
              of the towupper() C library function!! ***

    Parameters:

    source       = the null-terminated string to compare
    maximum_size = the maximum number of code units to compare. This
                   parameter may be larger than the actual length of the strings
    comperand    = the string with which to compare

    Return values:

    Returns zero if the strings are not equal, and non-zero if the strings are equal.
    If maximum_size is zero then zero is returned regardless of the contents of the
    source and comperand strings.
*/
EXTERN t_boolean
wstring_equal_ignoring_case(const wchar_t * source, size_t maximum_size, const wchar_t * comperand);

/*
    Description:

    This function converts a wide string to an integer. It supports binary,
    octal and hexadecimal using prefixes '0b', '0' and '0x' respectively.
    If no prefix is specified then the integer is assumed to be decimal.
    This function will not convert beyond the source_size in code units 
    (bytes). Conversion stops at the first invalid character. This
    situation is not considered an error. The return value can be
    used to check the validity of the character at which it
    stopped converting. However note that if conversion stops at
    source_size code units than the returned pointer will point
    to the character immediately following source_size code units.

    Parameters:

    source      = the null-terminated string to convert to an integer
    source_size = initialize to the size of the source buffer in code units
                  (bytes). This parameter may be larger or smaller than the
                  actual length of the string. Upon return, it contains the
                  size of the source buffer as if it started at the return
                  value from the function.
    value       = the converted value
    new_size    = a pointer to a size_t variable which will be set to
                  the "new" source_size if the source pointer were set to
                  the return value from this function.

    Return values:

    Returns a pointer to the character immediately following the integer value
    or NULL if an error occurs.
*/
EXTERN wchar_t *
wstring_to_integer(const wchar_t * source, size_t source_size, t_int * value, size_t * new_size);

/*
    Description:

    This function converts a wide string to a double. It supports floating-point
    numbers in the form:

        [+|-][0-9]*[.][0-9]*[e|E][+|-][0-9]+
    or  [+|-]Inf
    or  [+|-]NaN

    For example:
        0.5
        -.75
        1e-10
        .5e7
        -Inf
        +NaN

    This function will not convert beyond the source_size in code units 
    (wchar_t's). Conversion stops at the first invalid character. This
    situation is not considered an error. The return value can be
    used to check the validity of the character at which it
    stopped converting. However note that if conversion stops at
    source_size code units than the returned pointer will point
    to the character immediately following source_size code units.

    Note that leading whitespace is not skipped. The caller must skip
    leading whitespace if whitespace may be present.

    Parameters:

    source      = the null-terminated string to convert to a double
    source_size = initialize to the size of the source buffer in code units
                  (wchar_t's). This parameter may be larger or smaller than the
                  actual length of the string.
    value       = the converted value
    new_size    = a pointer to a size_t variable which will be set to
                  the "new" source_size if the source pointer were set to
                  the return value from this function.

    Return values:

    Returns a pointer to the character immediately following the double value
    or NULL if an error occurs.  If no valid value could be parsed or 
	the string is empty, the function returns NULL.
*/
EXTERN wchar_t *
wstring_to_double(const wchar_t * source, size_t source_size, t_double * value, size_t * new_size);

/*
    Description:

    This function converts an integer to a wide string. It supports any base
    between 2 and 36 inclusive. The return value is zero on success or a
    negative error code on failure. Conversion stops at destination_size 
    code units. The resulting string is always null-terminated. If there
    is not enough room in the destination string then the string is
    truncated and a negative error code is returned. No prefix is added 
    to the string to indicate the base. If the value is negative then a
    '-' character is placed at the beginning of the string.

    Parameters:

    destination      = the null-terminated string in which to store the result
    destination_size = initialize to the size of the destination buffer in code
                       units (wchar_t's).
    base             = the base in which to convert the value
    value            = the value to convert

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
integer_to_wstring(wchar_t * destination, size_t destination_size, t_uint base, t_int value);

/*
    Description:

    This function converts an unsigned integer to a wide string. It supports any base
    between 2 and 36 inclusive. The return value is zero on success or a negative
    error code on failure. Conversion stops at destination_size code units. The
    resulting string is always null-terminated. If there is not enough room in
    the destination string then the string is truncated and a negative
    error code is returned. No prefix is added to the string to indicate
    the base.

    Parameters:

    destination      = the null-terminated string in which to store the result
    destination_size = initialize to the size of the destination buffer in code
                       units (wchar_t's).
    base             = the base in which to convert the value
    value            = the value to convert

    Return values:

    Returns 0 on success and a negative error code on failure.
*/
EXTERN t_error
unsigned_to_wstring(wchar_t * destination, size_t destination_size, t_uint base, t_uint value);

/*
    Description:

    This function converts a wide string to an unsigned 64-bit integer. It supports binary,
    octal and hexadecimal using prefixes '0b', '0' and '0x' respectively.
    If no prefix is specified then the 64-bit integer is assumed to be decimal.
    This function will not convert beyond the source_size in code units 
    (bytes). Conversion stops at the first invalid character. This
    situation is not considered an error. The return value can be
    used to check the validity of the character at which it
    stopped converting. However note that if conversion stops at
    source_size code units than the returned pointer will point
    to the character immediately following source_size code units.

    Note that leading whitespace is not skipped. The caller must skip
    leading whitespace if whitespace may be present.

    Parameters:

    source      = the null-terminated wide string to convert to a 64-bit integer
    source_size = initialize to the size of the source buffer in code units
                  (bytes). This parameter may be larger or smaller than the
                  actual length of the string.
    value       = the converted value
    new_size    = a pointer to a size_t variable which will be set to
                  the "new" source_size if the source pointer were set to
                  the return value from this function.

    Return values:

    Returns a pointer to the character immediately following the integer value
    or NULL if an error occurs.  If the first character is not an integer or 
	the string is empty, the function returns NULL.
*/
EXTERN wchar_t *
wstring_to_unsigned_long(const wchar_t * source, size_t source_size, t_ulong * value, size_t * new_size);

/*
    Description:

    This function prints formatted output to a string. The resulting string will
    be truncated if the formatted output is too large for the destination string.
    The string is always null terminated, unless the buffer size is 0.

    Parameters:

    destination      = the buffer in which to store the formatted string
    destination_size = the size of the buffer in code units (wchar_t's)
    format           = the formatting string
    ...              = the arguments to format

    Return values:

    Returns the number of code units (wchar_t's) written on success (not including the null terminator),
    or a negative error code. If the string is truncated then -QERR_STRING_TOO_SMALL is returned,
    but the truncated string is still written to the buffer and is always null terminated.
*/
EXTERN t_int
wstring_format(wchar_t * destination, size_t destination_size, const wchar_t * format, ...);

/*
    Description:

    This function prints formatted output to a string. The resulting string will
    be truncated if the formatted output is too large for the destination string.
    The string is always null terminated, unless the buffer size is 0.

    Parameters:

    destination      = the buffer in which to store the formatted string
    destination_size = the size of the buffer in code units (wchar_t's)
    format           = the formatting string
    arguments        = the arguments to format

    Return values:

    Returns the number of code units (wchar_t's) written on success (not including the null terminator),
    or a negative error code. If the string is truncated then -QERR_STRING_TOO_SMALL is returned,
    but the truncated string is still written to the buffer and is always null terminated.
*/
EXTERN t_int
wstring_formatV(wchar_t * destination, size_t destination_size, const wchar_t * format, va_list arguments);


/*
    Description:

    This function replaces the old_char in the source string with the
    new_char character. Every instance of old_char is replaced, not just
    the first instance.

    Parameters:

    source      = the string to modify
    source_size = the limit on the size of the source string in code units (bytes)
    old_char    = the character to replace
    new_char    = the character with which to replace it

    Return values:

    Returns 0 on success, or a negative error code.
*/
EXTERN t_error
wstring_replace(wchar_t * source, size_t source_size, wchar_t old_char, wchar_t new_char);


#if defined(_UNICODE)
#define _tstring_length(source, source_size)                                            wstring_length(source, source_size)
#define _tstring_copy(destination, destination_size, source)                            wstring_copy(destination, destination_size, source)
#define _tstring_concatenate(destination, destination_size, source)                     wstring_concatenate(destination, destination_size, source)
#define _tstring_find(source, source_size, c, new_size)                                 wstring_find(source, source_size, c, new_size)
#define _tstring_find_in_set(source, source_size, set, set_size, new_size, set_index)   wstring_find_in_set(source, source_size, set, set_size, new_size, set_index)
#define _tstring_find_substring(source, source_size, substring, new_size)               wstring_find_substring(source, source_size, substring, new_size)
#define _tstring_equal(source, maximum_size, comperand)                                 wstring_equal(source, maximum_size, comperand)
#define _tstring_equal_ignoring_case(source, maximum_size, comperand)                   wstring_equal_ignoring_case(source, maximum_size, comperand)
#define _tstring_to_integer(source, source_size, value, new_size)                       wstring_to_integer(source, source_size, value, new_size)
#define _tstring_to_double(source, source_size, value, new_size)                        wstring_to_double(source, source_size, value, new_size)
#define _integer_to_tstring(destination, destination_size, base, value)                 integer_to_wstring(destination, destination_size, base, value)
#define _unsigned_to_tstring(destination, destination_size, base, value)                unsigned_to_wstring(destination, destination_size, base, value)
#define _tstring_format                                                                 wstring_format
#define _tstring_formatV(destination, destination_size, format, arguments)              wstring_formatV(destination, destination_size, format, arguments)
#define _tstring_replace(source, source_size, old_char, new_char)                       wstring_replace(source, source_size, old_char, new_char)
#define _tstring_to_unsigned_long(source, source_size, value, new_size)                 wstring_to_unsigned_long(source, source_size, value, new_size)
#else
#define _tstring_length(source, source_size)                                            string_length(source, source_size)
#define _tstring_copy(destination, destination_size, source)                            string_copy(destination, destination_size, source)
#define _tstring_concatenate(destination, destination_size, source)                     string_concatenate(destination, destination_size, source)
#define _tstring_find(source, source_size, c, new_size)                                 string_find(source, source_size, c, new_size)
#define _tstring_find_in_set(source, source_size, set, set_size, new_size, set_index)   string_find_in_set(source, source_size, set, set_size, new_size, set_index)
#define _tstring_find_substring(source, source_size, substring, new_size)               string_find_substring(source, source_size, substring, new_size)
#define _tstring_equal(source, maximum_size, comperand)                                 string_equal(source, maximum_size, comperand)
#define _tstring_equal_ignoring_case(source, maximum_size, comperand)                   string_equal_ignoring_case(source, maximum_size, comperand)
#define _tstring_to_integer(source, source_size, value, new_size)                       string_to_integer(source, source_size, value, new_size)
#define _tstring_to_double(source, source_size, value, new_size)                        string_to_double(source, source_size, value, new_size)
#define _integer_to_tstring(destination, destination_size, base, value)                 integer_to_string(destination, destination_size, base, value)
#define _unsigned_to_tstring(destination, destination_size, base, value)                unsigned_to_string(destination, destination_size, base, value)
#define _tstring_format                                                                 string_format
#define _tstring_formatV(destination, destination_size, format, arguments)              string_formatV(destination, destination_size, format, arguments)
#define _tstring_replace(source, source_size, old_char, new_char)                       string_replace(source, source_size, old_char, new_char)
#define _tstring_to_unsigned_long(source, source_size, value, new_size)                 string_to_unsigned_long(source, source_size, value, new_size)
#endif

#endif
