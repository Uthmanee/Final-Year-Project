#if !defined(_quanser_persistent_stream_h)
#define _quanser_persistent_stream_h

/*
    Quanser Persistent Stream API

    The Persistent Stream API is a high-level API based upon the Stream API defined in quanser_stream.h.
    It consists of functions that provide a "persistent" connection between client and server. Connections
    are persistent in the sense that if the connection is lost or closed by the peer, the Persistent Stream
    functions automatically attempt to reconnect, without any extra action by the caller. For example, the
    pstream_send function may actually attempt to reconnect to a peer instead of sending the data, in which
    case it would return -QERR_WOULD_BLOCK. There is no need to call pstream_close and pstream_connect to
    reconnect. This persistence is convenient because it means that the code can simply assume that the
    connection is always there. If, in our example, the pstream_send function returns any error then simply
    call pstream_send again until it succeeds (with some kind of time delay in between!). Note a key point
    in this example - the error codes returned by the pstream functions are more for informational purposes.
    It is not necessary to close the persistent stream when an error occurs, because the connection will
    automatically be re-established when the connection is lost. Thus, an error really indicates that the
    operation could not be performed at present, but may succeed in the future, even without closing the
    persistent stream. In fact, the persistent stream should not be closed until it is no longer needed.
    It should be closed, however, before exiting the application.

    One key feature of the Persistent Stream API is that all the pstream functions are non-blocking. They
    always return immediately. The reason for these non-blocking semantics is that the Persistent Stream API
    forms the basis of the Basic communications blocks: Stream Client and Stream Server. These blocks are
    designed to be called periodically at the sample rate of the blocks. They are also designed never to
    block because otherwise they could interfere with the sample rate of the diagram. Thus, the Persistent
    Stream API functions are designed to be called periodically and therefore do not block.

    To implement a client, use the pstream_connect, pstream_send, pstream_receive and pstream_close
    functions. To implement a server, use the pstream_listen, pstream_send, pstream_receive and pstream_close
    functions. The current state of the connection may be determined using the pstream_get_state function,
    which returns an enumerated type indicating whether a connection is currently established, or is in
    the process of being established, or whether there is no connection at all. See the pstream_get_state
    function for details.
*/

#include "quanser_stream.h"
#include "quanser_thread.h"
#include "quanser_semaphore.h"

typedef enum tag_pstream_flags
{
    PSTREAM_FLAG_NATIVE_ENDIAN             = STREAM_BYTE_ORDER_NATIVE_ENDIAN,   /* use the native endianness i.e. use little endian on a little endian platform and big endian on a big endian platform (no byte swapping) */
    PSTREAM_FLAG_LITTLE_ENDIAN             = STREAM_BYTE_ORDER_LITTLE_ENDIAN,   /* send/receive data types in little endian order i.e., do not swap bytes on a little endian platform, swap bytes on a big endian platform */
    PSTREAM_FLAG_BIG_ENDIAN                = STREAM_BYTE_ORDER_BIG_ENDIAN,      /* send/receive data types in big endian order i.e., swap bytes on a little endian platform, do not swap bytes on a big endian platform */
    PSTREAM_FLAG_SWAP_BYTES                = 7,                                 /* always swap bytes regardless of native endianness */
    PSTREAM_FLAG_ENDIAN_MASK               = 7,                                 /* bit mask for endian flags (space is reserved for unusual byte orders) */

    /* Mode flags - the following two flags are mutually exclusive. Only one of them may be specified */
    PSTREAM_FLAG_NON_BLOCKING              = 0,           /* use non-blocking I/O to implement non-blocking connection I/O */
    PSTREAM_FLAG_MULTITHREADED             = (1 << 3),    /* use blocking I/O in separate threads to implement "non-blocking" connection I/O */

    /* Optimization flags - the following two flags are mutually exclusive. Only one of them may be specified */
    PSTREAM_FLAG_MAXIMIZE_THROUGHPUT       = 0,           /* sacrifice latency in order to optimize bandwidth usage */
    PSTREAM_FLAG_MINIMIZE_LATENCY          = (1 << 4),    /* sacrifice bandwidth in order to minimize latency (flush on each send) */

    /* Send flags - the following two flags are mutually exclusive. Only one of them may be specified */
    PSTREAM_FLAG_SEND_ALL                  = 0,           /* send all the data (buffer in FIFO) */
    PSTREAM_FLAG_SEND_MOST_RECENT          = (1 << 5),    /* only send the most recent data */

    /* Receive flags - the following two flags are mutually exclusive. Only one of them may be specified */
    PSTREAM_FLAG_RECEIVE_ALL               = 0,           /* receive all the data (buffer in FIFO) */
    PSTREAM_FLAG_RECEIVE_MOST_RECENT       = (1 << 6),    /* only receive the most recent data */

    /* Variable-dimension flags */
    PSTREAM_FLAG_NO_DIMENSIONS             = (1 << 7)     /* when variable-sized data is being sent, do not send the dimensions in the stream */
} t_pstream_flags;

#define PSTREAM_FLAG_MASK                  0x00ff

typedef enum tag_pstream_state
{
    PSTREAM_STATE_NOT_CONNECTED,  /* no stream connected */
    PSTREAM_STATE_CONNECTING,     /* stream_connect has been called in non-blocking mode */
    PSTREAM_STATE_CONNECTED,      /* stream is connected */
    PSTREAM_STATE_CLOSING,        /* stream is closing */

    NUMBER_OF_PSTREAM_STATES
} t_pstream_state;

typedef struct tag_pstream_poke_state
{
    t_stream_poke_state stream_state;
    char * buffer;
    t_int bytes_to_poke;
    t_uint flags;
} t_pstream_poke_state;

typedef struct tag_pstream_peek_state
{
    t_stream_peek_state stream_state;
    const char * buffer;
    t_int bytes_to_peek;
    t_uint flags;
} t_pstream_peek_state;

typedef struct tag_pstream * t_pstream;

/*
    Name:   t_pstream_options

    Description:

    This structure is used to configure the persistent stream in a call to pstream_listen
    or pstream_connect. It defines how the persistent stream will operate.

    Data Types:

    The Persistent Stream API only allows one data type to be sent and one data type to
    be received. The definition of this data type is defined when the persistent stream
    is created and cannot be changed. The data type is considered atomic. The persistent
    stream functions will only send or receive the entire data type (e.g. an entire
    vector of doubles) and will never send or receive part of the data type.
    
    Two fields of the t_pstream_options structure define the data type for pstream_send 
    operations: send_unit_size and num_send_units. The data type may be considered a vector
    of "units". The size of each "unit" is defined by the send_unit_size field and the 
    number of "units" in the vector is defined by the num_send_units field. For example, 
    to send arrays of 5 doubles, set the send_unit_size field to sizeof(double) and the 
    num_send_units field to 5.
    
    The receive_unit_size and num_receive_units fields define the data type for the
    pstream_receive function in a similar fashion.

    Byte-Swapping and Endianness:

    The definition of a "unit" is important because it is used when the PSTREAM_FLAG_LITTLE_ENDIAN,
    PSTREAM_FLAG_BIG_ENDIAN or PSTREAM_FLAG_SWAP_BYTES flag is set. Setting one of these flags causes
    the pstream_send and pstream_receive functions to swap the bytes in each "unit" when the desired
    endianness does not match the endianness of the platform on which the code is running. For example,
    if the PSTREAM_FLAG_BIG_ENDIAN flag is set and the code is running on a little endian platform
    then byte swapping will be performed. For instance, if send_unit_size is sizeof(double) then it
    will swap the bytes in each double. The ENDIAN flags are useful for communicating between two
    processors with different endianness. Note that both ends of the connection should use the
    same ENDIAN flag. If the PSTREAM_FLAG_NATIVE_ENDIAN flag is set then no byte swapping occurs -
    it simply uses the native endianness of the platform on which the code is running. If the
    PSTREAM_FLAG_SWAP_BYTES flag is set then it always swap bytes, regardless of the native
    endianness of the platform on which the code is running.

    Buffering:

    The Persistent Stream API is built upon the Stream API defined in quanser_stream.h.
    Hence, the underlying stream has a send and receive buffer associated with it. The
    size of the send and receive buffers are defined by the send_buffer_size and
    receive_buffer_size fields respectively. These buffers are defined in bytes and
    must be large enough to hold the send and receive data types respectively. For
    example, if send_unit_size is sizeof(double), or 8 bytes, and num_sent_units is 5,
    then the send_buffer_size must be at least 40 bytes. In general, the send_buffer_size
    must be at least send_unit_size * num_send_units bytes in length. Typically it is
    a multiple of send_unit_size * num_send_units. The same holds true of the
    receive_buffer_size with respect to receive_unit_size * num_receive_units.

    This buffering is particularly important in the non-blocking mode described below
    because it is the only buffering available at the application level in that mode.
    If the current contents of the buffer cannot be transmitted by the pstream_send
    function in one call, then it will append the data to be sent to the stream's send
    buffer and attempt to send the entire contents of the buffer as well as the new
    data on the next call i.e., the data from both pstream_send calls will be sent at
    the same time on the next call to pstream_send, if possible. Thus, the stream buffers
    provide the buffering needed to handle the fluctuating latencies typical of
    communications mediums such as Ethernet, where contention can result in unexpected
    latencies.

    Modes:

    Persistent streams have two modes of operation: non-blocking or multithreaded. In both
    cases the actual pstream functions always return immediately and never block. Instead,
    the mode affects how the persistent stream operates internally when it manages the
    stream.
    
    Non-Blocking Mode:

    If the PSTREAM_FLAG_NON_BLOCKING flag is set in the flags field then the
    persistent stream uses non-blocking I/O to implement the pstream functions. In this
    mode, the persistent stream functions call the underlying Stream API directly so that
    the error codes reflect the errors returned by the Stream API with non-blocking I/O.
    In this mode, it may take longer for the pstream functions to execute depending on
    the underlying protocol and how efficiently it handles non-blocking I/O. Setting
    the PSTREAM_FLAG_NON_BLOCKING flag also means that I/O is only done when a pstream
    function is invoked. No I/O is performed in between calls to the pstream functions
    except in the underlying communication protocol's kernel driver, which will be handling
    interrupts from the communication hardware.

    If the PSTREAM_FLAG_RECEIVE_ALL flag is specified then the pstream_receive function
    will read the next data available out of the stream buffer.
    
    If the PSTREAM_FLAG_RECEIVE_MOST_RECENT flag is specified then the pstream_receive
    function reads all the data available out of the stream buffer but only returns
    the most recent data. The PSTREAM_FLAG_RECEIVE_ALL and PSTREAM_FLAG_RECEIVE_MOST_RECENT 
    flags are mutually exclusive. Only one of these flags  may be specified.

    In non-blocking mode, the PSTREAM_FLAG_SEND_ALL and PSTREAM_FLAG_SEND_MOST_RECENT
    flags behave in the same way. In both cases, the data is simply written to the
    stream buffer if space is available since there are no functions in the underlying
    Stream API for overwriting data in the stream buffer (because part of the data may
    already have been transmitted).


    Multithreaded Mode:

    If the PSTREAM_FLAG_MULTITHREADED flag is set then the persistent stream uses
    multithreaded mode. The PSTREAM_FLAG_NON_BLOCKING and PSTREAM_FLAG_MULTITHREADED flags
    are mutually exclusive. Only one of these flags may be specified. If the
    PSTREAM_FLAG_MULTITHREADED flag is set then the persistent stream API creates two
    threads: a send thread and a receive thread. It then uses blocking I/O in these two
    threads to communicate with the peer. The pstream functions themselves, however, continue
    to return immediately without blocking. How the data is transferred between the pstream
    functions and the send and receive threads depends on the send and receive flags.

    The attributes of the send and receive threads may be specified via the send_thread_attributes
    and receive_thread_attributes fields respectively. These fields may be set to NULL to
    use the default thread attributes. Otherwise the address of a qthread_attr_t variable
    that has been initialized with qthread_attr_init() should be assigned. Refer to the
    quanser_thread.h header file for the different qthread_attr_xxxx functions used for
    configuring thread attributes. The qthread_attr_t variable(s) should be "destroyed" using
    qthread_attr_destroy after calling pstream_connect or pstream_listen. The address of
    the same qthread_attr_t variable may be used for both the send and receive thread
    attributes.
    
    If the PSTREAM_FLAG_SEND_ALL flag is specified then a FIFO queue is used to buffer the
    data between the send thread and the pstream_send function so that all the data sent
    by the pstream_send function is eventually transmitted to the peer by the send thread
    as bandwidth becomes available. Of course, the FIFO queue must be large enough to hold
    all the data to be sent.

    The size of the FIFO queue for send operations is determined by the send_fifo_size
    field. This field indicates the number of samples in the send thread's FIFO queue,
    where one sample is num_send_units * send_unit_size bytes. This field is typically
    greater than one, and should never be zero if the PSTREAM_FLAG_SEND_ALL and
    PSTREAM_FLAG_MULTITHREADED flags are both specified.

    The size of the FIFO queue for receive operations is determined by the receive_fifo_size
    field and has similar semantics.
    
    If the PSTREAM_FLAG_SEND_MOST_RECENT flag is specified then the data is not buffered
    between the send thread and the pstream_send function. The PSTREAM_FLAG_SEND_ALL and
    PSTREAM_FLAG_SEND_MOST_RECENT flags are mutually exclusive. Only one of these flags 
    may be specified. Instead, every call to pstream_send overwrites the data to be sent 
    unless the send thread has already transmitted it. Thus, only the most recent data is
    transmitted.

    Similar semantics exist for the PSTREAM_FLAG_RECEIVE_ALL and PSTREAM_FLAG_RECEIVE_MOST_RECENT
    flags for the receive thread.


    Variable-Size Sending:

    If the max_send_dimensions and num_send_dimensions parameters are defined then the
    persistent stream API supports sending data with variable dimensions. The API
    goes beyond simply a variable number of bytes, but actually supports multidimensional
    data with varying dimensions. The number of dimensions however may not change.

    To send variable-size data, use the pstream_send_with_dimensions function instead of
    pstream_send. If pstream_send is used it will assume the maximum dimensions. In this case,
    the persistent stream API will send the dimensions of the data prior to transmitting
    the data itself, unless the PSTREAM_FLAG_NO_DIMENSIONS flag is set. The API will use the
    minimum integer size required to hold the dimension. For example, if the maximum dimension
    is less than 256, then the API will only send an 8-bit unsigned integer for that dimension.
    Likewise, if the maximum dimension is less than 65536 then it will only send a 16-bit unsigned
    integer for that dimension.

    Note that the send_buffer_size must be large enough to account for both the dimensions
    and the data itself. For example, if a matrix of doubles is being sent, in which the
    maximum matrix dimensions are 12 x 10, then:

        send_unit_size      = sizeof(double) = 8 bytes
        num_send_units      = 12 x 10        = 120 units
        max_send_dimensions = [12, 10]
        num_send_dimensions = 2
        send_buffer_size    = num_send_units * send_unit_size + num_send_dimensions * sizeof(t_uint8)
                            = 120 * 8 + 2 * 1
                            = 962 bytes

    The num_send_dimensions is multiplied by sizeof(t_uint8) because both 12 and 10 are less
    than 256. If max_send_dimensions was [12, 1000] then the number of bytes required would be:

        send_buffer_size    = num_send_units * send_unit_size + size of dimensions
                            = 120 * 8 + sizeof(t_uint8) + sizeof(t_uint16)
                            = 963 bytes

    because 12 fits within a t_uint8 while 1000 fits within a t_uint16 data type.

    To send a 5 x 3 submatrix, invoke:

        pstream_send_with_dimensions(stream, &data, &dims)

    where:
        data = array of 15 doubles containing the elements of the 5 x 3 matrix
        dims = array of 2 unsigned integers with the value: [5, 3]

    Note that the pstream_send_with_dimensions function will return an error if the
    max_send_dimensions and num_send_dimensions have not been defined (i.e. are NULL and zero
    respectively).

    Whether the dimensions are interpreted as row-major or column-major is up to the
    application. The persistent stream API merely communicates the current dimensions
    without interpretation. Note that any byte ordering that has been configured will
    apply to the data only. The dimensions are always transmitted in little endian
    byte order. The dimensions and data together are sent atomically.


    Variable-Size Receiving:

    If the max_receive_dimensions and num_receive_dimensions parameters are defined then the
    persistent stream API supports receiving data with variable dimensions. The API
    goes beyond simply a variable number of bytes, but actually supports multidimensional
    data with varying dimensions. The number of dimensions however may not change.

    To receive variable-size data, use the pstream_receive_with_dimensions function instead of
    pstream_receive. If pstream_receive is used it will assume the maximum dimensions. In this case,
    the persistent stream API will receive the dimensions of the data prior to receiving
    the data itself. The API will use the minimum integer size required to hold the dimension.
    For example, if the maximum dimension is less than 256, then the API will only receive
    an 8-bit unsigned integer for that dimension. Likewise, if the maximum dimension is less
    than 65536 then it will only receive a 16-bit unsigned integer for that dimension.

    Note that the receive_buffer_size must be large enough to account for both the dimensions
    and the data itself. For example, if a matrix of doubles is being received, in which the
    maximum matrix dimensions are 12 x 10, then:

        receive_unit_size      = sizeof(double) = 8 bytes
        num_receive_units      = 12 x 10        = 120 units
        max_receive_dimensions = [12, 10]
        num_receive_dimensions = 2
        receive_buffer_size    = num_receive_units * receive_unit_size + num_receive_dimensions * sizeof(t_uint8)
                               = 120 * 8 + 2 * 1
                               = 962 bytes

    The num_receive_dimensions is multiplied by sizeof(t_uint8) because both 12 and 10 are less
    than 256. If max_receive_dimensions was [12, 1000] then the number of bytes required would be:

        receive_buffer_size = num_receive_units * receive_unit_size + size of dimensions
                            = 120 * 8 + sizeof(t_uint8) + sizeof(t_uint16)
                            = 963 bytes

    because 12 fits within a t_uint8 while 1000 fits within a t_uint16 data type.

    To receive a 5 x 3 submatrix, invoke:

        pstream_receive_with_dimensions(stream, &data, &dims)

    where:
        data = array of 15 doubles which will receive the elements of the 5 x 3 matrix
        dims = array of 2 unsigned integers which will receive the values: [5, 3]

    Note that the pstream_receive_with_dimensions function will return an error if the
    max_receive_dimensions and num_receive_dimensions have not been defined (i.e. are NULL and zero
    respectively).

    Whether the dimensions are interpreted as row-major or column-major is up to the
    application. The persistent stream API merely communicates the current dimensions
    without interpretation. Note that any byte ordering that has been configured will
    apply to the dimensions as well as the data itself. The dimensions and data together
    are received atomically.


    Fields:

    size                        = set this field to sizeof(t_pstream_options)
    flags                       = a bitwise combination of the t_pstream flags defined above
    send_unit_size              = the size of one "unit" for pstream_send operations. e.g. sizeof(t_double)
    num_send_units              = the number of units for pstream_send operations e.g. 5 for a 5-vector of "units"
    send_buffer_size            = the size in bytes of the underlying t_stream's send buffer
    send_fifo_size              = the size of the FIFO queue in samples (one sample is send_unit_size * num_send_units bytes)
                                  to use in multithread mode. This field is ignored in non-blocking mode.
    send_thread_attributes      = the attributes of the send thread. This field may be NULL to use default
                                  attributes. This field is ignored in non-blocking mode.
    receive_unit_size           = the size of one "unit" for pstream_receive operations. e.g. sizeof(t_double)
    num_receive_units           = the number of units for pstream_receive operations e.g. 5 for a 5-vector of "units"
    receive_buffer_size         = the size in bytes of the underlying t_stream's receive buffer
    receive_fifo_size           = the size of the FIFO queue in samples (one sample is receive_unit_size * num_receive_units bytes)
                                  to use in multithread mode. This field is ignored in non-blocking mode.
    receive_thread_attributes   = the attributes of the receive thread. This field may be NULL to use default
                                  attributes. This field is ignored in non-blocking mode.
    max_send_dimensions         = the maximum dimensions of the data sent. May be NULL to use fixed-size data. If non-NULL, then
                                  the product of the dimensions must equal num_send_units.
    num_send_dimensions         = the number of dimensions in the max_send_dimensions array. Set to zero if max_send_dimensions is NULL.
    max_receive_dimensions      = the maximum dimensions of the data received. May be NULL to use fixed-size data. If non-NULL, then
                                  the product of the dimensions must equal num_receive_units.
    num_receive_dimensions      = the number of dimensions in the max_receive_dimensions array. Set to zero if max_receive_dimensions is NULL.
*/
typedef struct tag_pstream_options
{
    size_t              size;                       /* Size of t_pstream_options structure in bytes. Set to sizeof(t_pstream_options). */
    t_uint8             flags;                      /* One or more flags from t_pstream_flags enumeration */

    t_int               send_unit_size;             /* Size of each unit that will be sent when pstream_send called */
    t_int               num_send_units;             /* Number of units that will be sent (atomically) when pstream_send called */
    t_int               send_buffer_size;           /* Buffer size in bytes to use for stream for sending data (must be >= send_unit_size * num_send_units) */
    t_int               send_fifo_size;             /* Buffer size in samples to use for FIFO for transferring data to send thread */
    qthread_attr_t *    send_thread_attributes;     /* Used to create send thread if PSTREAM_FLAG_MULTITHREADED flag set (may be NULL to use default thread attributes) */

    t_int               receive_unit_size;          /* Size of each unit that will be sent when pstream_receive called */
    t_int               num_receive_units;          /* Number of units that will be received (atomically) when pstream_receive called */
    t_int               receive_buffer_size;        /* Buffer size to use for stream for receiving data (must be >= receive_unit_size * num_receive_units) */
    t_int               receive_fifo_size;          /* Buffer size in samples to use for FIFO for transferring data from receive thread */
    qthread_attr_t *    receive_thread_attributes;  /* Used to create receive thread if PSTREAM_FLAG_MULTITHREADED flag set (may be NULL to use default thread attributes) */

    t_uint *            max_send_dimensions;        /* Maximum dimensions for the data sent. Set to NULL to use fixed-size signals. Product of dimensions must equal num_send_units. */
    t_uint              num_send_dimensions;        /* Number of dimensions for the data sent. Set to zero to use fixed-size signals. */

    t_uint *            max_receive_dimensions;     /* Maximum dimensions for the data received. Set to NULL to use fixed-size signals. Product of dimensions must equal num_receive_units. */
    t_uint              num_receive_dimensions;     /* Number of dimensions for the data received. Set to zero to use fixed-size signals. */
} t_pstream_options;

/*
    Name:   pstream_listen

    Description:

    This function creates a listening stream according to the given URI.
    The URI specifies the protocol, address, port and options associated with
    the stream. The Persistent Stream API uses the protocol to load a protocol-specific
    driver. For example:

        tcpip://localhost:17000             - listen on TCP/IP port 17000
        shmem://mymemory:1?bufsize=8192     - listen on shared memory "mymemory", port 1, using a default 8K shared memory buffer
        pipe:mypipe?bufsize=4096            - listen on named pipe "mypipe" using a default 4K buffer size

    This function creates a persistent server. Persistent servers listen for
    and accept a connection from a single client and then communicate with that
    client. If the current client disconnects then a new client may connect. Only
    one client at a time is supported.

    The options parameter is a pointer to a t_pstream_options structure that must be
    fully initialized. See the help for the t_pstream_options structure above for
    details.

    This function always returns immediately, even if no connection is established with
    a client yet. Subsequent calls to pstream_send or pstream_receive will complete the
    connection if a client is attempting to connect.
    
    If the persistent stream is created successfully then 0 is returned. Otherwise
    a negative error code is returned and the persistent stream could not be created and should 
    not be used.

    The connection must be closed using pstream_close when it is no longer needed.
    
    Parameters:

    uri                 = a URI indicating the listening stream to which to connect.
    options             = a pointer to a t_pstream_options structure containing the various options
    connection          = a pointer to a t_pstream variable in which the persistent client stream
                          handle will be stored. It will be NULL if the stream could not be created.

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned. In this
    case the persistent stream is invalid and should not be used.
*/
EXTERN t_error
pstream_listen(const char * uri, t_pstream_options * options, t_pstream * connection);

/*
    Name:   pstream_connect

    Description:

    This function connects to a listening stream referenced by the given URI.
    The URI specifies the protocol, address, port and options associated with
    the stream. The Persistent Stream API uses the protocol to load a protocol-specific
    driver. For example:

        tcpip://remotehost:17000            - connect to remotehost on port 17000 using TCP/IP
        shmem://mymemory:1?bufsize=8192     - connect via an 8K shared memory buffer
        pipe:mypipe?bufsize=4096            - connect via a 4K named pipe

    The options parameter is a pointer to a t_pstream_options structure that must be
    fully initialized. See the help for the t_pstream_options structure above for
    details.

    This function always returns immediately, even if the connection is not yet established.
    Subsequent calls to pstream_send or pstream_receive will complete the connection.

    If the persistent stream is created successfully then 0 is returned. Otherwise
    a negative error code is returned and the persistent stream could not be created and should 
    not be used.

    The connection must be closed using pstream_close when it is no longer needed.
    
    Parameters:

    uri                 = a URI indicating the listening stream to which to connect.
    options             = a pointer to a t_pstream_options structure containing the various options
    connection          = a pointer to a t_pstream variable in which the persistent client stream
                          handle will be stored. It will be NULL if the stream could not be created.

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned. In this
    case the persistent stream is invalid and should not be used.
*/
EXTERN t_error
pstream_connect(const char * uri, t_pstream_options * options, t_pstream * connection);

/*
    Name:   pstream_receive

    Description:

    This function receives data from the peer. The number of bytes received will be
    num_receive_units * receive_unit_size. Hence, the supplied buffer must be at least
    this number of bytes in length. It returns 1 if the data is received successfully.
    
    If it could not receive data without blocking then -QERR_WOULD_BLOCK is returned. In this
    case no data is returned but the connection is still established with the peer. This function
    never blocks waiting for data to arrive.
    
    If there is no connection or an error occurred receiving the data then a negative error code
    is returned. However, it is not necessary to call pstream_close to close the connection.
    The t_pstream is still valid and may still be used. Instead, the error may effectively be 
    ignored because the next call to pstream_receive will attempt to re-establish the connection. 
    In fact, in multithreaded mode, the connection may be reestablished in between calls to 
    pstream_receive so that the next call to pstream_receive will return new data from the client.
    
    Parameters:

    connection  = the t_pstream returned by pstream_connect or pstream_listen
    buffer      = a buffer to receive the data. It must be at least 
                  receive_unit_size * num_receive_units bytes in length.

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned. However, it
    the t_pstream need not be closed and may still be used because the next call to pstream_receive
    will automatically attempt to re-establish the connection.
*/
EXTERN t_int
pstream_receive(t_pstream connection, void * buffer);

/*
    Name:   pstream_receive_with_dimensions

    Description:

    This function receives variable-size data from the peer. The dimensions of the data are
    received followed by the data itself.  The number of bytes of data received will be
    less than or equal to num_receive_units * receive_unit_size. Hence, the supplied buffer must be
    at least this number of bytes in length. It returns 1 if the data is received successfully.
    
    If it could not receive data without blocking then -QERR_WOULD_BLOCK is returned. In this
    case no data is returned but the connection is still established with the peer. This function
    never blocks waiting for data to arrive.
    
    If there is no connection or an error occurred receiving the data then a negative error code
    is returned. However, it is not necessary to call pstream_close to close the connection.
    The t_pstream is still valid and may still be used. Instead, the error may effectively be 
    ignored because the next call to pstream_receive_with_dimensions will attempt to re-establish the connection. 
    In fact, in multithreaded mode, the connection may be reestablished in between calls to 
    pstream_receive_with_dimensions so that the next call to pstream_receive will return new data from the client.
    
    Parameters:

    connection  = the t_pstream returned by pstream_connect or pstream_listen
    buffer      = a buffer to receive the data. It must be at least 
                  receive_unit_size * num_receive_units bytes in length. The actual
                  number of bytes stored will be the product of the dimensions
                  returned in the dimensions parameter and the receive_unit_size.
    dimensions  = a buffer to receive the actual dimensions of the data in buffer. It
                  must be at least num_receive_dimensions in length. The dimensions
                  will not exceed the maximum dimensions specified in the
                  max_receive_dimensions array when the persistent stream was created.

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned. However,
    the t_pstream need not be closed if the connection were lost and may still be used because
    the next call to pstream_receive_with_dimensions will automatically attempt to re-establish
    the connection. If invalid dimensions are received then a -QERR_INVALID_DIMENSIONS error will
    be returned and the stream will have to be closed.
*/
EXTERN t_int
pstream_receive_with_dimensions(t_pstream connection, void * buffer, t_uint * dimensions);

/*
    Name:   pstream_send

    Description:

    This function sends data to the peer. The number of bytes sent will be
    num_send_units * send_unit_size. Hence, the supplied buffer must be at least
    this number of bytes in length. It returns 1 if the data is sent successfully.
    
    If it could not send the data without blocking then -QERR_WOULD_BLOCK is returned. In this
    case, the data will be added to the stream send buffer but will not be sent immediately.
    However, the connection is still established with the peer. This function
    never blocks waiting for data to sent.
    
    If there is no connection or an error occurred sending the data then a negative error code
    is returned. However, it is not necessary to call pstream_close to close the connection.
    The t_pstream is still valid and may still be used. Instead, the error may effectively be 
    ignored because the next call to pstream_send will attempt to re-establish the connection. 
    In fact, in multithreaded mode, the connection may be reestablished in between calls to 
    pstream_send so that the next call to pstream_send will succeed in sending the new data to
    the client.
    
    Parameters:

    connection  = the t_pstream returned by pstream_connect or pstream_listen
    buffer      = a buffer containing the data to be sent. It must be at least 
                  send_unit_size * num_send_units bytes in length.

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned. However, it
    the t_pstream need not be closed and may still be used because the next call to pstream_send
    will automatically attempt to re-establish the connection.
*/
EXTERN t_int
pstream_send(t_pstream connection, const void * buffer);

/*
    Name:   pstream_send_with_dimensions

    Description:

    This function sends variable-size data to the peer. The dimensions of the data are sent
    followed by the data itself, unless the PSTREAM_FLAG_NO_DIMENSIONS flag is set. The number
    of bytes of data sent will be less than or equal to num_send_units * send_unit_size. Hence,
    the supplied buffer must be at least this number of bytes in length. It returns 1 if the data
    is sent successfully.
    
    If it could not send data without blocking then -QERR_WOULD_BLOCK is returned. In this
    case no data is returned but the connection is still established with the peer. This function
    never blocks waiting for data to arrive.
    
    If there is no connection or an error occurred sending the data then a negative error code
    is returned. However, it is not necessary to call pstream_close to close the connection.
    The t_pstream is still valid and may still be used. Instead, the error may effectively be 
    ignored because the next call to pstream_send_with_dimensions will attempt to re-establish the connection. 
    In fact, in multithreaded mode, the connection may be reestablished in between calls to 
    pstream_send_with_dimensions so that the next call to pstream_send will return new data from the client.
    
    Parameters:

    connection  = the t_pstream returned by pstream_connect or pstream_listen
    buffer      = a buffer of data to send. The number of bytes required in the
                  buffer is the product of the dimensions passed in the dimensions
                  parameter and the send_unit_size.
    dimensions  = a buffer containing the actual dimensions of the data in buffer. It
                  must be at least num_send_dimensions in length. The dimensions
                  must not exceed the maximum dimensions specified in the
                  max_send_dimensions array when the persistent stream was created or
                  a fatal error will be returned.

    Return value:

    Returns 0 on success. If an error occurs then a negative error code is returned. However,
    the t_pstream need not be closed if the connection were lost and may still be used because
    the next call to pstream_send_with_dimensions will automatically attempt to re-establish
    the connection. If invalid dimensions are sent then a -QERR_INVALID_DIMENSIONS error will
    be returned and no data will be sent.
*/
EXTERN t_int
pstream_send_with_dimensions(t_pstream connection, const void * buffer, const t_uint * dimensions);

/*
    Description:

    This function prepares the t_pstream_peek_state to begin peeking data from the persistent stream. 
    "Peeking" involves reading from the stream buffer without updating the buffer pointers. It is 
    particularly useful for reading mixed data types from the persistent stream while ensuring that 
    byte swapping is performed correctly. The "peek state" is used to keep track of how much data 
    has been peeked from the stream so far.

    The stream_peek_end function must be called to end the peek operation. Failure to do so
    may potentially cause deadlock the next time stream_peek_begin is called.

    As an example of using the peek capabilities to read a sequence of data types as a single
    atomic unit:

    t_pstream_peek_state state;

    result = pstream_peek_begin(stream, &state);
    if (result > 0) {

        result = pstream_peek_int(stream, &state, 5);
        if (result > 0) {
            result = pstream_peek_double(stream, &state, 3.14);
        }

        result = pstream_peek_end(stream, &state, result);
    }

    In this example, the code peeks an integer and a double from the input stream. The data
    is not removed from the stream buffer but is maintained in the buffer until pstream_peek_end
    is called. If at any time the operation would block because there is not enough space
    in the stream buffer, then -QERR_WOULD_BLOCK is returned. In this case, stream_peek_end
    does not advance the input stream and the same peeked data will be read the next time
    data is read or peeked from the stream. The pstream_peek_end returns the same error,
    -QERR_WOULD_BLOCK, to make it easier to propagate the error code.

    However, if the pstream_peek_int and pstream_peek_double succeed then when pstream_peek_end is
    called the stream pointer is advanced. Hence, the data is removed from the input stream
    and subsequent sends/peeks to the stream will receive new data. In this case, pstream_peek_end
    returns one.
 
    Thus, the integer and double are read as one atomic unit from the input stream, because
    if not enough data is available, then nothing is read from the input stream. Only if both
    quantities are read successfully is the data actually removed from the input stream.

    Note that the pstream_peek_xxxx functions may receive data from the underlying communication
    channel, but the data being peeked is never removed from the input stream until pstream_peek_end
    is called to indicate that the peeked data may be removed from the input stream.

    This function assumes that the stream is valid.

    Parameters:

    stream    = a persistent stream established using pstream_connect or pstream_listen.
    state     = the "peek state" to initialize.

    Return value:

    This function only returns an error if one of the parameters is invalid or the
    stream is shutdown or invalid. It returns 1 on success. If it returns zero it means
    the underlying connection was closed gracefully by the peer, but the persistent stream
    may still be used as it will reconnect the next time it is used.
 */
EXTERN t_int
pstream_peek_begin(t_pstream connection, t_pstream_peek_state * state);

EXTERN t_int
pstream_peek_unit_array(t_pstream connection, t_pstream_peek_state * state, void * units, t_int unit_size, t_int num_units);

EXTERN t_int
pstream_peek_end(t_pstream connection, t_pstream_peek_state * state, t_error status);

/*
    Description:

    This function prepares the t_pstream_poke_state to begin poking data to the persistent stream. 
    "Poking" involves writing to the stream buffer without writing to the underlying communication
    channel or updating the buffer pointers. It is particularly useful for writing mixed data types
    to the persistent stream while ensuring that byte swapping is performed correctly. The "poke 
    state" is used to keep track of how much data has been poked into the stream so far.

    The stream_poke_end function must be called to end the poke operation. Failure to do so
    may potentially cause deadlock the next time stream_poke_begin is called.

    As an example of using the poke capabilities to write a sequence of data types as a single
    atomic unit:

    t_pstream_poke_state state;

    result = pstream_poke_begin(stream, &state);
    if (result == 0) {
 
        result = pstream_poke_int(stream, &state, 5);
        if (result > 0) {
            result = pstream_poke_double(stream, &state, 3.14);
        }

        result = pstream_poke_end(stream, &state, result);
    }

    In this example, the code pokes an integer and a double into the output stream. The data
    is not transmitted over the underlying communication channel but is maintained in the
    stream buffer. If at any time the operation would block because there is not enough space
    in the stream buffer, then -QERR_WOULD_BLOCK is returned. In this case, stream_poke_end
    does not advance the output stream and the poked data is discarded and not sent to the 
    output stream. Hence, the next time the code is called it may write the same data again 
    without the peer receiving two copies. The pstream_poke_end returns the same error,
    -QERR_WOULD_BLOCK, to make it easier to propagate the error code.

    However, if the pstream_poke_int and pstream_poke_double succeed then when pstream_poke_end is
    called the stream pointer is advanced. Hence, the data will be sent to the output
    stream the next time the stream is flushed and subsequent sends/pokes to the stream 
    will send new data. In this case, pstream_poke_end returns one. If the persistent stream
    is configured to minimize latency, then the stream is flushed right away.

    Thus, the integer and double are sent as one atomic unit to the output stream, because
    if not enough space is available in the stream buffer, then nothing is written to the
    output stream. Only if both quantities are written successfully is the data actually 
    sent to the output stream.

    Note that the pstream_poke_xxxx functions may send data to the underlying communication
    channel (that remained from previous send operations), but the data being poked is never 
    sent until pstream_poke_end is called to indicate that the poked data may be sent to the 
    output stream.

    This function assumes that the stream is valid.

    Parameters:

    stream    = a persistent stream established using pstream_connect or pstream_listen.
    state     = the "poke state" to initialize.

    Return value:

    This function only returns an error if one of the parameters is invalid or the
    stream is shutdown or closed.
*/
EXTERN t_int
pstream_poke_begin(t_pstream connection, t_pstream_poke_state * state);

/*
    Name:   pstream_poke_unit_array

    Description:

    This function writes an array of "units" to the stream buffer, where the size
    of a "unit" is determined by the unit_size parameter. It attempts to store the
    "units" in the stream buffer. It either writes all of the array or none of it. 
    If there is enough room available in the stream buffer then it stores the data 
    in the buffer and returns immediately. However, the stream pointer is not
    advanced, so the data is not written to the actual communication channel. The data
    will only allowed to be written to the underlying communication channel if 
    stream_poke_end is called. If an error occurs, then it returns a negative error 
    code. If the connection is closed it is considered an error condition.

    If the stream has been configured to swap bytes then this function will swap the 
    order of the bytes within each unit when they are poked.

    If persistent stream is blocking then this function may block attempting to flush the
    stream buffer (to write out data previously sent and still waiting in the stream buffer). 
    Once the entire array is poked into the buffer then 1 is returned. If an error occurs then
    the error code is returned.

    If the persistent stream is non-blocking then this function does not block. It returns 1
    on success. If the entire array could not be poked without blocking, then -QERR_WOULD_BLOCK
    is returned. If an error occurs then the error code is returned.

    This function does not support two threads poking or flushing data at the same time.
    However, data may be poked or the stream flushed by another thread at the same time as
    data is being received.

    The BSD socket API has no equivalent to this function.

    Parameters:

    stream       = a persistent stream established using pstream_connect or pstream_listen.
    state        = the poke state initialized using pstream_poke_begin.
    units        = the array to be poked.
    unit_size    = the size of one element in the array
    num_units    = the number of elements in the array to poke

    Return value:

    Returns 1 on success. If an error occurs then a negative error code is returned.
*/
EXTERN t_int
pstream_poke_unit_array(t_pstream connection, t_pstream_poke_state * state, const void * units, t_int unit_size, t_int num_units);

/*
    Description:

    This function finishes a "poke" operation by updating the stream buffer pointers so
    that all poked data is now marked as written to the stream. It must be called to end
    a poke operation.

    If the status argument is one then it advances the output stream and the data
    is sent to the underlying output stream to make room for new data. If the status argument
    is less than one then the poked data is discarded.

    The status argument is generally the result of the last pstream_poke_xxxx operation.
    Refer to the pstream_poke_begin function for an example.

    This function assumes that the stream is valid.

    Parameters:

    stream    = a persistent stream established using pstream_connect or pstream_listen.
    state     = the "poke state" indicating how much data to add to the output stream.
    status    = this value is typically the result from the last pstream_poke_xxxx operation.
                If it is 1 then the poke is completed and the data is sent. If it is negative
                then the data is not sent and the status is returned as the result.

    Return value:

    This function returns an error if one of the parameters is invalid or the
    status argument is negative. It returns one if the status argument is one 
    and the peek is completed successfully. 
*/
EXTERN t_int
pstream_poke_end(t_pstream connection, t_pstream_poke_state * state, t_error status);

/*
    Name:   pstream_get_state

    Description:

    This function returns the current state of the connection with the peer.
    It returns the current state in the t_pstream_state variable passed as
    an argument. This enumerated type is defined above and indicates whether
    a connection is currently established with a peer, or is in the process
    of being established, or is not established or closing.
    
    Parameters:

    connection  = the t_pstream returned by pstream_connect or pstream_listen
    state       = the address of a t_pstream_state variable to receive the
                  current state of the connection.

    Return value:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
pstream_get_state(t_pstream connection, t_pstream_state * state);

/*
    Name:   pstream_shutdown

    Description:

    This function shuts down the persistent stream. The stream must still be
    closed using pstream_close. The pstream_shutdown function ensures that
    the current connection to the peer is shut down, if any, and that no
    new connections will be accepted. It is useful in multithreaded applications
    where one thread is used to shut down the connection, but another thread
    actually closes the stream.
    
    Parameters:

    connection  = the t_pstream returned by pstream_connect or pstream_listen

    Return value:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
pstream_shutdown(t_pstream connection);

/*
    Name:   pstream_close

    Description:

    This function closes the persistent stream. It stops the send and receive threads
    if multithreaded mode is in use. It also frees any system resources used by the
    persistent stream.
    
    Parameters:

    connection  = the t_pstream returned by pstream_connect or pstream_listen

    Return value:

    Returns 0 on success. Otherwise it returns a negative error code.
*/
EXTERN t_error
pstream_close(t_pstream connection);

#endif
