/*
 * Filename: quanser_ublox.h
 *
 * Created on: August 19, 2008
 *
 * Version: 1.0
 *
 * Purpose: contains an API for interfacing the ublox GPS unit
 *
 * Last Modified:
 *
 * Notice: This code is the sole property of Quanser Inc. It may not be copied, modified
 *         or sold without the permission of Quanser Inc. Under no circumstances shall this
 *         notice, or the copyright be removed.
 *
 * Copyright �2008 Quanser Inc.
 * $Revision: 1.0 $
*/
#if !defined(_quanser_ublox_h)
#define _quanser_ublox_h

#include "quanser_extern.h"
#include "quanser_errors.h"
#include "quanser_types.h"
#include "quanser_thread.h"

typedef struct tag_ubloxdata * t_ubloxdata; /* GPS data */
typedef struct tag_ublox     * t_ublox;     /* stream reference */

EXTERN t_error
ublox_initialize(const char * uri, t_int send_buffer_size, t_int receive_buffer_size, t_ublox * ublox);

EXTERN t_error
ublox_shutdown(t_ublox ublox);

EXTERN t_error
ublox_close(t_ublox ublox);

EXTERN t_error
ublox_initialize_data(t_ubloxdata gpsdata);

EXTERN t_error
ublox_get_data(t_ublox ublox, t_ubloxdata gpsdata);

EXTERN t_error
ublox_convert_to_utm(t_double lat, t_double lon, t_double *X, t_double *Y);

EXTERN t_error
ublox_initialize_gpsdata(t_ubloxdata * gpsdata);

EXTERN t_error
ublox_release_gpsdata(t_ubloxdata * gpsdata);


EXTERN t_error
ublox_get_gpsdata_type(t_int data_index);

EXTERN t_error
ublox_get_gpsdata_length(t_int data_index);

EXTERN t_error
ublox_access_gpsdata(t_ubloxdata gpsdata, t_int data_index, void * gpsdata_field);

EXTERN t_error
ublox_initialize_thread(const char * uri, t_int send_buffer_size, t_int receive_buffer_size, qthread_attr_t * attributes, 
                        t_ublox * ublox);

EXTERN t_error
ublox_close_thread(t_ublox ublox);

EXTERN t_error
ublox_get_data_thread(t_ublox ublox, t_ubloxdata gpsdata);

EXTERN t_error
ublox_get_speed(t_ubloxdata gpsdata, t_double * speed, t_double * course);

EXTERN t_error
ublox_get_xyz(t_ubloxdata gpsdata, t_double * x, t_double * y, t_double * z);

EXTERN t_error
ublox_get_latlonalt(t_ubloxdata gpsdata, t_double * lat, t_double * lon, t_double * alt);

EXTERN t_error
ublox_data_accuracy(t_ubloxdata gpsdata, t_double * hdop, t_double * vdop, t_double * pdop, 
                    t_double * posfix, t_double * satinfix, t_double * satinview);

#endif

