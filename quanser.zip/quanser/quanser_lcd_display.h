#if !defined(_quanser_lcd_display_h)
#define _quanser_lcd_display_h

#include "quanser_extern.h"
#include "quanser_errors.h"
#include "quanser_types.h"
#include "quanser_video.h" /* for t_image_format */
#include <stdarg.h>

/*
* Access to the LCD can be shared, asynchronous or exclusive:
* 
* Shared:
*   In shared mode, the LCD may be shared by multiple processes and only holds a global mutex while actually writing to the display. 
*   Hence, two processes can write to the display and will not corrupt each other's messages. If one process currently holds the
*   mutex, the other will simply wait for it to finish its operation and then it will grab the mutex and write to the display.
*   The net effect is that the message from the second process may replace the message from the first process.
*
* Asynchronous:
*   In asynchronous mode, the LCD may be shared by multiple processes and only holds a global mutex while actually writing to the display.
*   Hence, two processes can write to the display and will not corrupt each other's messages. However, in this case, if one process currently 
*   holds the mutex, the other will simply skip its write operation and not do anything. The net effect is that the message from the second
*   process is not displayed. This mode is typically used in combination with a process in LCD_ACCESS_EXCLUSIVE mode so that the process with
*   exclusive access (e.g. a QUARC model) takes priority until it finishes with the LCD. For example, asynchronous mode is used by the QUARC
*   Power Monitor to access the LCD so it takes lower priority than other processes.
*
* Exclusive:
*   In exclusive mode, the LCD is not shared by multiple processes. It holds the global mutex for the whole time the LCD is open. If another
*   process tries to open the LCD in exclusive mode it will return -QERR_BUSY indicating that the LCD is in use.
*/
typedef enum tag_lcd_access
{
    LCD_ACCESS_SHARED,              /* multiple processes can access the LCD at the same time but hold a global mutex while actually writing to the display. Waits for mutex to be released */
    LCD_ACCESS_ASYNCHRONOUS,        /* multiple processes can access the LCD at the same time but hold a global mutex while actually writing to the display. Skips write if mutex already held by another process */
    LCD_ACCESS_EXCLUSIVE            /* only one process can access the LCD at a time (global mutex is held as long as the LCD is open) */
} t_lcd_access;

typedef enum tag_touch_event
{
    TOUCH_EVENT_DOWN,
    TOUCH_EVENT_UP,
    TOUCH_EVENT_CONTACT,
    TOUCH_EVENT_NONE
} t_touch_event;

typedef enum tag_touch_direction
{
    TOUCH_DIRECTION_UP,
    TOUCH_DIRECTION_DOWN,
    TOUCH_DIRECTION_LEFT,
    TOUCH_DIRECTION_RIGHT
} t_touch_direction;

typedef enum tag_touch_speed
{
    TOUCH_SPEED_STATIC,
    TOUCH_SPEED_NORMAL,
    TOUCH_SPEED_HIGH
} t_touch_speed;

typedef struct tag_lcd_touch_finger
{
    t_uint16 r, c;      /* row, column coordinates of the finger position */
    t_uint8 event;      /* 0 = put down, 1 = put up, 2 = contact, 3 = no event */
    t_uint8 id;         /* touch identifier */
    t_uint8 weight;     /* touch weight (valid points in X * valid points in Y / 2) */
    t_uint8 speed;      /* 0 = static, 1 = normal speed, 2 = high speed */
    t_uint8 direction;  /* 0 = up, 1 = down, 2 = left, 3 = right */
    t_uint8 area;       /* touch area */
} t_lcd_touch_finger;

typedef enum tag_touch_gesture
{
    TOUCH_GESTURE_NONE,

    TOUCH_GESTURE_SINGLE_PAN_NORTH    = 0x10,
    TOUCH_GESTURE_SINGLE_PAN_EAST     = 0x14,
    TOUCH_GESTURE_SINGLE_PAN_SOUTH    = 0x18,
    TOUCH_GESTURE_SINGLE_PAN_WEST     = 0x1C,
    TOUCH_GESTURE_SINGLE_CLICK        = 0x20,
    TOUCH_GESTURE_DOUBLE_CLICK        = 0x22,
    TOUCH_GESTURE_SINGLE_ROTATE_RIGHT = 0x28,
    TOUCH_GESTURE_SINGLE_ROTATE_LEFT  = 0x29,
    TOUCH_GESTURE_ZOOM_IN             = 0x48,
    TOUCH_GESTURE_ZOOM_OUT            = 0x49,
    TOUCH_GESTURE_DOUBLE_ROTATE_LEFT  = 0x81,
    TOUCH_GESTURE_DOUBLE_ROTATE_RIGHT = 0x82
} t_touch_gesture;

typedef struct tag_lcd_touch
{
    t_lcd_touch_finger fingers[10]; /* up to 10 fingers */
    t_uint8 num_fingers;            /* number of valid fingers */
    t_uint8 gesture;                /* see t_touch_gesture enumeration */
} t_lcd_touch;

typedef struct tag_st7032*  t_st7032;
typedef struct tag_st7066u* t_st7066u;
typedef struct tag_ws0010*  t_ws0010;
typedef struct tag_ls012b7dd01* t_ls012b7dd01;
typedef struct tag_ls027b7dh01* t_ls027b7dh01;
typedef struct tag_mech_sensors_trainer_lcd* t_mech_sensors_trainer_lcd;

/*
** Opens the ST7032 (or NewHaven NHD-C0216C0Z display). A typical URI for an I2C
** connection to the display is "i2c-cpu://localhost:8?address=0x3E,baud=100000,lsb=1"
*/
EXTERN t_error
st7032_open(const char * uri, t_st7032 * display);

/*
** Print to the display. Unrecognized characters are skipped. If more than 16
** characters would be printed on a line then the line is truncated. A newline will
** cause the characters to be displayed on the next line. As there are only two
** lines on the display there should only be one newline in the format string.
**
** Printing starts at the given line and column. Line 0 is the first line and
** column 0 is the first column. For example:
**  st7032_print(display, 0, 0, "Hello world")
** will print "Hello world" starting in the top, left corner of the display.
**
** The format string is UTF-8 and does support Unicode (particularly, Katakana
** characters).
*/
EXTERN t_int
st7032_print(t_st7032 display, t_uint line, t_uint column, const char * message, size_t length);

EXTERN t_int
st7032_wprint(t_st7032 display, t_uint line, t_uint column, const wchar_t * message, size_t length);

#if defined(_UNICODE)
#define st7032_tprint(display, line, column, message) st7032_wprint(display, line, column, message, length)
#else
#define st7032_tprint(display, line, column, message) st7032_print(display, line, column, message, length)
#endif

/*
** Defines the character associated with the given character code. Valid character codes
** are 0x10 to 0x17 i.e., '\020' to '\027'. Using these characters will produce the
** bitmap defined in the pattern for that character.
**
** The pattern defines each line of the character being defined, with the five bits
** in each t_uint8 defining the pixels of that line. For example to define the letter T,
** the pattern would be:
**      pattern[0] = 0b00011111 (0x1F)
**      pattern[1] = 0b00000100 (0x40)
**      pattern[2] = 0b00000100 (0x40)
**      pattern[3] = 0b00000100 (0x40)
**      pattern[4] = 0b00000100 (0x40)
**      pattern[5] = 0b00000100 (0x40)
**      pattern[6] = 0b00000100 (0x40)
**      pattern[7] = 0b00000000 (0x00) <= should generally be zero to allow for cursor
** Note that only bits 0-4 are used. Bit 0 is the rightmost pixel and bit 4 is the leftmost pixel.
*/
EXTERN t_error
st7032_set_character(t_st7032 display, t_int code, const t_uint8 pattern[8]);

/*
** Close the display, freeing up allocated resources.
*/
EXTERN t_error
st7032_close(t_st7032 display);

/*
** Opens the ST7066u (or NewHaven NHD-0216K1Z-NSW-FBW-L display). A typical URI for a serial
** connection to the display is "serial://localhost:8?address=0x3E,baud=100000,lsb=1"
*/
EXTERN t_error
st7066u_open(const char* uri, t_st7066u* display);

/*
** Print to the display. Unrecognized characters are skipped. If more than 16
** characters would be printed on a line then the line is truncated. A newline will
** cause the characters to be displayed on the next line. As there are only two
** lines on the display there should only be one newline in the format string.
**
** Printing starts at the given line and column. Line 0 is the first line and
** column 0 is the first column. For example:
**  st7066u_print(display, 0, 0, "Hello world")
** will print "Hello world" starting in the top, left corner of the display.
**
** The format string is UTF-8 and does support Unicode (particularly, Katakana
** characters).
*/
EXTERN t_int
st7066u_print(t_st7066u display, t_uint line, t_uint column, const char* message, size_t length);

EXTERN t_int
st7066u_wprint(t_st7066u display, t_uint line, t_uint column, const wchar_t* message, size_t length);

#if defined(_UNICODE)
#define st7066u_tprint(display, line, column, message) st7066u_wprint(display, line, column, message, length)
#else
#define st7066u_tprint(display, line, column, message) st7066u_print(display, line, column, message, length)
#endif

/*
** Defines the character associated with the given character code. Valid character codes
** are 0x10 to 0x17 i.e., '\020' to '\027'. Using these characters will produce the
** bitmap defined in the pattern for that character.
**
** The pattern defines each line of the character being defined, with the five bits
** in each t_uint8 defining the pixels of that line. For example to define the letter T,
** the pattern would be:
**      pattern[0] = 0b00011111 (0x1F)
**      pattern[1] = 0b00000100 (0x40)
**      pattern[2] = 0b00000100 (0x40)
**      pattern[3] = 0b00000100 (0x40)
**      pattern[4] = 0b00000100 (0x40)
**      pattern[5] = 0b00000100 (0x40)
**      pattern[6] = 0b00000100 (0x40)
**      pattern[7] = 0b00000000 (0x00) <= should generally be zero to allow for cursor
** Note that only bits 0-4 are used. Bit 0 is the rightmost pixel and bit 4 is the leftmost pixel.
*/
EXTERN t_error
st7066u_set_character(t_st7066u display, t_int code, const t_uint8 pattern[8]);

/*
** Close the display, freeing up allocated resources.
*/
EXTERN t_error
st7066u_close(t_st7066u display);

/*
** Opens the WS0010 display, which is connected via USB PCB that controls it.
** A typical URI for the connection to the display is
**    "lcd://qbot_platform:1"
** On a target other than QBot Platform, a typical URI might be:
**    "spi://localhost:0?baud=2e6,word=10,polarity=1,phase=1,frame=56"
** This particular URI was used with the display connected to a Quanser QPIDe 
** terminal board in Windows.
**
** Set the graphics_mode parameter to false to use the display with text only
** via the ws0010_print and ws0010_wprint functions.
**
** Set the graphics_mode parameter to true to use the display with graphics only
** via the ws0010_draw_image function.
**
** It is not possible to switch between graphics and text mode without closing
** and re-opening the display.
*/
EXTERN t_error
ws0010_open(const char* uri, t_boolean graphics_mode, t_ws0010* display);

/*
** Print to the display. Unrecognized characters are skipped. If more than 16
** characters would be printed on a line then the line is truncated. A newline will
** cause the characters to be displayed on the next line. As there are only two
** lines on the display there should only be one newline in the format string.
**
** Printing starts at the given line and column. Line 0 is the first line and
** column 0 is the first column. For example:
**  ws0010_print(display, 0, 0, "Hello world")
** will print "Hello world" starting in the top, left corner of the display.
**
** The format string is UTF-8 and does support Unicode (particularly, Katakana
** characters).
*/
EXTERN t_int
ws0010_print(t_ws0010 display, t_uint line, t_uint column, const char* message, size_t length);

EXTERN t_int
ws0010_wprint(t_ws0010 display, t_uint line, t_uint column, const wchar_t* message, size_t length);

#if defined(_UNICODE)
#define ws0010_tprint(display, line, column, message) ws0010_wprint(display, line, column, message, length)
#else
#define ws0010_tprint(display, line, column, message) ws0010_print(display, line, column, message, length)
#endif

/*
** Defines the character associated with the given character code. Valid character codes
** are 0x10 to 0x17 i.e., '\020' to '\027'. Using these characters will produce the
** bitmap defined in the pattern for that character.
**
** The pattern defines each line of the character being defined, with the five bits
** in each t_uint8 defining the pixels of that line. For example to define the letter T,
** the pattern would be:
**      pattern[0] = 0b00011111 (0x1F)
**      pattern[1] = 0b00000100 (0x04)
**      pattern[2] = 0b00000100 (0x04)
**      pattern[3] = 0b00000100 (0x04)
**      pattern[4] = 0b00000100 (0x04)
**      pattern[5] = 0b00000100 (0x04)
**      pattern[6] = 0b00000100 (0x04)
**      pattern[7] = 0b00000000 (0x00) <= should generally be zero to allow for cursor
** Note that only bits 0-4 are used. Bit 0 is the rightmost pixel and bit 4 is the leftmost pixel.
*/
EXTERN t_error
ws0010_set_character(t_ws0010 display, t_int code, const t_uint8 pattern[8]);

/*
** Draws an image on the display at the given pixel coordinates (top, left). Note that this function
** does not clear the display first, so it is possible to draw multiple images at different locations.
** The image is expected to be a black and white image in row-major order (stored column by column in memory)
** with each byte representing a single pixel (0 or 255). It also accepts greyscale images, in which
** case it will use a threshold of pixel <= 127 to differentiate white and black.
*/
EXTERN t_error
ws0010_draw_image(t_ws0010 display, t_int pixel_row, t_int pixel_column, t_uint image_width, t_uint image_height, const t_uint8* image);

/*
** Close the display, freeing up allocated resources.
*/
EXTERN t_error
ws0010_close(t_ws0010 display);

/*
** Opens the Sharp LS012B7DD01. A typical URI for an SPI connection to
** the display on the QDrone2 is "spi://localhost:2?word=8,baud=1000000,frame=1,memsize=990"
*/
EXTERN t_error
ls012b7dd01_open(const char* uri, t_ls012b7dd01* display);

/*
** Print to the display. Unrecognized characters are skipped. If more than 16
** characters would be printed on a line then the line is truncated. A newline will
** cause the characters to be displayed on the next line. As there are only two
** lines on the display there should only be one newline in the format string.
**
** Printing starts at the given line and column. Line 0 is the first line and
** column 0 is the first column. For example:
**  ls012b7dd01_print(display, 0, 0, "Hello world")
** will print "Hello world" starting in the top, left corner of the display.
**
** The format string is UTF-8 and does support Unicode (particularly, Katakana
** characters).
*/
EXTERN t_int
ls012b7dd01_print(t_ls012b7dd01 display, t_uint line, t_uint column, const char* message, size_t length);

EXTERN t_int
ls012b7dd01_wprint(t_ls012b7dd01 display, t_uint line, t_uint column, const wchar_t* message, size_t length);

#if defined(_UNICODE)
#define ls012b7dd01_tprint(display, line, column, message) ls012b7dd01_wprint(display, line, column, message, length)
#else
#define ls012b7dd01_tprint(display, line, column, message) ls012b7dd01_print(display, line, column, message, length)
#endif

/*
** Defines the character associated with the given character code. Valid character codes
** are 0x10 to 0x17 i.e., '\020' to '\027'. Using these characters will produce the
** bitmap defined in the pattern for that character.
**
** The pattern defines each line of the character being defined, with the eleven bits
** in each t_uint16 defining the pixels of that line. For example to define the letter T,
** the pattern would be:
**      pattern[0]  = 0b00000000000 (0x0000)
**      pattern[1]  = 0b00000000000 (0x0000)
**      pattern[2]  = 0b00000000000 (0x0000)
**      pattern[3]  = 0b00111111100 (0x01FC)
**      pattern[4]  = 0b00000100000 (0x0020)
**      pattern[5]  = 0b00000100000 (0x0020)
**      pattern[6]  = 0b00000100000 (0x0020)
**      pattern[7]  = 0b00000100000 (0x0020)
**      pattern[8]  = 0b00000100000 (0x0020)
**      pattern[9]  = 0b00000100000 (0x0020)
**      pattern[10] = 0b00000100000 (0x0020)
**      pattern[11] = 0b00000100000 (0x0020)
**      pattern[12] = 0b00000000000 (0x0000)
**      pattern[13] = 0b00000000000 (0x0000)
**      pattern[14] = 0b00000000000 (0x0000)
**      pattern[15] = 0b00000000000 (0x0000)
** Note that only bits 0-10 are used. Bit 0 is the rightmost pixel and bit 10 is the leftmost pixel.
** The baseline is in pattern[11]. The top of a typical character is in pattern[3], although some
** characters go higher.
*/
EXTERN t_error
ls012b7dd01_set_character(t_ls012b7dd01 display, t_int code, const t_uint16 pattern[16]);

/*
** Determine whether to invert the colours of the display so that text appears as
** white text on a black background, instead of black text on a white background.
*/
EXTERN t_error
ls012b7dd01_set_inversion(t_ls012b7dd01 display, t_boolean invert);

/*
** Determine whether to rotate the display 180 degrees.
*/
EXTERN t_error
ls012b7dd01_set_rotation(t_ls012b7dd01 display, t_boolean rotate);

/*
** Draws an image on the display at the given pixel coordinates (top, left). Note that this function
** does not clear the display first, so it is possible to draw multiple images at different locations.
** The image is expected to be a black and white image in row-major order (stored column by column in memory)
** with each byte representing a single pixel (0 or 255). It also accepts greyscale images, in which
** case it will use a threshold of pixel <= 127 to differentiate white and black.
*/
EXTERN t_error
ls012b7dd01_draw_image(t_ls012b7dd01 display, t_int pixel_row, t_int pixel_column, t_uint image_width, t_uint image_height, const t_uint8* image);

/*
** Close the display, freeing up allocated resources.
*/
EXTERN t_error
ls012b7dd01_close(t_ls012b7dd01 display);


/*
** Opens the Sharp LS027B7DH01. A typical URI for an SPI connection to
** the display on the QCar2 is "spi://localhost:2?word=8,baud=1000000,frame=1,memsize=990".
** The access parameter determines whether the LCD can be shared or not while
** it is open.
*/
EXTERN t_error
ls027b7dh01_open(const char* uri, t_lcd_access access, t_ls027b7dh01* display);

/*
** Put the LCD display into drawing mode so that the display is not updated until
** ls027b7dh01_end_draw is called. This allows both graphics and text to be mixed
** on the display as an atomic update.
*/
EXTERN t_error
ls027b7dh01_begin_draw(t_ls027b7dh01 display);

/*
** Take the LCD display out of drawing mode. The display will be updated at
** this point.
*/
EXTERN t_error
ls027b7dh01_end_draw(t_ls027b7dh01 display);

/*
** Print to the display. Unrecognized characters are skipped. If more than 25
** characters would be printed on a line then the line is truncated. A newline will
** cause the characters to be displayed on the next line. Up to 12 lines may be
** displayed.
**
** Printing starts at the given line and column. Line 0 is the first line and
** column 0 is the first column. For example:
**  ls027b7dh01_print(display, 0, 0, "Hello world")
** will print "Hello world" starting in the top, left corner of the display.
**
** The format string is Unicode.
*/
EXTERN t_int
ls027b7dh01_print(t_ls027b7dh01 display, t_uint line, t_uint column, const char* message, size_t length);

EXTERN t_int
ls027b7dh01_wprint(t_ls027b7dh01 display, t_uint line, t_uint column, const wchar_t* message, size_t length);

#if defined(_UNICODE)
#define ls027b7dh01_tprint(display, line, column, message) ls027b7dh01_wprint(display, line, column, message, length)
#else
#define ls027b7dh01_tprint(display, line, column, message) ls027b7dh01_print(display, line, column, message, length)
#endif

/*
** Defines the character associated with the given character code. Valid character codes
** are 0x10 to 0x17 i.e., '\020' to '\027'. Using these characters will produce the
** bitmap defined in the pattern for that character.
**
** The pattern defines each line of the character being defined, with the sixteen bits
** in each t_uint16 defining the pixels of that line. For example to define the letter T,
** the pattern would be:
**      pattern[0]  = 0b0000000000000000 (0x0000)
**      pattern[1]  = 0b0000000000000000 (0x0000)
**      pattern[2]  = 0b0000000000000000 (0x0000)
**      pattern[3]  = 0b0001111111111000 (0x1FF8)
**      pattern[4]  = 0b0000000010000000 (0x0080)
**      pattern[5]  = 0b0000000010000000 (0x0080)
**      pattern[6]  = 0b0000000010000000 (0x0080)
**      pattern[7]  = 0b0000000010000000 (0x0080)
**      pattern[8]  = 0b0000000010000000 (0x0080)
**      pattern[9]  = 0b0000000010000000 (0x0080)
**      pattern[10] = 0b0000000010000000 (0x0080)
**      pattern[11] = 0b0000000010000000 (0x0080)
**      pattern[12] = 0b0000000010000000 (0x0080)
**      pattern[13] = 0b0000000010000000 (0x0080)
**      pattern[14] = 0b0000000010000000 (0x0080)
**      pattern[15] = 0b0000000000000000 (0x0000)
**      pattern[16] = 0b0000000000000000 (0x0000)
**      pattern[17] = 0b0000000000000000 (0x0000)
**      pattern[18] = 0b0000000000000000 (0x0000)
**      pattern[19] = 0b0000000000000000 (0x0000)
** Note that all 16 bits are used. Bit 0 is the rightmost pixel and bit 15 is the leftmost pixel.
** The baseline is in pattern[14]. The top of a typical character is in pattern[3], although some
** characters go higher.
*/
EXTERN t_error
ls027b7dh01_set_character(t_ls027b7dh01 display, t_int code, const t_uint16 pattern[20]);

/*
** Determine whether to invert the colours of the display so that text appears as
** white text on a black background, instead of black text on a white background.
*/
EXTERN t_error
ls027b7dh01_set_inversion(t_ls027b7dh01 display, t_boolean invert);

/*
** Determine whether to rotate the display 180 degrees.
*/
EXTERN t_error
ls027b7dh01_set_rotation(t_ls027b7dh01 display, t_boolean rotate);

/*
** Draws an image on the display at the given pixel coordinates (top, left). Note that this function
** does not clear the display first, so it is possible to draw multiple images at different locations.
** The image is expected to be a black and white image in column-major order (stored column by column in memory)
** with each byte representing a single pixel (0 or 255). It also accepts greyscale images, in which
** case it will use a threshold of pixel <= 127 to differentiate white and black.
*/
EXTERN t_error
ls027b7dh01_draw_image(t_ls027b7dh01 display, t_int pixel_row, t_int pixel_column, t_uint image_width, t_uint image_height, const t_uint8* image);

/*
** Save the current display contents to a PBM image file. The filename should
** have a .pbm extension.
*/
EXTERN t_error
ls027b7dh01_save_display(t_ls027b7dh01 display, const char* filename);

/*
** Close the display, freeing up allocated resources.
*/
EXTERN t_error
ls027b7dh01_close(t_ls027b7dh01 display);

/*
** Opens the Quanser Mechatronics Sensors USB LCD. Use a URI of the
** form lcd://localhost:<port> where <port> is the board number of
** the USB device.
*/
EXTERN t_error
mech_sensors_trainer_lcd_open(const char* uri, t_mech_sensors_trainer_lcd* display);

/*
** Put the LCD display into drawing mode so that the display is not updated until
** mech_sensors_trainer_lcd_end_draw is called. This allows both graphics and text to be mixed
** on the display as an atomic update.
*/
EXTERN t_error
mech_sensors_trainer_lcd_begin_draw(t_mech_sensors_trainer_lcd display);

/*
** Take the LCD display out of drawing mode. The display will be updated at
** this point.
*/
EXTERN t_error
mech_sensors_trainer_lcd_end_draw(t_mech_sensors_trainer_lcd display);

/*
* Description:
*
*   Draws an image on the display at the given pixel coordinates (top, left).
*
*   Note that this function does not clear the display first, so it is possible to draw multiple images at different
*   locations. The image is expected to be in the image format specified.
*
* Parameters:
*   display      = the handle to the display returned by mech_sensors_trainer_lcd_open
*   pixel_row    = the pixel row at which the top edge of the image will be drawn
*   pixel_column = the pixel column at which the left edge of the image will be drawn
*   image_width  = the width of the image
*   image_height = the height of the image
*   image_format = the format of the image. Not all image formats are supported.
*   image        = a pointer to the image, which must be in the format specified by the image_format argument.
*/
EXTERN t_error
mech_sensors_trainer_lcd_draw_image(t_mech_sensors_trainer_lcd display, t_int pixel_row, t_int pixel_column, t_uint image_width, t_uint image_height, t_image_format image_format, const t_uint8* image);

/*
* Description:
* 
*   Draws an image on the display at the given pixel coordinates (top, left) using the mask as the alpha
*   component of the image. Hence, a value of 0 in the mask at a pixel will cause that image pixel not to be
*   drawn and a value of 255 in the mask at a pixel will cause that image pixel to be drawn. Any value in between
*   and it will blend the image with the image on screen.
*
*   Note that this function does not clear the display first, so it is possible to draw multiple images at different 
*   locations. The image is expected to be in the image format specified. The mask must be in the grayscale format
*   corresponding to the given image format.
* 
* Parameters:
*   display      = the handle to the display returned by mech_sensors_trainer_lcd_open
*   pixel_row    = the pixel row at which the top edge of the image will be drawn
*   pixel_column = the pixel column at which the left edge of the image will be drawn
*   image_width  = the width of the image
*   image_height = the height of the image
*   image_format = the format of the image. Not all image formats are supported.
*   image        = a pointer to the image, which must be in the format specified by the image_format argument.
*   mask         = an alpha mask in the grayscale format corresponding to the image_format argument.
*/
EXTERN t_error
mech_sensors_trainer_lcd_draw_image_with_blend(t_mech_sensors_trainer_lcd display, t_int pixel_row, t_int pixel_column, t_uint image_width, t_uint image_height, t_image_format image_format, const t_uint8* image, const t_uint8* mask);

/*
* Description:
*
*   Draws an image on the display at the given pixel coordinates (top, left) using the mask to determine which
*   pixels are drawn and which are not. Hence, a value of 0 in the mask at a pixel will cause that image pixel not to be
*   drawn and a non-zero value in the mask at a pixel will cause that image pixel to be drawn.
*
*   Note that this function does not clear the display first, so it is possible to draw multiple images at differents
*   locations. The image is expected to be in the image format specified. The mask must be in the grayscale format
*   corresponding to the given image format.
*
* Parameters:
*   display      = the handle to the display returned by mech_sensors_trainer_lcd_open
*   pixel_row    = the pixel row at which the top edge of the image will be drawn
*   pixel_column = the pixel column at which the left edge of the image will be drawn
*   image_width  = the width of the image
*   image_height = the height of the image
*   image_format = the format of the image. Not all image formats are supported.
*   image        = a pointer to the image, which must be in the format specified by the image_format argument.
*   mask         = a simple black and white mask in the grayscale format corresponding to the image_format argument.
*/
EXTERN t_error
mech_sensors_trainer_lcd_draw_image_with_mask(t_mech_sensors_trainer_lcd display, t_int pixel_row, t_int pixel_column, t_uint image_width, t_uint image_height, t_image_format image_format, const t_uint8* image, const t_uint8* mask);

/*
* Description:
* 
* Print to the display. Unrecognized characters are skipped. If more than 50
* characters would be printed on a line then the line is truncated. A newline will
* cause the characters to be displayed on the next line. Up to 24 lines may be
* displayed.
* 
* Printing starts at the given line and column. Line 0 is the first line and
* column 0 is the first column. For example:
*  mech_sensors_trainer_lcd_print(display, 0, 0, "Hello world", 11)
* will print "Hello world" starting in the top, left corner of the display.
* 
* The message string is UTF-8. The maximum length is specified in code units,
* which in this case are bytes. Note that a single UTF-8 character can span
* up to four code units.
* 
* Parameters:
* 
*   display = the handle returned by mech_sensors_trainer_lcd_open.
*   line    = the zero-based line number at which to print the text.
*   column  = the zero-based column number at which to print the text.
*   message = the message text as a UTF-8 string.
*   length  = the maximum length of the message in code units (bytes).
* 
* Returns:
*   Returns zero on success and a negative error code on failure.
*/
EXTERN t_int
mech_sensors_trainer_lcd_print(t_mech_sensors_trainer_lcd display, t_uint line, t_uint column, const char* message, size_t length);

/*
* Description:
*
* Print to the display. Unrecognized characters are skipped. If more than 50
* characters would be printed on a line then the line is truncated. A newline will
* cause the characters to be displayed on the next line. Up to 24 lines may be
* displayed.
*
* Printing starts at the given line and column. Line 0 is the first line and
* column 0 is the first column. For example:
*  mech_sensors_trainer_lcd_wprint(display, 0, 0, L"Hello world", 11)
* will print "Hello world" starting in the top, left corner of the display.
*
* The message string is Unicode. Note that the size of a code unit depends on
* the platform and a single Unicode character may span more than one code unit.
*
* Parameters:
*
*   display = the handle returned by mech_sensors_trainer_lcd_open.
*   line    = the zero-based line number at which to print the text.
*   column  = the zero-based column number at which to print the text.
*   message = the message text as a wide Unicode string.
*   length  = the maximum length of the message in code units.
*
* Returns:
*   Returns zero on success and a negative error code on failure.
*/
EXTERN t_int
mech_sensors_trainer_lcd_wprint(t_mech_sensors_trainer_lcd display, t_uint line, t_uint column, const wchar_t* message, size_t length);

/*
* Description:
*
* Print to the display. Unrecognized characters are skipped. If more than 50
* characters would be printed on a line then the line is truncated. A newline will
* cause the characters to be displayed on the next line. Up to 24 lines may be
* displayed.
*
* Printing starts at the given line and column. Line 0 is the first line and
* column 0 is the first column. For example:
*  mech_sensors_trainer_lcd_print(display, 0, 0, "Hello world", 11)
* will print "Hello world" starting in the top, left corner of the display.
*
* The message string is UTF-8. The maximum length is specified in characters.
*
* Parameters:
*
*   display = the handle returned by mech_sensors_trainer_lcd_open.
*   line    = the zero-based line number at which to print the text.
*   column  = the zero-based column number at which to print the text.
*   message = the message text as a UTF-8 string.
*   length  = the maximum length of the message in characters.
*
* Returns:
*   Returns zero on success and a negative error code on failure.
*/
EXTERN t_int
mech_sensors_trainer_lcd_print_cch(t_mech_sensors_trainer_lcd display, t_uint line, t_uint column, const char* message, size_t length);

/*
* Description:
*
* Print to the display. Unrecognized characters are skipped. If more than 50
* characters would be printed on a line then the line is truncated. A newline will
* cause the characters to be displayed on the next line. Up to 24 lines may be
* displayed.
*
* Printing starts at the given line and column. Line 0 is the first line and
* column 0 is the first column. For example:
*  mech_sensors_trainer_lcd_wprint(display, 0, 0, L"Hello world", 11)
* will print "Hello world" starting in the top, left corner of the display.
*
* The message string is Unicode. Note that the size of a code unit depends on
* the platform and a single Unicode character may span more than one code unit.
*
* Parameters:
*
*   display = the handle returned by mech_sensors_trainer_lcd_open.
*   line    = the zero-based line number at which to print the text.
*   column  = the zero-based column number at which to print the text.
*   message = the message text as a wide Unicode string.
*   length  = the maximum length of the message in characters.
*
* Returns:
*   Returns zero on success and a negative error code on failure.
*/
EXTERN t_int
mech_sensors_trainer_lcd_wprint_cch(t_mech_sensors_trainer_lcd display, t_uint line, t_uint column, const wchar_t* message, size_t length);

#if defined(_UNICODE)
#define mech_sensors_trainer_lcd_tprint(display, line, column, message) mech_sensors_trainer_lcd_wprint(display, line, column, message, length)
#define mech_sensors_trainer_lcd_tprint_cch(display, line, column, message) mech_sensors_trainer_lcd_wprint(display, line, column, message, length)
#else
#define mech_sensors_trainer_lcd_tprint(display, line, column, message) mech_sensors_trainer_lcd_print(display, line, column, message, length)
#define mech_sensors_trainer_lcd_tprint_cch(display, line, column, message) mech_sensors_trainer_lcd_print(display, line, column, message, length)
#endif

/*
** Defines the character associated with the given character code. Valid character codes
** are 0x10 to 0x17 i.e., '\020' to '\027'. Using these characters will produce the
** bitmap defined in the pattern for that character.
**
** The pattern defines each line of the character being defined, with the sixteen bits
** in each t_uint16 defining the pixels of that line. For example to define the letter T,
** the pattern would be:
**      pattern[0]  = 0b0000000000000000 (0x0000)
**      pattern[1]  = 0b0000000000000000 (0x0000)
**      pattern[2]  = 0b0000000000000000 (0x0000)
**      pattern[3]  = 0b0001111111111000 (0x1FF8)
**      pattern[4]  = 0b0000000010000000 (0x0080)
**      pattern[5]  = 0b0000000010000000 (0x0080)
**      pattern[6]  = 0b0000000010000000 (0x0080)
**      pattern[7]  = 0b0000000010000000 (0x0080)
**      pattern[8]  = 0b0000000010000000 (0x0080)
**      pattern[9]  = 0b0000000010000000 (0x0080)
**      pattern[10] = 0b0000000010000000 (0x0080)
**      pattern[11] = 0b0000000010000000 (0x0080)
**      pattern[12] = 0b0000000010000000 (0x0080)
**      pattern[13] = 0b0000000010000000 (0x0080)
**      pattern[14] = 0b0000000010000000 (0x0080)
**      pattern[15] = 0b0000000000000000 (0x0000)
**      pattern[16] = 0b0000000000000000 (0x0000)
**      pattern[17] = 0b0000000000000000 (0x0000)
**      pattern[18] = 0b0000000000000000 (0x0000)
**      pattern[19] = 0b0000000000000000 (0x0000)
** Note that all 16 bits are used. Bit 0 is the rightmost pixel and bit 15 is the leftmost pixel.
** The baseline is in pattern[14]. The top of a typical character is in pattern[3], although some
** characters go higher.
*/
EXTERN t_error
mech_sensors_trainer_lcd_set_character(t_mech_sensors_trainer_lcd display, t_int code, const t_uint16 pattern[20]);

/*
** Sets the colour to use for text when printing. Colour components range from 0 to 255.
*/
EXTERN t_error
mech_sensors_trainer_lcd_set_text_color(t_mech_sensors_trainer_lcd display, t_uint8 red, t_uint8 green, t_uint8 blue);

/*
** Determine whether to invert the colours of the display so that text appears as
** white text on a black background, instead of black text on a white background.
*/
EXTERN t_error
mech_sensors_trainer_lcd_set_inversion(t_mech_sensors_trainer_lcd display, t_boolean invert);

/*
** Clear the LCD display to the background colour.
*/
EXTERN t_error
mech_sensors_trainer_lcd_clear(t_mech_sensors_trainer_lcd display);

/*
** Determine whether to rotate the display 180 degrees.
*/
EXTERN t_error
mech_sensors_trainer_lcd_set_rotation(t_mech_sensors_trainer_lcd display, t_boolean rotate);

/*
* Get the touch information for the display. If the data is new since the last time this function
* was invoked then the return value is 1. Otherwise the return value is zero. If an error occurs
* then a negative error code is returned.
*/
EXTERN t_error
mech_sensors_trainer_lcd_get_touch_information(t_mech_sensors_trainer_lcd display, t_lcd_touch* touch_info);

/*
** Save the current display contents to a PPM image file. The filename should
** have a .ppm extension.
*/
EXTERN t_error
mech_sensors_trainer_lcd_save_display(t_mech_sensors_trainer_lcd display, const char* filename);

/*
** Close the display, freeing up allocated resources.
*/
EXTERN t_error
mech_sensors_trainer_lcd_close(t_mech_sensors_trainer_lcd display);

#endif
