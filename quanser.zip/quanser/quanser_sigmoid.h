#if !defined(_quanser_sigmoid_h)
#define _quanser_sigmoid_h

#include "quanser_types.h"
#include "quanser_runtime.h"

enum tag_sigmoid_parameter_indices
{
	SIGMOID_PARAMETER_T1,
	SIGMOID_PARAMETER_T2,
	SIGMOID_PARAMETER_T3,
	SIGMOID_PARAMETER_X0,
	SIGMOID_PARAMETER_X1,
	SIGMOID_PARAMETER_X2,
	SIGMOID_PARAMETER_XD,
	SIGMOID_PARAMETER_V0,
	SIGMOID_PARAMETER_VP,
	SIGMOID_PARAMETER_AP,
	SIGMOID_PARAMETER_HOLD_OFF,

	NUMBER_OF_SIGMOID_PARAMETERS
};

EXTERN void sigmoid_calculate_trajectory(t_double params[NUMBER_OF_SIGMOID_PARAMETERS],
                                         t_double T0, t_double X0, t_double V0, 
                                         const t_double max_acceleration, 
                                         const t_double max_velocity);

#endif
