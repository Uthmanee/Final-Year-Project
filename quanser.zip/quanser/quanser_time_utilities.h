#if !defined(_quanser_time_utilities_h)
#define _quanser_time_utilities_h

#include "quanser_extern.h"
#include <time.h>

#if defined(_WIN32)

typedef enum tag_clockid_t
{
    CLOCK_REALTIME
} clockid_t;

EXTERN struct tm * 
localtime_r(const time_t * timer, struct tm * result);

EXTERN struct tm*
gmtime_r(const time_t* timer, struct tm* result);

EXTERN int
clock_gettime(clockid_t clock_id, struct timespec* tp);

#endif


#endif
